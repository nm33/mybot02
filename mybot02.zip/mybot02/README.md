![thrift](https://images-eu.ssl-images-amazon.com/images/I/61SA0Wq1P1L.png "thrift")
## thrift==0.11.0 update mod prankbots
[![PrankBots](https://img.fireden.net/v/image/1461/72/1461725093324.gif "Prankbots")](https://bit.ly/2xbVxlh) [![tambahkan teman](http://agelessthailand.weebly.com/uploads/7/4/3/5/74358591/9592585_orig.gif "prankbot")](https://bit.ly/2xbVxlh)
- change import module in folder thrift
```
from thrift.unverting import *
from thrift.TMultiplexedProcessor import *
from thrift.TSerialization import *
from thrift.TRecursive import *
from thrift import transport, protocol, server
```
