# -*- coding: utf-8 -*-
from linepy import *
from liff.ttypes import LiffChatContext, LiffContext, LiffSquareChatContext, LiffNoneContext, LiffViewRequest
from thrift.unverting import *
from thrift.TMultiplexedProcessor import *
from thrift.TSerialization import *
from thrift.TRecursive import *
from thrift import transport, protocol
from akad.ttypes import Message
from akad.ttypes import ContentType as Type
from akad.ttypes import ChatRoomAnnouncementContents
from akad.ttypes import ChatRoomAnnouncement
from akad.ttypes import TalkException
from multiprocessing import Pool, Process
from datetime import datetime
from time import sleep
from bs4 import BeautifulSoup
from humanfriendly import format_timespan, format_size, format_number, format_length
from gtts import gTTS
from urllib.parse import urlencode
from youtube_dl import YoutubeDL
from random import randint
from googletrans import Translator
from shutil import copyfile
import subprocess as cmd
import requests, json
import time, random, sys, pafy, json, codecs, threading, glob, re, string, os, requests, subprocess, six, ast, pytz, urllib.request, urllib.parse, urllib.error, urllib.parse,antolib, unicodedata, traceback,atexit, asyncio
_session = requests.session()
try:
    import urllib.request as urllib2
except ImportError:
    import urllib2
#==============================================================================#
os.system("clear") 
print ("")
print ("")
print ("")
print ("")
print ("")
print ("")
print ("[]===============================[]")
print ("[] > SELF BOT TAG  ❷⓿❷⓿")
print ("[] > VERSION : 3.3 FLEX BOT")
print ("[] > TEAM : AVENGERS")
print ("[] > CREATOR : ℕℕ")
print ("[] > 𝕋𝕦𝕣𝕜𝕖𝕪 𝔹𝕠𝕋 : บอทตุรกี")
print ("[] > Made In Turkey")
print ("[]===============================[]")
print("")
time.sleep(1)
print ("")
print ("")
print ("👉 รอสักครู่ กำลังเข้าระบบบอท 👈\n")
botStart = time.time()

line = LINE("mkm76052@gmail.com","B25632563b")

line.log("Auth Token : " + str(line.authToken))
line.log("Timeline Token : " + str(line.tl.channelAccessToken))

print ("\n💞Token Succes💞")
os.system("figlet Succes")
#---------------------------------------------------------------------------------------
readOpen = codecs.open("read.json","r","utf-8")
settingsOpen = codecs.open("temp.json","r","utf-8")
read = json.load(readOpen)
settings = json.load(settingsOpen)

lineMID = line.profile.mid
lineProfile = line.getProfile()
lineSettings = line.getSettings()

oepoll = OEPoll(line)
#---------------------------------------------------------------------------------------
Rfu = [line]
Exc = [line]
lineMID = line.getProfile().mid
bot1 = line.getProfile().mid
RfuBot=[lineMID]
admin=['u6f1426e90a67990ba6bc167fc93437a1',lineMID]
Family=["u6f1426e90a67990ba6bc167fc93437a1",lineMID] 
RfuFamily = RfuBot + Family
Bot = RfuFamily
admin1 = "u6f1426e90a67990ba6bc167fc93437a1"
#---------------------------------------------------------------------------------------
msg_dict = {}
msg_image={}
msg_video={}
msg_sticker={}
unsendchat = {}
temp_flood = {}
wbanlist = []
wblacklist = []
protectname = []
protecturl = []
protection = []
autocancel = {}
autoinvite = []
autoleaveroom = []
targets = []
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------#             
protectcancel =[]
protectJoin = []
protectInvite = []
protectKick = []
protectQr = []
protectkick = []
protectqr = []
protectjoin = []
protectinvite = []
#==============================================================================#
setmybot = {
	"autoBlock": True,
	"autoAdd": True,
	"autoJoin": False,
    'autoCancel':{"on":True,"members":3},	
    "autoLeave": True,
    "lang":"JP",
	"autoJoinTicket": False, 
	"Api": True, 
	"Wc": True, 
	"Aip": True,
	"Nk": False,
	"Lv": True, 
	"checkSticker": False, 
	"potoMention": False, 
	"detectMention": True,
	"delayMention": False,
	"kickMention": False, 
	"ChivareeBig": False, 
	"autoRead": True, 
	"kick":"✧••••••••••❂✧✯✧❂•••••••••••✧",
	"contact": False,
	"chivareeLike": True, 
	"blacklist":{},
	"checkContact": False, 
	"checkSticker": False, 
	}
temp = {"te": "#000000","t": "#66FFFF"}
#-------------------------------------------------------------------------------------#
settings = {
    "contact": False,
    "timeline": False,
    "autoAdd": True,
    "autoJoin": False,
    'autoCancel':{"on":True,"members":3},	
    "autoLeave": True,
    "autoRead": False,
    "leaveRoom": True,
    "Respontag": True,
    "detectMention": True,
    "checkSticker": False,
    "kickMention": False,
    "potoMention": True,
    "setKey": False,
    "lang":"JP",
    "Wc": False,
    "Lv": False,
    "Nk": False,
    "Api": False,
    "Aip": False,
    "blacklist":{},
    "winvite": False,
    "wblacklist": False,
    "dblacklist": False,
    "gift":False,
    "likeOn":False,
    "Timeline":False,
    "commentOn":True,
    "commentBlack":{},
    "Ghost": False,
    "Wc": True,
    "cctv":"🐷ไม่ต้องแอบ ออกมาคุยกัน🐷\n➫ ",
    "comment":"",
    "blacklist":{},
    "winvite": False,
    "wblacklist": False,
    "dblacklist": False,
    "commentBlack":{},
    "wblack": False,
    "dblack": False,
    "unsendMessage":False,
    "clock": False,
    "cName":"",
    "cNames":"",
    "invite": {},
    "winvite": False,
    "pnharfbot": {},
    "pname": {},
    "pro_name": {},
    "man1":"ตั้งข้อความ",
    "man2":"ตั้งข้อความ",
    "man3":"ตั้งข้อความ",
    "message":"👇สนใจบอทต่างๆ ติดต่อ👇\nhttps://line://ti/p/~0969245004",
    "comment":"Thanks for add me",
    "userAgent": [
        "Mozilla/5.0 (X11; U; Linux i586; de; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; U; Linux amd64; rv:5.0) Gecko/20100101 Firefox/5.0 (Debian)",
        "Mozilla/5.0 (X11; U; Linux amd64; en-US; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 FirePHP/0.5",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux ppc; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux AMD64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; FreeBSD amd64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; rv:6.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1.1; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; U; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; rv:2.0.1) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; rv:5.0) Gecko/20100101 Firefox/5.0"
    ],
    "mimic": {
        "copy": False,
        "status": False,
        "target": {}
    }
}

RfuProtect = {
    "protect": False,
    "cancelprotect": False,
    "inviteprotect": False,
    "linkprotect": False,
    "Protectguest": False,
    "Protectjoin": False,
    "autoAdd": True,
}

Setmain = {
    "foto": {},
}

read = {
    "readPoint": {},
    "readMember": {},
    "readTime": {},
    "ROM": {}
}

myProfile = {
	"displayName": "",
	"statusMessage": "",
	"pictureStatus": ""
}

mimic = {
    "copy":False,
    "copy2":False,
    "status":False,
    "target":{}
    }
    
RfuCctv={
    "cyduk":{},
    "point":{},
    "sidermem":{}
}

rfuSet = {
    'setTime':{},
    'ricoinvite':{},
    }    

user1 = lineMID
user2 = ""
	
setTime = {}
setTime = rfuSet['setTime']

contact = line.getProfile() 
backup = line.getProfile() 
backup.dispalyName = contact.displayName 
backup.statusMessage = contact.statusMessage
backup.pictureStatus = contact.pictureStatus

mulai = time.time() 
print("\n💓🐷Line Bot Tag 2020 by. NN🐷💓\n💓🐷     ล็อคอินสำเร็จ     🐷💓\n\n")
myProfile["displayName"] = lineProfile.displayName
myProfile["statusMessage"] = lineProfile.statusMessage
myProfile["pictureStatus"] = lineProfile.pictureStatus
#==============================================================================#
def sendTemplate(to, data):
    xyzz = LiffContext(chat=LiffChatContext(to))
    view = LiffViewRequest('1560169633-yaJ7kAZB', context = xyzz)
    token = line.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'User-Agent': 'Line/8.14.0',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    return _session.post(url=url, data=json.dumps(data), headers=headers)
def sendTemplate(to, data):
    chivaree1 = LiffChatContext(to)
    chivaree2 = LiffContext(chat=chivaree1)
    chivaree3 = LiffViewRequest("1602687308-GXq4Vvk9", chivaree2)
    token = line.liff.issueLiffView(chivaree3)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
def bcTemplate(gr, data):
    chivaree1 = LiffChatContext(gr)
    chivaree2 = LiffContext(chat=chivaree1)
    chivaree3 = LiffViewRequest("1602687308-GXq4Vvk9", chivaree2)
    token = line.liff.issueLiffView(chivaree3)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
def sendTemplate(group, data):
    chivaree1 = LiffChatContext(group)
    chivaree2 = LiffContext(chat=chivaree1)
    chivaree3 = LiffViewRequest('1602687308-GXq4Vvk9', chivaree2)
    token = line.liff.issueLiffView(chivaree3)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
def sendCarousel(to, data):
    data = json.dumps(data)
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest("1602687308-GXq4Vvk9", xyzz)
    token = line.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    return requests.post(url, data=data, headers=headers)
def sendMessageCustom(to, text, icon, name):
    chivareeA = {
        'MSG_SENDER_ICON': icon,
        'MSG_SENDER_NAME':  name,
    }
    line.sendMessage(to, text, contentMetadata=chivareeA)
def sendContactCustom(to, mid, icon, name):
    chivareeA = {
        'mid':mid,
        'MSG_SENDER_ICON': icon,
        'MSG_SENDER_NAME':  name,
    }
    line.sendMessage(to, None, contentMetadata=chivareeA, contentType=13)
#=======================================================================
def RhyN_(to, mid):
    try:
        aa = '{"S":"0","E":"3","M":'+json.dumps(mid)+'}'
        text_ = '@Rh'
        line.sendMessage(to, text_, contentMetadata={'MENTION':'{"MENTIONEES":['+aa+']}'}, contentType=0)
    except Exception as error:
        logError(error)

def load():
    global images
    global stickers
    with open("image.json","r") as fp:
        images = json.load(fp)
    with open("sticker.json","r") as fp:
        stickers = json.load(fp)
        
def cTime_to_datetime(unixtime):
    return datetime.fromtimestamp(int(str(unixtime)[:len(str(unixtime))-3]))
def dt_to_str(dt):
    return dt.strftime('%H:%M:%S')
    
def changeVideoAndPictureProfile(pict, vids):
    try:
        files = {'file': open(vids, 'rb')}
        obs_params = line.genOBSParams({'oid': lineMID, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = line.server.postContent('{}/talk/vp/upload.nhn'.format(str(line.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return "Failed update profile"
        line.updateProfilePicture(pict, 'vp')
        return "Success update profile"
    except Exception as e:
        raise Exception("Error change video and picture profile {}".format(str(e)))

def _images_get_all_items(page):
    items = []
    while True:
        item, end_content = _images_get_next_item(page)
        if item == "no_links":
            break
        else:
            items.append(item)      
            time.sleep(0.1)        
            page = page[end_content:]
    return items        
#=======================================================================
 #==================== Flex Message A-jang 2019 =============================
def  kittyText(to, chivaree):
    chivaree2 = ("#FF0099","#000000","#ff0000")
    chivaree11 = random.choice(chivaree2)
    chivaree15={
         "type": "flex","altText": "☆•AVENGERS•☆","contents": { "type": "bubble",     
         "body": {"type": "box","layout": "vertical",   "contents": [{"type": "text","text": chivaree,"color": "#00ff00","align": "center","wrap": True,"size": "sm"},{"type": "text","text": "••• [ BOT TAG 🕒 " +datetime.today().strftime('%H:%M:%S')+ "™ ] •••","color": "#ffffff","align": "center","size": "xs"}]},
         "styles": {"body": {"backgroundColor": chivaree11},"footer": {"backgroundColor": "#ffffff","separator": True,"separatorColor": "#000000"}}}}
    sendTemplate(to, chivaree15)
def  ajangText(to, chivaree):
    chivaree14={
                 "type": "flex","altText": "☆•AVENGERS•☆","contents": { "type": "bubble",     
                "footer": {"type": "box","layout": "vertical",   "contents": [{"type": "text","text": chivaree,"color": "#00ff00","align": "center","wrap": True,"size": "xs"}]},
                "styles": {"body": {"backgroundColor": "#000000"},"footer": {"backgroundColor": "#000000","separator": True,"separatorColor": "#000000"}}}}
    sendTemplate(to, chivaree14)
def kittySend(to, chivaree):
    chivaree13={
          "type": "flex","altText": "• AVENGERS •","contents": {"type": "bubble","styles": {"footer": {"backgroundColor": "#000000"},},
          "footer": {"type": "box","layout": "vertical","spacing": "sm","contents": [{"type": "box","layout": "baseline","contents": [{
          "type": "icon","url": "https://obs.line-scdn.net/{}".format(line.getContact(lineMID).pictureStatus),"size": "lg"},{
          "type": "text","text": chivaree,"color":"#00ff00","gravity": "center","align":"center","wrap": True,"size": "sm"},{
          "type": "icon","url": "https://obs.line-scdn.net/{}".format(line.getContact(lineMID).pictureStatus),"size": "lg"},]}]}}}
    sendTemplate(to, chivaree13)    
def nn1(to, nn1):
    data={
"type": "flex",
"altText": nn1,
"contents": {
"type": "bubble",
"styles": {
"footer": {"backgroundColor": "#000000"},
},
"footer": {
"type": "box",
"layout": "vertical",
"spacing": "sm",
"contents": [
{
"type": "box",
"layout": "baseline",
"contents": [
{
"type": "icon",
"url": "https://obs.line-scdn.net/{}".format(line.getContact(lineMID).pictureStatus),
"size": "md"
},
{
"type": "text",
"text": nn1,
"color":"#CC0000",
"gravity": "center",
"align":"center",
"wrap": True,
"size": "md"
},
{
"type": "icon",
"url": "https://obs.line-scdn.net/{}".format(line.getContact(lineMID).pictureStatus),
"size": "md"
},
]
}
]
}
}
}
    sendTemplate(to, data)
def nn2 (to, nn2):
    data={
"type": "flex",
"altText": "AVENGERS",
"contents": { 
"type": "bubble",     
"header": {
"type": "box",
"layout": "vertical",   
"contents": [
{     
"type": "text",
"text": nn2,
"color": "#000000",
"align": "center"
}
]
},
"hero": {
"type": "image",
"url": "https://sv1.picz.in.th/images/2020/01/27/RX04Vq.png",
"size": "lg",
"action": {
"type":"uri","uri":"line://app/1602687308-GXq4Vvk9?type=text&text=ติดต่อ"}
}
},
"body": {
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "text",
"text": nn2,
"align": "center",
"size": "lg",
"color": "#000000",
"wrap": True,
"flex": 1
}
]
},
"footer": {
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "text",
"text": "AVENGERS BOT: 🕒 " +datetime.today().strftime('%H:%M:%S')+ "™",
"color": "#66FFFF",
"size": "xs",
"align": "center"
}
]
},
"styles": {
"header": {
"backgroundColor": "#000000"
},
"hero": {
"separator": True,
"separatorColor": "#000000",
},
"footer": {
"backgroundColor": "#000000",
"separator": True,
"separatorColor": "#FFFFFF"
},
"body": {
"backgroundColor": "#FFFFFF",                            
}
}
}
    sendTemplate(to, data)
#---------------------------------------------------------------------------------------------#
def Rapid1Say(mtosay):
    line.sendText(Rapid1To,mtosay)

def waktu(secs):
	mins, secs = divmod(secs,60)
	hours, mins = divmod(mins,60)
	days,hours = divmod(hours,24)
	return '%02d วัน %02d ชั่วโมง %02d นาที %02d วินาที' % (days, hours, mins, secs)
	
def sendCarousel(data):
    url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/SendMessage"
    data = data
    headers = {}
    headers['User-Agent'] = 'Mozilla/5.0 (Linux) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/67.0.3396.87 Mobile Safari/537.36 Line/8.10.1'
    headers['Content-Type'] = 'application/json'
    return requests.Session().post(url,data=json.dumps(data),headers=headers)
#===================== A-jang βot Time ====================================
def ajangTime(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours,24)
    return '%02d วัน\n───────────\n%02d ชั่วโมง\n───────────\n%02d นาที\n───────────\n' %(days ,hours, mins)

def kittyTime(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours,24)
    weeks, days = divmod(days,7)
    months, weeks = divmod(weeks,4)
    text = ""
    if months != 0: text += "%02d เดือน" % (months)
    if weeks != 0: text += " %02d สัปดาห์" % (weeks)
    if days != 0: text += " %02d วัน" % (days)
    if hours !=  0: text +=  " %02d ชั่วโมง" % (hours)
    if mins != 0: text += " %02d นาที" % (mins)
    if secs != 0: text += " %02d วินาที" % (secs)
    if text[0] == " ":
            text = text[1:]
    return text

def mentionMembers(to, mid):
    try:
        arrData = ""
        textx = "🗣จำนวนคนที่แทค {} คน🗣\n➫ ".format(str(len(mid)))
        arr = []
        no = 1
        for i in mid:
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention
            if no < len(mid):
                no += 1
                textx += "➫ "
            else:
                try:
                    textx += "➫ชื่อกลุ่ม   {} 🗣".format(str(line.getGroup(to).name))
                except:
                    pass
        line.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        logError(error)
        line.sendMessage(to, "[ INFO ] Error :\n" + str(error))
def summon(to, nama):
    aa = ""
    bb = ""
    strt = int(14)
    akh = int(14)
    nm = nama
    for mm in nm:
      akh = akh + 2
      aa += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(mm)+"},"""
      strt = strt + 6
      akh = akh + 4
      bb += "\xe2\x95\xa0 @x \n"
    aa = (aa[:int(len(aa)-1)])
    msg = Message()
    msg.to = to
    msg.text = "\xe2\x95\x94\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\n"+bb+"\xe2\x95\x9a\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90"
    msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+aa+']}','EMTVER':'4'}
    print ("TAG ALL")
    try:
       line.sendMessage(msg)
    except Exception as error:
       print(error)
#=========================================================================
def genImageB64(path):
    with open(path, 'rb') as img_file:
        encode_str = img_file.read()
        b64img = base64.b64encode(encode_str)
        return b64img.decode('utf-8')

def genUrlB64(url):
    return base64.b64encode(url.encode('utf-8')).decode('utf-8')
    
def change(url):
	import base64
	return base64.b64encode(url.encode()).decode()    
   
def command(text):
    pesan = text.lower()
    if pesan.startswith(settings["keyCommand"]):
        cmd = pesan.replace(settings["keyCommand"],"")
    else:
        cmd = "Undefined command"
    return cmd       

def sendMention(to, mid, firstmessage, lastmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        line.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        logError(error)
        line.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def sendSticker(to, version, packageId, stickerId):
    contentMetadata = {
        'STKVER': version,
        'STKPKGID': packageId,
        'STKID': stickerId
    }
    line.sendMessage(to, '', contentMetadata, 7)

def sendImage(to, path, name="image"):
    try:
        if settings["server"] == "VPS":
            line.sendImageWithURL(to, str(path))
    except Exception as error:
        logError(error)
#=================================

def restartBot():
    print ("RESTART SERVER")
    time.sleep(3)
    python = sys.executable
    os.execl(python, python, *sys.argv)
    
def logError(text):
    line.log("[ แจ้งเตือน ] " + str(text))
    time_ = datetime.now()
    with open("errorLog.txt","a") as error:
        error.write("\n[%s] %s" % (str(time), text))

        
def sendMessageWithMention(to, lineMID):
    try:
        aa = '{"S":"0","E":"3","M":'+json.dumps(lineMID)+'}'
        text_ = '@x '
        line.sendMessage(to, text_, contentMetadata={'MENTION':'{"MENTIONEES":['+aa+']}'}, contentType=0)
    except Exception as error:
        logError(error)
 
def myhelp():
    myHelp = """
" \n 🖌คำสั่งสำหรับบอทแทค🖌\n"
"\n╭──┅═ই۝ई═┅──\n"
"\n║✯͜͡➫ คำสั่ง [คำสั่งบอท]\n"
"\n║✯͜͡➫ บอท [ใช่สำหรับ@มินสั่ง]\n"
"\n║✯͜͡➫ ผส\n"
"\n║✯͜͡➫ สมาชิค\n"
"\n║✯͜͡➫ แทค\n"
"\n║✯͜͡➫ เทส\n"
"\n║✯͜͡➫ ดึง\n"
"\n║✯͜͡➫ เช็คกลุ่ม\n"
"\n║✯͜͡➫ แทคล่องหน\n"
"\n║✯͜͡➫ มินล่องหน\n"
"\n║✯͜͡➫ คทล่องหน\n"
"\n║✯͜͡➫ ออน\n"
"\n║✯͜͡➫ สปีด\n"
"\n║✯͜͡➫ ของขวัญ\n"
"\n║✯͜͡➫ แจก\n"
"\n║͜͡➫ Con  [เปิดดูคนแอบอ่าน]\n"
"\n║͜͡➫ Coff [ปิดดูคนแอบอ่าน]\n"
"\n║✯͜͡➫ ยกเชิญ\n"
"\n║✯͜͡➫ คทบอท\n"
"\n║✯͜͡➫ ชื่อบอท\n"
"\n║✯͜͡➫ ปกบอท\n"
"\n║✯͜͡➫ ตัสบอท\n"
"\n║✯͜͡➫ วีดีโอบอท\n"
"\n║✯͜͡➫ มิดบอท\n"
"\n║✯͜͡➫ดิสบอท\n"
"\n║✯͜͡➫ คทเพื่อน @\n"
"\n║✯͜͡➫ มิดเพื่อน @\n"
"\n║✯͜͡➫ ชื่อเพื่อน @\n"
"\n║✯͜͡➫ ตัสเพื่อน @\n"
"\n║✯͜͡➫ ดิสเพื่อน @\n"
"\n║✯͜͡➫ วิดีโอเพื่อน @\n"
"\n║✯͜͡➫ ปกเพื่อน @\n"
"\n║✯͜͡➫ คัดลอกปก @\n"
"\n║✯͜͡➫ คืนปก\n"
"\n║✯͜͡➫ ก๊อป @\n"
"\n║✯͜͡➫ mimic on/off [พูดตาม]\n"
"\n║✯͜͡➫ พูดตาม @\n"
"\n║✯͜͡➫ ลบพูดตาม @\n"
"\n║✯͜͡➫ เช็คพูดตาม\n"
"\n║✯͜͡➫ เพสโต\n"
"\n║✯͜͡➫ ยูทูป\n"
"\n║✯͜͡➫ ขอเพลง\n"
"\n║✯͜͡➫ github\n"
"\n║✯͜͡➫ google\n"
"\n║✯͜͡➫ เฟส\n"
"\n║✯͜͡➫ คท:\n"
"\n║✯͜͡➫ ค้นหาไอดี\n"
"\n║✯͜͡➫ Spam\n"
"\n║✯͜͡➫ หนัง\n"
"\n║✯͜͡➫ พูด\n"
"\n║✯͜͡➫ โทร\n"
"\n║✯͜͡➫ ไอดีกลุ่ม\n"
"\n║✯͜͡➫ ปกกลุ่ม\n"
"\n║✯͜͡➫ ชื่อกลุ่ม\n"
"\n║✯͜͡➫ ข้อมูลกลุ่ม\n"
"\n║✯͜͡➫ สมาชิคกลุ่ม\n"
"\n║✯͜͡➫ ข้อมูล @\n"
"\n║✯͜͡➫ รายชื่อบลอค\n"
"\n║✯͜͡➫ แอด  [ดูคนสร้างกลุ่ม]\n"
"\n║✯͜͡➫ วันที่\n"
"\n║✯͜͡➫ ภาพ\n"
"\n║✯͜͡➫ คนแอดบอท\n"
"\n║✯͜͡➫ Midสมาชิค\n"
"\n║✯͜͡➫ 18+\n"
"\n║✯͜͡➫ เชิญผส\n"
"\n╰──┅═ই۝ई═┅──\n"
"\nสมาชิคสามารถเล่นโต้ตอบกับบอทได้\n"
"\nจงพิม➫ให้ถูกคำสั่งด้านบนด้วย☝️\n"
"""
    return myHelp

def listgrup():
    listGrup =  """
   🖌คำสั่งสำหรับแอดมิน🖌
╭──┅═ই۝ई═┅──
║☠͜͡➫ เปิด/ปิด  รับแขก
║☠͜͡➫ เปิด/ปิด ส่งแขก
║☠͜͡➫ ตั้งเข้า:
║☠͜͡➫ ตั้งออก:
║☠͜͡➫ เชคเข้า
║☠͜͡➫ เชคออก
║☠͜͡➫ ทักเข้า
║☠͜͡➫ ทักออก
║☠͜͡➫ ลบดำ
║☠͜͡➫ ลงดำ
║☠͜͡➫ แก้ขาว
║☠͜͡➫ ตั้งแอด
║☠͜͡➫ ลบแอด
║☠͜͡➫ เชคแอด
║☠͜͡➫ ยกเชิญ
║☠͜͡➫ รีบอท
║☠͜͡➫ ออน
║☠͜͡➫ ข้อมูลบอท
║☠͜͡➫ เชคค่าบอท
║☠͜͡➫ เปิดบลอค
║☠͜͡➫ ปิดบลอค
║☠͜͡➫ เปิดเข้า
║☠͜͡➫ ปิดเข้า
║☠͜͡➫ เปิดมุด
║☠͜͡➫ ปิดมุด
║☠͜͡➫ เปิดยกเลิก
║☠͜͡➫ ปิดยกเลิก
║☠͜͡➫ เปิดหวด
║☠͜͡➫ ปิดหวด
║☠͜͡➫ เปิดเชคติ๊ก
║☠͜͡➫ ปิดเชคติ๊ก
║☠͜͡➫ ล้างห้อง
║☠͜͡➫ สวย น่ารัก
║☠͜͡➫ ลบสิริ
║☠͜͡➫ ประกาศ
║☠͜͡➫ แชทเพื่อน
║☠͜͡➫ บอทออก
║☠͜͡➫ บอทออกทุกกลุ่ม
║☠͜͡➫ โทร
║☠͜͡➫ เพลง
║☠͜͡➫ ถถถ
║☠͜͡➫ เปิดลิ้ง
║☠͜͡➫ ปิดลิ้ง
║☠͜͡➫ ลิ้ง
║☠͜͡➫ ลบรัน
║☠͜͡➫ ลบแชท 
╰──┅═ই۝ई═┅──
ให้ใส่➫( / )นำหน้าก่อนสั่งนะ
สั้งได้แอดมินกับVIPเท่านั้น"""
    return listGrup
#==============================================================================#
def lineBot(op):
    try:
        if op.type == 0:
            return
        if op.type == 5:
            if setmybot["autoAdd"] == True:
                line.blockContact(op.param1)
            if setmybot["autoBlock"] == True:
                chivaree = "https://sv1.picz.in.th/images/2019/08/17/Z9vipQ.jpg"
                time.sleep(0.004)
                line.blockContact(op.param1)
                line.sendImageWithURL(op.param1, chivaree)
                line.sendMessage(op.param1, "🐷ระบบออโต้บล็อคทำงาน🐷\nบัญชีไลนนี้ถูกป้องกันด้วย\n™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣\nระบบได้บล็อคคุณ อัตโนมัติ\n\n😐หากสนใจติดบอทรอสักครู่😐")
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------#        
        if op.type == 11:
            if op.param1 in protectqr:
                try:
                    if line.getGroup(op.param1).preventedJoinByTicket == False:
                        if op.param2 not in Bot:
                            line.reissueGroupTicket(op.param1)
                            X = line.getGroup(op.param1)
                            X.preventedJoinByTicket = True
                            line.updateGroup(X)
                            line.kickoutFromGroup(op.param1,[op.param2])
                            line.sendMessage(op.param1, None, contentMetadata={'mid': op.param2}, contentType=13)
                except:
                    pass
        if op.type == 11:    
        	if line.getGroup(op.param1).preventedJoinByTicket == False:
        	   nn2(op.param1,"พบการเปลี่ยนการตั้งค่ากลุ่ม")                
        if op.type == 13:
            if op.param1 in protectinvite:
                if op.param2 not in Bot:
                    try:
                        group = line.getGroup(op.param1)
                        gMembMids = [contact.mid for contact in group.invitee]
                        for _mid in gMembMids:
                            line.cancelGroupInvitation(op.param1,[_mid])
                            line.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        pass  
        if op.type == 17:
            if op.param1 in protectjoin:
                if op.param2 not in Bot:
                    settings["blacklist"][op.param2] = True
                    try:
                        if op.param3 not in settings["blacklist"]:
                            line.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        pass
                return   
        if op.type == 19:
            if op.param1 in protectkick:
                if op.param2 not in Bot:
                    settings["blacklist"][op.param2] = True
                    line.kickoutFromGroup(op.param1,[op.param2])
                else:
                    pass     
#==========================================================================
        if op.type == 13:
            if lineMID in op.param3:
                chivaree2019 = line.getGroup(op.param1)
                if setmybot["autoJoin"] == True:
                    if setmybot["autoCancel"]["on"] == True:
                        if len(chivaree2019.members) <= setmybot["autoCancel"]["members"]:
                            line.rejectGroupInvitation(op.param1)
                        else:
                            line.acceptGroupInvitation(op.param1)
                    else:
                        line.acceptGroupInvitation(op.param1)
                elif setmybot["autoCancel"]["on"] == True:
                    if len(chivaree2019.members) <= setmybot["autoCancel"]["members"]:
                        time.sleep(random.uniform(4.5,5.0))
                        line.rejectGroupInvitation(op.param1)
                        print ("• ระบบกินห้องรันทำงานคับ •")
                    else:
                    	pass
            else:
                Inviter = op.param3.replace("",',')
                InviterX = Inviter.split(",")
                matched_list = []
                for tag in setmybot["blacklist"]:
                    matched_list+=[str for str in InviterX if str == tag]
                if matched_list == []:
                    pass
                else:
                    line.cancelGroupInvitation(op.param1, matched_list)        
#==================================				
        if op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0:
                if sender != line.profile.mid:
                    to = sender
                else:
                    to = receiver
            else:
                to = receiver
            
        if op.type == 24:
            print ("[ 24 ] ออกแชทรวมแล้ว")
            if setmybot["autoLeave"] == True:
                line.leaveRoom(op.param1)
                
        if op.type == 25:
            msg = op.message           

        if op.type == 16:
                gname = line.getGroup(op.param1).name
                line.sendText(admin,"บอทได้เข้าร่วมกลุ่ม\n"+gname+"\n")
                line.sendText(admin,op.param1)
        if op.type == 14:
                gname = line.getGroup(op.param1).name
                line.sendText(admin,"บอทออกจากกลุ่ม\n"+gname+"\n")
        if op.type == 25:
            msg = op.message
            if msg.contentType == 13:
                if settings["wblack"] == True:
                    if msg.contentMetadata["mid"] in settings["commentBlack"]:
                        line.sendMessage(msg.to,"sudah masuk daftar hitam")
                        settings["wblack"] = False
                    else:
                        settings["commentBlack"][msg.contentMetadata["mid"]] = True
                        settings["wblack"] = False
                        line.sendMessage(msg.to,"Itu tidak berkomentar")
                elif settings["dblack"] == True:
                    if msg.contentMetadata["mid"] in settings["commentBlack"]:
                        del settings["commentBlack"][msg.contentMetadata["mid"]]
                        line.sendMessage(msg.to,"Done")
                        settings["dblack"] = False
                    else:
                        settings["dblack"] = False
                        line.sendMessage(msg.to,"Tidak ada dalam daftar hitam")
#-------------------------------------------------------------------------------
                elif settings["wblacklist"] == True:
                    if msg.contentMetadata["mid"] in settings["blacklist"]:
                        line.sendMessage(msg.to,"sudah masuk daftar hitam")
                        settings["wblacklist"] = False
                    else:
                        settings["blacklist"][msg.contentMetadata["mid"]] = True
                        settings["wblacklist"] = False
                        line.sendMessage(msg.to,"ยัดดำเรียบร้อย")
                        
                elif settings["dblacklist"] == True:
                    if msg.contentMetadata["mid"] in settings["blacklist"]:
                        del settings["blacklist"][msg.contentMetadata["mid"]]
                        line.sendMessage(msg.to,"แก้ขาวเรียบร้อย")
                        settings["dblacklist"] = False
                    else:
                        settings["dblacklist"] = False
                        line.sendMessage(msg.to,"แก้ขาวแล้ว")

#-------------------------------------------------------------------------------
        if op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0:
                if sender != line.profile.mid:
                    to = sender
                else:
                    to = receiver
            else:
                to = receiver
            if msg.contentType == 0:
                if text is None:
                    return
#==============================================================================#                
#เปิดปิดต้อนรับ
                elif msg.text.lower() == 'เปิดต้อนรับ':
                        if setmybot["Wc"] == True:
                            if setmybot["lang"] == "JP":
                                nn2(to,"🔊เปิดข้อความต้อนรับ🔊")
                        else:
                            setmybot["Wc"] = True
                            if setmybot["lang"] == "JP":
                                nn2(to,"🔊เปิดข้อความต้อนรับ🔊")
                elif msg.text.lower() == 'ปิดต้อนรับ':
                        if setmybot["Wc"] == False:
                            if setmybot["lang"] == "JP":
                                nn2(to,"🔇ปิดข้อความต้อนรับ🔇")
                        else:
                            setmybot["Wc"] = False
                            if setmybot["lang"] == "JP":
                                nn2(to,"🔇ปิดข้อความต้อนรับ🔇")
#เปิดปิดคนออก
                elif msg.text.lower() == 'เปิดคนออก':
                        if settings["Lv"] == True:
                            if settings["lang"] == "JP":
                                nn2(to,"🔊เปิดข้อความคนออกกลุ่ม🔊")
                        else:
                            settings["Lv"] = True
                            if settings["lang"] == "JP":
                                nn2(to,"🔊เปิดข้อความคนออกกลุ่ม🔊")
                elif msg.text.lower() == 'ปิดคนออก':
                        if settings["Lv"] == False:
                            if settings["lang"] == "JP":
                                nn2(to,"🔇ปิดข้อความคนออกกลุ่ม🔇")
                        else:
                            settings["Lv"] = False
                            if settings["lang"] == "JP":
                                nn2(to,"🔇ปิดข้อความคนออกกลุ่ม🔇")               
#เปิดปิดทักเตะ
                elif msg.text.lower() == 'เปิดทักเตะ':
                        if setmybot["Nk"] == True:
                            if setmybot["lang"] == "JP":
                                nn2(to,"🔊เปิดข้อความทักคนเตะ🔊")
                        else:
                            setmybot["Nk"] = True
                            if setmybot["lang"] == "JP":
                                nn2(to,"🔊เปิดข้อความทักคนเตะ🔊")
                elif msg.text.lower() == 'ปิดทักเตะ':
                        if setmybot["Nk"] == False:
                            if setmybot["lang"] == "JP":
                                nn2(to,"🔇ปิดข้อความทักคนเตะ🔇")
                        else:
                            setmybot["Nk"] = False
                            if setmybot["lang"] == "JP":
                                nn2(to,"🔇ปิดข้อความทักคนเตะ🔇")            
#เปิดปิดแทค
                elif msg.text.lower() == 'เปิดแทค':
                        if setmybot["detectMention"] == True:
                            if setmybot["lang"] == "JP":
                                nn2(to,"🔊เปิดข้อความตอบแทค🔊")
                        else:
                            setmybot["detectMention"] = True
                            if setmybot["lang"] == "JP":
                                nn2(to,"🔊เปิดข้อความตอบแทค🔊")
                elif msg.text.lower() == 'ปิดแทค':
                        if setmybot["detectMention"] == False:
                            if setmybot["lang"] == "JP":
                                nn2(to,"🔇ปิดข้อความตอบแทค🔇")
                        else:
                            setmybot["detectMention"] = False
                            if setmybot["lang"] == "JP":
                                nn2(to,"🔇ปิดข้อความตอบแทค🔇")                 
#เปิดปิดแทคสติ้กเกอร์
                elif msg.text.lower() == 'เปิดแทค2':
                        if setmybot["potoMention"] == True:
                            if setmybot["lang"] == "JP":
                                nn2(to,"🔊เปิดแทคสติ้กเกอร์🔊")
                        else:
                            setmybot["potoMention"] = True
                            if setmybot["lang"] == "JP":
                                nn2(to,"🔊เปิดแทคสติ้กเกอร์🔊")
                elif msg.text.lower() == 'ปิดแทค2':
                        if setmybot["potoMention"] == False:
                            if setmybot["lang"] == "JP":
                                nn2(to,"🔇ปิดแทคสติ้กเกอร์🔇")
                        else:
                            setmybot["potoMention"] = False
                            if setmybot["lang"] == "JP":
                                nn2(to,"🔇ปิดแทคสติ้กเกอร์🔇")   
#เปิดปิดออกแชท
                elif msg.text.lower() == 'เปิดออก':
                        if setmybot["autoLeave"] == True:
                            if setmybot["lang"] == "JP":
                                nn2(to,"🔊เปิดออกแชทรวม🔊")
                        else:
                            setmybot["autoLeave"] = True
                            if setmybot["lang"] == "JP":
                                nn2(to,"🔊เปิดออกแชทรวม🔊")
                elif msg.text.lower() == 'ปิดออก':
                        if setmybot["autoLeave"] == False:
                            if setmybot["lang"] == "JP":
                                nn2(to,"🔇ปิดออกแชทรวม🔇")
                        else:
                            setmybot["autoLeave"] = False
                            if setmybot["lang"] == "JP":
                                nn2(to,"🔇ปิดออกแชทรวม🔇")             
#เปิดปิดอ่าน
                elif msg.text.lower() == 'เปิดอ่าน':
                        if setmybot["autoRead"] == True:
                            if setmybot["lang"] == "JP":
                                nn2(to,"🔊เปิดอ่านข้อความ🔊")
                        else:
                            setmybot["autoRead"] = True
                            if setmybot["lang"] == "JP":
                                nn2(to,"🔊เปิดอ่านข้อความ🔊")
                elif msg.text.lower() == 'ปิดอ่าน':
                        if setmybot["autoRead"] == False:
                            if setmybot["lang"] == "JP":
                                nn2(to,"🔇ปิดอ่านข้อความ🔇")
                        else:
                            setmybot["autoRead"] = False
                            if setmybot["lang"] == "JP":
                                nn2(to,"🔇ปิดอ่านข้อความ🔇")       
#เปิดปิดกันรัน                  
                elif msg.text in ["เปิดกินห้อง","เปิดกันรัน"]:
                    setmybot["autoCancel"]["on"] = True
                    nn2(to, "❂•เปิดระบบกินห้องรัน•")   
                    
                elif msg.text in ["ปิดกินห้อง","ปิดกันรัน"]:
                    setmybot["autoCancel"]["on"] = False
                    nn2(to, "❂•ปิดระบบกินห้องกัน•")   
#เปิดเข้าปิดเข้า                    
                elif msg.text in ["เอจังเปิดเข้า","เปิดเข้า"]:
                    settings["autoJoin"] = True
                    nn2(to, "❂•เปิดเข้ากลุ่มอัติโนมัติ•")
                elif msg.text in ["เอจังปิดเข้า","ปิดเข้า"]:
                    settings["autoJoin"] = False
                    nn2(to, "❂•ปิดเข้ากลุ่มอัติโนมัติ•")
#===========================================================================================================
                elif msg.text in ["เอจังเปิดบล็อค","เปิดบล็อค","เปิดบล็อก","เปิดบล๊อค"]:
                    setmybot["autoBlock"] = True
                    setmybot["autoAdd"] = True
                    nn2(to, "❂ 🌟เปิดระบบออโต้บล็อค🌟❂")
                    
                elif msg.text in ["เอจังปิดบล็อค","ปิดบล็อค","ปิดบล็อก","ปิดบล๊อค"]:
                    setmybot["autoBlock"] = False
                    setmybot["autoAdd"] = False
                    nn2(to, "❂ 🌟ปิดระบบออโต้บล็อค🌟❂")                    
#----------------------------------------------------------------------------------------------------------#                    
                elif text.lower() == 'เปิดไลค์':
                    settings["chivareeLike"] = True
                    chivaree15={
                       "type": "flex","altText": "☆•A-jang Test•☆","contents": { "type": "bubble",     
                       "body": {"type": "box","layout": "vertical",   "contents": [{"type": "text","text": "•••🌟🌟เปิดระบบออโต้ไลค์🌟🌟•••","color": "#ff0099","align": "center","size": "sm"}]},
                       "styles": {"body": {"backgroundColor": "#87CEEB"},"footer": {"backgroundColor": "#ffffff","separator": True,"separatorColor": "#000000"}}}}
                    sendTemplate(to, chivaree15)
#----------------------------------------------------------------------------------------------------------#                    
                elif text.lower() == 'ปิดไลค์':
                    settings["chivareeLike"] = False
                    chivaree15={
                       "type": "flex","altText": "☆•A-jang Test•☆","contents": { "type": "bubble",     
                       "body": {"type": "box","layout": "vertical",   "contents": [{"type": "text","text": "•••🌟🌟เปิดระบบออโต้ไลค์🌟🌟•••","color": "#ff0099","align": "center","size": "sm"}]},
                       "styles": {"body": {"backgroundColor": "#87CEEB"},"footer": {"backgroundColor": "#ffffff","separator": True,"separatorColor": "#000000"}}}}
                    sendTemplate(to, chivaree15)      
#------------------[เปิด-ปิดป้องกัน]--------------------------------------------------------#                   
                elif 'กันลิ้ง ' in msg.text:
                      spl = msg.text.replace('กันลิ้ง ','')
                      if spl == 'เปิด':
                          if msg.to in protectqr:
                              msgs = "เปิดระบบกันลิ้ง"
                          else:
                              protectqr.append(msg.to)
                              ginfo = line.getGroup(msg.to)
                              msgs = "เปิดระบบกันลิ้ง\n ประจำกลุ่ม : " +str(ginfo.name)
                          kittyText(msg.to, "「พร้อมใช้งานแล้ว」\n" + msgs)                          
                      elif spl == 'ปิด':
                           if msg.to in protectqr:
                               protectqr.remove(msg.to)
                               ginfo = line.getGroup(msg.to)
                               msgs = "ปิดระบบกันลิ้ง\n ประจำกลุ่ม : " +str(ginfo.name)
                           else:
                               msgs = "ปิดระบบกันลิ้ง"
                           kittyText(msg.to, "「ปิดใช้งาน」\n" + msgs)
                    
                elif 'กันเชิญ ' in msg.text:
                      spl = msg.text.replace('กันเชิญ ','')
                      if spl == 'เปิด':
                          if msg.to in protectinvite:
                              msgs = "เปิดระบบกันคนเชิญ"
                          else:
                              protectinvite.append(msg.to)
                              ginfo = line.getGroup(msg.to)
                              msgs = "เปิดระบบกันคนเชิญ\n ประจำกลุ่ม : " +str(ginfo.name)
                          kittyText(msg.to, "「พร้อมใช้งานแล้ว」\n" + msgs)                          
                      elif spl == 'ปิด':
                           if msg.to in protectinvite:
                               protectinvite.remove(msg.to)
                               ginfo = line.getGroup(msg.to)
                               msgs = "ปิดระบบกันคนเชิญ\n ประจำกลุ่ม : " +str(ginfo.name)
                           else:
                               msgs = "ปิดระบบกันคนเชิญ"
                           kittyText(msg.to, "「ปิดใช้งาน」\n" + msgs)     
                         
                elif 'กันเตะ ' in msg.text:
                      spl = msg.text.replace('กันเตะ ','')
                      if spl == 'เปิด':
                          if msg.to in protectkick:
                              msgs = "เปิดระบบกันคนเตะ"
                          else:
                              protectkick.append(msg.to)
                              ginfo = line.getGroup(msg.to)
                              msgs = "เปิดระบบกันคนเตะ\n ประจำกลุ่ม : " +str(ginfo.name)
                          kittyText(msg.to, "「พร้อมใช้งานแล้ว」\n" + msgs)                          
                      elif spl == 'ปิด':
                           if msg.to in protectkick:
                               protectkick.remove(msg.to)
                               ginfo = line.getGroup(msg.to)
                               msgs = "ปิดระบบกันคนเตะ\n ประจำกลุ่ม : " +str(ginfo.name)
                           else:
                               msgs = "ปิดระบบกันคนเตะ"
                           kittyText(msg.to, "「ปิดใช้งาน」\n" + msgs)                    
#==============================================================================#

                elif text.lower() == '/ลบดำ':
                    if msg._from in admin:
                        settings["blacklist"] = {}
                        line.sendMessage(msg.to,"ลบบัชชีดำทั้งหมดเรียบร้อย")
                        
                elif text.lower() == '/ลงดำ':
                    if msg._from in admin:
                        settings["wblacklist"] = True
                        line.sendMessage(msg.to,"ส่ง คท คนทีจะยัดดำ")
                        
                elif msg.text in [  ]:
                    if msg._from in admin:
                        settings["dblacklist"] = True
                        line.sendMessage(msg.to,"ส่ง คท คนทีจะแก้ดำ")
#-------------ชุดคำสั่ง------------------------------------------------------------------                                 
                elif msg.text in ["me","Me"]:
                                chivaree = line.getContact(msg._from)
                                line.reissueUserTicket()
                                chivaree11 = {
                                 "type": "flex",
                                 "altText": "{} cangkemu".format(str(chivaree.displayName)),
                                 "contents": {
                                  "type": "bubble",
                                  "styles": {
                                    "header": {
                                      "backgroundColor": "#66FFFF",
                                    },
                                    "body": {
                                      "backgroundColor": "#66FFFF",
                                      "separator": True,
                                      "separatorColor": "#66FFFF"
                                    },
                                    "footer": {
                                      "backgroundColor": "#66FFFF",
                                      "separator": True
                                    }
                                  },
                                  "header": {
                                    "type": "box",
                                    "layout": "horizontal",
                                    "contents": [
                                      {
                                        "type": "text",
                                        "align":"center",
                                        "text": "Your Profile Picture",
                                        "weight": "bold",
                                        "color": "#000000",
                                        "size": "md"
                                      }
                                    ]
                                  },
                                  "hero": {
                                    "type": "image",
                                    "url": "https://os.line.naver.jp/os/p/{}".format(msg._from),
                                    "size": "full",
                                    "aspectRatio": "20:13",
                                    "aspectMode": "cover",
                                    "action": {
                                      "type": "uri",
                                      "uri": "https://line://ti/p/~0969245004"
                                    }
                                  },
                                  "body": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "spacing": "md",
                                    "action": {
                                      "type": "uri",
                                      "uri": "http://line.me/ti/p/~0969245004"
                                    },
                                    "contents": [
                                      {
                                        "type": "text",
                                        "align":"center",
                                        "text": "💓🐷  BOT TAG 2020  🐷💓",
                                        "size": "md",
                                        "color": "#000000"
                                      },
                                      {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [
                                          {
                                            "type": "box",
                                            "layout": "baseline",
                                            "contents": [
                                              {
                                                "type": "icon",
                                                "url": "https://os.line.naver.jp/os/p/{}".format(msg._from),
                                                "size": "5xl"
                                              },
                                              {
                                                "type": "text",
                                                "text": "ชื่อคุณ :",
                                                "weight": "bold",
                                                "color": "#000000",
                                                "margin": "sm",
                                                "flex": 0
                                              },
                                              {
                                                "type": "text",
                                                "text": chivaree.displayName,
                                                "size": "sm",
                                                "align": "end",
                                                "color": "#000000"
                                              }
                                            ]
                                          },
                                          {
                                            "type": "box",
                                            "layout": "baseline",
                                            "contents": [
                                              {
                                                "type": "icon",
                                                "url": "https://sv1.picz.in.th/images/2020/01/28/RpCOvI.png",
                                                "size": "5xl"
                                              },
                                              {
                                                "type": "text",
                                                "text": "𝐀𝐃𝐌𝐈𝐍 :",
                                                "weight": "bold",
                                                "color": "#000000",
                                                "margin": "sm",
                                                "flex": 0
                                              },
                                              {
                                                "type": "text",
                                                "text": "꧁͜͡NN꧂",
                                                "size": "sm",
                                                "align": "end",
                                                "color": "#000000"
                                              }
                                            ]
                                          },
                                          {
                                            "type": "box",
                                            "layout": "baseline",
                                            "contents": [
                                              {
                                                "type": "icon",
                                                "url": "https://sv1.picz.in.th/images/2020/01/28/RpCOvI.png",
                                                "size": "5xl"
                                              },
                                              {
                                                "type": "text",
                                                "text": "𝐂𝐑𝐄𝐀𝐓𝐎𝐑 :",
                                                "margin": "sm",
                                                "color": "#000000",
                                                "weight": "bold",
                                                "flex": 0
                                              },
                                              {
                                                "type": "text",
                                                "text": "꧁͜͡NN꧂",
                                                "size": "sm",
                                                "align": "end",
                                                "color": "#000000"
                                              }]}]},
                                      {
                                        "type": "text",
                                        "text": "™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣",
                                        "wrap": True,
                                        "color": "#000000",
                                        "size": "xxs"
                                      }
                                    ]
                                  },
                                  "footer": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "contents": [
                                      {
                                        "type": "spacer",
                                        "size": "sm"
                                      },
                                      {
                                        "type": "button",
                                        "style": "primary",
                                        "color": "#000000",
                                        "action": {
                                          "type": "uri",
                                          "label": "𝐌𝐘 𝐂𝐎𝐍𝐓𝐀𝐂𝐓",
                                          "uri": "https://line.me/ti/p/"+line.getUserTicket().id
                                }}]}}}
                                sendTemplate(to, chivaree11)                                               
 #======================================================================
                elif msg.text in ["คำสั่งพิเศษ"]:
                            contact = line.getContact(lineMID)
                            sender_profile = line.getContact(sender)
                            dataProfile = [
                                {
                                    "type": "bubble",
                                    "styles": {
                                        "header": {"backgroundColor": "#66FFFF"},
                                         "hero": {"backgroundColor": "#66FFFF"},
                                        "body": {"backgroundColor": "#FFFFFF", "separator": True, "separatorColor": "#000000"},
                                        "footer": {"backgroundColor": "#66FFFF", "separator": True, "separatorColor": "#000000"}
                                    },
                                    "header": {
                                            "type": "box",
                                            "layout": "baseline",
                                            "contents": [
                                                    {
                                                        "type": "icon",
                                                        "url": 'https://sv1.picz.in.th/images/2020/01/29/RGP7vS.png',
                                                        "size":"xxl"
                                                    },
                                                   {
                                                    "type": "text",
                                                    "text": "™ BOT TAG 2020",
                                                     "margin": "xxl",
                                                    "weight": "bold",
                                                    "color": "#000000",
                                                    "size": "md"
                                            }  
                                        ]    
                                    },
                                    "hero": {
                                        "type": "image",
                                         "url": "https://sv1.picz.in.th/images/2020/01/29/RGPB02.png",
                                         "size": "xl",
                                        "action": {
                                             "type":"uri","uri":"line://app/1602687308-GXq4Vvk9?type=image&img=https://sv1.picz.in.th/images/2019/08/07/KIzyak.jpg"
                                    }
                                   },
                                    "body": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                  "type": "text",
                                                "text": "••••••🐷❤ คำสั่งทั่วไป ❤🐷••••••",
                                                "size": "md",
                                                 "align": "center",
                                                 "color": "#000000",
                                                 'flex': 1,
                                             },
                                            {
                                                "type": "text",
                                                "text": "•♡• Me",
                                                "size": "sm",
                                                "color": "#000000",
                                                'flex': 1,
                                            },
                                            {
                                                 "type": "text",
                                                "text": "•♡• เชคค่า",
                                                "size": "sm",
                                                 "color": "#000000",
                                                 'flex': 1,
                                             },
                                            {
                                                "type": "text",
                                                "text": "•♡• แทค",
                                                "size": "sm",
                                                "color": "#000000",
                                                'flex': 1,
                                            },
                                            {
                                                 "type": "text",
                                                 "text": "•♡• ออน",
                                                 "size": "sm",
                                                 "color": "#000000",
                                                 'flex': 1,
                                             },
                                            {
                                                "type": "text",
                                                "text": "•♡• สปีด",
                                                "size": "sm",
                                                "color": "#000000",
                                                'flex': 1,
                                            },
                                            {
                                                "type": "text",
                                                "text": "•♡• คท",
                                                "size": "sm",
                                                "color": "#000000",
                                                'flex': 1,
                                            },
                                            {
                                                 "type": "text",
                                                "text": "•♡• ข้อมูล",
                                                "size": "sm",
                                                 "color": "#000000",
                                                 'flex': 1,
                                             },
                                            {
                                                "type": "text",
                                                "text": "•♡• ข้อมูลกลุ่ม",
                                                "size": "sm",
                                                "color": "#000000",
                                                'flex': 1,
                                            },
                                            {
                                                 "type": "text",
                                                "text": "•♡• ยูทูป [ข้อความ]",
                                                "size": "sm",
                                                 "color": "#000000",
                                                 'flex': 1,
                                             },
                                            {
                                                "type": "text",
                                                "text": "•♡• เทสบอท",
                                                "size": "sm",
                                                "color": "#000000",
                                                'flex': 1,
                                            },
                                            {
                                                 "type": "text",
                                                "text": "•♡• แอดมิน",
                                                "size": "sm",
                                                 "color": "#000000",
                                                 'flex': 1,
                                             },
                                            {
                                                "type": "text",
                                                "text": "•♡• ผส",
                                                "size": "sm",
                                                "color": "#000000",
                                                'flex': 1,                
                                             }
                                        ]
                                    },
                                    "footer": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [
                                            {
                                                "type": "button",
                                                "style": "link",
                                                "height": "sm",
                                                "action": {
                                                    "type": "uri",
                                                    "label": "🌟      BOT TAG 2020      🌟",
                                                     "uri":"https://line.me/ti/p/~0969245004"
                                                      }
                                                    },
                                                    {
                                                        "type": "spacer",
                                                        "size": "sm",
                                              }
                                        ]
                                   }
                                },
                                {
                                    "type": "bubble",
                                    "styles": {
                                        "header": {"backgroundColor": "#66FFFF"},
                                         "hero": {"backgroundColor": "#66FFFF"},
                                        "body": {"backgroundColor": "#FFFFFF", "separator": True, "separatorColor": "#000000"},
                                        "footer": {"backgroundColor": "#66FFFF", "separator": True, "separatorColor": "#000000"}
                                    },
                                    "header": {
                                            "type": "box",
                                            "layout": "baseline",
                                            "contents": [
                                                    {
                                                        "type": "icon",
                                                        "url": 'https://sv1.picz.in.th/images/2020/01/29/RGP7vS.png',
                                                        "size":"xxl"
                                                    },
                                                   {
                                                    "type": "text",
                                                    "text": "™ BOT TAG 2020",
                                                     "margin": "xxl",
                                                    "weight": "bold",
                                                    "color": "#000000",
                                                    "size": "md"
                                            }  
                                        ]    
                                    },
                                    "hero": {
                                        "type": "image",
                                         "url": "https://sv1.picz.in.th/images/2020/01/29/RGPXg2.png",
                                         "size": "xl",
                                        "action": {
                                             "type":"uri","uri":"line://app/1602687308-GXq4Vvk9?type=image&img=https://sv1.picz.in.th/images/2019/08/07/KIzyak.jpg"
                                    }
                                   },
                                    "body": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                  "type": "text",
                                                "text": "••••••🐷💗 คำสั่งทั่วไป 💗🐷••••••",
                                                "size": "md",
                                                 "align": "center",
                                                 "color": "#000000",
                                                 'flex': 1,
                                             },
                                            {
                                                "type": "text",
                                                "text": "•♡• ติดต่อ",
                                                "size": "sm",
                                                 "color": "#000000",
                                                 'flex': 1,
                                             },
                                             {
                                                 "type": "text",
                                                "text": "•♡• เขียน [ข้อความ]",
                                                "size": "sm",
                                                 "color": "#000000",
                                                 'flex': 1,
                                             },
                                            {
                                                "type": "text",
                                                "text": "•♡• แจกๆ",
                                                "size": "sm",
                                                "color": "#000000",
                                                'flex': 1,
                                            },
                                            {
                                                 "type": "text",
                                                "text": "•♡• ดิส @",
                                                "size": "sm",
                                                 "color": "#000000",
                                                 'flex': 1,
                                             },
                                            {
                                                "type": "text",
                                                "text": "•♡• ปก @",
                                                "size": "sm",
                                                "color": "#000000",
                                                'flex': 1,
                                            },
                                            {
                                                 "type": "text",
                                                "text": "•♡• มิด @",
                                                "size": "sm",
                                                 "color": "#000000",
                                                 'flex': 1,
                                             },
                                            {
                                                "type": "text",
                                                "text": "•♡• ชื่อ @",
                                                "size": "sm",
                                                "color": "#000000",
                                                'flex': 1,
                                            },
                                            {
                                                 "type": "text",
                                                "text": "•♡• ตัส @",
                                                "size": "sm",
                                                 "color": "#000000",
                                                 'flex': 1,
                                             },
                                            {
                                                 "type": "text",
                                                "text": "•♡• ข้อมูล @",
                                                "size": "sm",
                                                 "color": "#000000",
                                                 'flex': 1,
                                             },
                                            {
                                                 "type": "text",
                                                "text": "•♡• สแปมแทค [จำนวน] @",
                                                "size": "sm",
                                                 "color": "#000000",
                                                 'flex': 1,
                                             },
                                            {
                                                 "type": "text",
                                                "text": "•♡• Spam on [จำนวน] ข้อความ",
                                                "size": "sm",
                                                 "color": "#000000",
                                                 'flex': 1,
                                             },
                                            {
                                                 "type": "text",
                                                "text": "•♡• เพลง [ข้อความ]",
                                                "size": "sm",
                                                 "color": "#000000",
                                                 'flex': 1,
                                             }
                                        ]
                                    },
                                    "footer": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [
                                            {
                                                "type": "button",
                                                "style": "link",
                                                "height": "sm",
                                                "action": {
                                                    "type": "uri",
                                                    "label": "🌟      BOT TAG 2020      🌟",
                                                     "uri":"https://line.me/ti/p/~0969245004"
                                                      }
                                                    },
                                                    {
                                                        "type": "spacer",
                                                        "size": "sm",
                                              }
                                        ]
                                   }
                                },
                                {
                                    "type": "bubble",
                                    "styles": {
                                        "header": {"backgroundColor": "#66FFFF"},
                                        "hero": {"backgroundColor": "#66FFFF"},
                                        "body": {"backgroundColor": "#FFFFFF", "separator": True, "separatorColor": "#000000"},
                                        "footer": {"backgroundColor": "#66FFFF", "separator": True, "separatorColor": "#000000"}
                                    },
                                    "header": {
                                            "type": "box",
                                            "layout": "baseline",
                                            "contents": [
                                                    {
                                                        "type": "icon",
                                                        "url": 'https://sv1.picz.in.th/images/2020/01/29/RGP7vS.png',
                                                        "size":"xxl"
                                                    },
                                                   {
                                                    "type": "text",
                                                    "text": "™ BOT TAG 2020",
                                                     "margin": "xxl",
                                                    "weight": "bold",
                                                    "color": "#000000",
                                                    "size": "md"
                                            }  
                                        ]    
                                    },
                                    "hero": {
                                        "type": "image",
                                         "url": "https://sv1.picz.in.th/images/2020/01/29/RGs0IR.png",
                                         "size": "xl",
                                        "action": {
                                             "type":"uri","uri":"line://app/1602687308-GXq4Vvk9?type=image&img=https://sv1.picz.in.th/images/2019/08/07/KIzyak.jpg"
                                    }
                                   },
                                    "body": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                  "type": "text",
                                                "text": "••••••🐷💗 คำสั่งทั่วไป 💗🐷••••••",
                                                "size": "md",
                                                 "align": "center",
                                                 "color": "#000000",
                                                 'flex': 1,
                                             },
                                            {
                                                "type": "text",
                                                "text": "•♡• /ประกาศ [ข้อความ]",
                                                "size": "sm",
                                                 "color": "#000000",
                                                 'flex': 1,
                                             },
                                            {
                                                 "type": "text",
                                                "text": "•♡• ประกูด [ข้อความ]",
                                                "size": "sm",
                                                 "color": "#000000",
                                                 'flex': 1,
                                             },
                                             {
                                                 "type": "text",
                                                "text": "•♡• กูเกิ้ล [ข้อความ]",
                                                "size": "sm",
                                                 "color": "#000000",
                                                 'flex': 1,
                                             },
                                            {
                                                "type": "text",
                                                "text": "•♡• เฟส [ข้อความ]",
                                                "size": "sm",
                                                "color": "#000000",
                                                'flex': 1,
                                            },
                                            {
                                                 "type": "text",
                                                "text": "•♡• ขอเพลง [ข้อความ]",
                                                "size": "sm",
                                                 "color": "#000000",
                                                 'flex': 1,
                                             },
                                            {
                                                "type": "text",
                                                "text": "•♡• Github [ข้อความ]",
                                                "size": "sm",
                                                "color": "#000000",
                                                'flex': 1,
                                            },
                                            {
                                                 "type": "text",
                                                "text": "•♡• เพลสโต [ข้อความ]",
                                                "size": "sm",
                                                 "color": "#000000",
                                                 'flex': 1,
                                             },
                                            {
                                                "type": "text",
                                                "text": "•♡• ลบสิริ",
                                                "size": "sm",
                                                "color": "#000000",
                                                'flex': 1,
                                            },
                                            {
                                                 "type": "text",
                                                "text": "•♡• บินห้อง",
                                                "size": "sm",
                                                 "color": "#000000",
                                                 'flex': 1,
                                             },
                                            {
                                                 "type": "text",
                                                "text": "•♡• รูปทั้งห้อง",
                                                "size": "sm",
                                                "color": "#000000",
                                                'flex': 1,
                                            },
                                            {
                                                 "type": "text",
                                                "text": "•♡• กลุ่ม",
                                                "size": "sm",
                                                 "color": "#000000",
                                                 'flex': 1,
                                             },
                                            {
                                                 "type": "text",
                                                "text": "•♡• ตั้งเวลา / อ่าน",
                                                "size": "sm",
                                                 "color": "#000000",
                                                 'flex': 1,
                                             }
                                        ]
                                    },
                                    "footer": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [
                                            {
                                                "type": "button",
                                                "style": "link",
                                                "height": "sm",
                                                "action": {
                                                    "type": "uri",
                                                    "label": "🌟      BOT TAG 2020      🌟",
                                                     "uri":"https://line.me/ti/p/~0969245004"
                                                      }
                                                    },
                                                    {
                                                        "type": "spacer",
                                                        "size": "sm",
                                                    }
                                               ]
                                        }
                                  }
                            ]                                                       
                            data = {
                                "type": "flex",
                                "altText": "✯• AVENGERS Help •✯",
                                "contents": {
                                    "type": "carousel",
                                    "contents": dataProfile
                                }
                            }
                            sendTemplate(to, data)
 
                elif text.lower() == "คำสั่ง" or text.lower() == "คำสั่ง1":
                    sas = "™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣\n"
                    sa = "• 🐷คำสั่ง\n"
                    sa += "• 🐷คำสั่งกิฟ\n"
                    sa += "• 🐷 คำสั่งตั้งค่า\n"
                    sa += "• 🐷คำสั่งออน\n"
                    sa += "• 🐷คำสั่งเทส\n"
                    sa += "• 🐷คำสั่งกลุ่ม\n"
                    sa += "• 🐷คำสั่งทั่วไป\n"
                    sa += "• 🐷คำสั่งมีเดีย\n"
                    sa += "• 🐷คำสั่งสปีด\n"
                    sa += "• 🐷คำสั่งนับ\n"
                    sa += "• 🐷คำสั่งapi\n"
                    sa += "• 🐷คำสั่งไวรัส\n"
                    sa += "• 🐷คำสั่งป้องกัน\n"
                    sa += "• 🐷คำสั่งพิเศษ\n"                    
                    helps = "{}".format(str(sa))
                    g = "https://sv1.picz.in.th/images/2020/01/28/RvRBXJ.png"
                    data = {
                            "type": "flex",
                                    "altText": "MENU TEST",
                                        "contents": {
                                        "styles": {
                                        "header": {
                                        "backgroundColor":"#66FFFF"
                                        },
                                        "body": {
                                        "backgroundColor": "#FFFFFF"
                                        },
                                        "footer": {
                                          "backgroundColor": "#66FFFF"
                                        }
                                        },
                                        "type": "bubble",
                                        "header": {
                                        "type": "box",
                                        "layout": "horizontal",
                                        "contents": [
                                                           {
                                                            "type": "button",
                                                            "style": "secondary",
                                                            "color": "#FFFFFF",
                                                            "height": "sm",
                                                            "gravity": "center",
                                                            "flex": 1,
                                                            "action": {
                                                            "type": "uri",
                                                            "label": "ชุดคำสั่ง BOT TAG 2020",
                                                            "uri": "line://app/1602687308-GXq4Vvk9?type=text&text=ติดต่อ"
                                                            }
                                                          },
                                                       ]
                                                   },
                                                   "body": {
                                                   "type": "box",
                                                   "layout": "horizontal",
                                                   "spacing": "md",
                                          "contents": [
                                          {
                                          "type": "box",
                                          "layout": "vertical",
                                          "flex": 0,
                                   "contents": [
                                   {
                                    "type": "image",
                                    "url": g,
                                    "gravity": "bottom"
                                    }
                                  ]
                               }, 
                            {
                             "type": "separator",
                             "color": "#FF9900"
                              }, 
                             {
                             "type": "box",
                             "layout": "vertical",
                             "flex": 2,
                      "contents": [
                      {
                       "type": "text",
                       "text": "{}".format(sa),
                       "color": "#000000",
                       "size": "sm",
                       "weight": "bold",
                      "flex": 3,
                      "wrap": True,
                     "gravity": "top"
                    }
                  ]
               }
            ]
         },
        "footer": {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                                           {
                                             "type": "button",
                                             "style": "secondary",
                                             "color": "#FFFFFF",
                                             "height": "sm",
                                             "gravity": "center",
                                             "flex": 1,
                                             "action": {
                                             "type": "uri",
                                             "label": "BOT TAG 2020",
                                             "uri": "https://line.me/ti/p/~0969245004",
                                            }
                                          },
                                        {
                                           "type": "spacer",
                                           "size": "sm",
                                         }
                                       ],
                                    "flex": 0
                                   }
                                }
                            }
                    sendTemplate(to, data)        

                elif text.lower() == "คำสั่งสปีด" or text.lower() == "สปีด":
                    sas = "™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣\n"
                    sa = "• 🐷 Sp \n"
                    sa += "• 🐷 แรงม้า\n"
                    sa += "• 🐷 ไฮสปีด\n"
                    sa += "• 🐷 สปูด\n"
                    sa += "• 🐷 สปัด\n"                    
                    sa += "• 🐷 4g\n"
                    sa += "• 🐷 เทสจรวด\n"
                    sa += "• 🐷 Ais\n"
                    sa += "• 🐷 3bb\n"      
                    sa += "• 🐷 8g\n"
                    sa += "• 🐷 9g\n"
                    sa += "• 🐷 .45\n"
                    sa += "• 🐷 10g\n"
                    sa += "• 🐷 M16\n"
                    sa += "• 🐷 11g\n"
                    sa += "• 🐷 Hk\n"
                    sa += "• 🐷 12g\n"
                    sa += "• 🐷 13g\n"
                    sa += "• 🐷 รถเต่า\n"
                    helps = "{}".format(str(sa))
                    g = "https://sv1.picz.in.th/images/2020/01/28/RvHoxJ.png"
                    data = {
                            "type": "flex",
                                    "altText": "MENU TEST",
                                        "contents": {
                                        "styles": {
                                        "header": {
                                        "backgroundColor":"#66FFFF"
                                        },
                                        "body": {
                                        "backgroundColor": "#FFFFFF"
                                        },
                                        "footer": {
                                          "backgroundColor": "#66FFFF"
                                        }
                                        },
                                        "type": "bubble",
                                        "header": {
                                        "type": "box",
                                        "layout": "horizontal",
                                        "contents": [
                                                           {
                                                            "type": "button",
                                                            "style": "secondary",
                                                            "color": "#FFFFFF",
                                                            "height": "sm",
                                                            "gravity": "center",
                                                            "flex": 1,
                                                            "action": {
                                                            "type": "uri",
                                                            "label": "คำสั่ง บอทเทสสปีด",
                                                            "uri": "https://line.me/ti/p/~0969245004"
                                                            }
                                                          },
                                                       ]
                                                   },
                                                   "body": {
                                                   "type": "box",
                                                   "layout": "horizontal",
                                                   "spacing": "md",
                                          "contents": [
                                          {
                                          "type": "box",
                                          "layout": "vertical",
                                          "flex": 0,
                                   "contents": [
                                   {
                                    "type": "image",
                                    "url": g,
                                    "gravity": "bottom"
                                    }
                                  ]
                               }, 
                            {
                             "type": "separator",
                             "color": "#FF9900"
                              }, 
                             {
                             "type": "box",
                             "layout": "vertical",
                             "flex": 2,
                      "contents": [
                      {
                       "type": "text",
                       "text": "{}".format(sa),
                       "color": "#000000",
                       "size": "sm",
                       "weight": "bold",
                      "flex": 3,
                      "wrap": True,
                     "gravity": "top"
                    }
                  ]
               }
            ]
         },
        "footer": {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                                           {
                                             "type": "button",
                                             "style": "secondary",
                                             "color": "#FFFFFF",
                                             "height": "sm",
                                             "gravity": "center",
                                             "flex": 1,
                                             "action": {
                                             "type": "uri",
                                             "label": "BOT TAG 2020",
                                             "uri": "https://line.me/ti/p/~0969245004",
                                            }
                                          },
                                        {
                                           "type": "spacer",
                                           "size": "sm",
                                         }
                                       ],
                                    "flex": 0
                                   }
                                }
                            }                        
                    sendTemplate(to, data)        

                elif text.lower() == "คำสั่งนับ" or text.lower() == "นับคำสั่ง":
                    sas = "™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣\n"
                    sa = "• 🐷 นับ \n"
                    sa += "• 🐷 นับจีน\n"
                    sa += "• 🐷 นับไทย\n"
                    sa += "• 🐷 นับอังกฤษ\n"
                    sa += "• 🐷 นับอินโด\n"   
                    sa += "• 🐷 นับสเปน\n"
                    sa += "• 🐷 นับไฮโซ\n"
                    sa += "• 🐷 ใครหล่อสุด\n"
                    sa += "• 🐷 ดับไฟ\n"
                    sa += "• 🐷 บอทด่า\n"
                    helps = "{}".format(str(sa))
                    g = "https://sv1.picz.in.th/images/2020/01/28/RvvUhl.jpg"
                    data = {
                            "type": "flex",
                                    "altText": "MENU TEST",
                                        "contents": {
                                        "styles": {
                                        "header": {
                                        "backgroundColor":"#66FFFF"
                                        },
                                        "body": {
                                        "backgroundColor": "#FFFFFF"
                                        },
                                        "footer": {
                                          "backgroundColor": "#66FFFF"
                                        }
                                        },
                                        "type": "bubble",
                                        "header": {
                                        "type": "box",
                                        "layout": "horizontal",
                                        "contents": [
                                                           {
                                                            "type": "button",
                                                            "style": "secondary",
                                                            "color": "#FFFFFF",
                                                            "height": "sm",
                                                            "gravity": "center",
                                                            "flex": 1,
                                                            "action": {
                                                            "type": "uri",
                                                            "label": "คำสั่ง นับเลข",
                                                            "uri": "https://line.me/ti/p/~0969245004"
                                                            }
                                                          },
                                                       ]
                                                   },
                                                   "body": {
                                                   "type": "box",
                                                   "layout": "horizontal",
                                                   "spacing": "md",
                                          "contents": [
                                          {
                                          "type": "box",
                                          "layout": "vertical",
                                          "flex": 0,
                                   "contents": [
                                   {
                                    "type": "image",
                                    "url": g,
                                    "gravity": "bottom"
                                    }
                                  ]
                               }, 
                            {
                             "type": "separator",
                             "color": "#FF9900"
                              }, 
                             {
                             "type": "box",
                             "layout": "vertical",
                             "flex": 2,
                      "contents": [
                      {
                       "type": "text",
                       "text": "{}".format(sa),
                       "color": "#000000",
                       "size": "sm",
                       "weight": "bold",
                      "flex": 3,
                      "wrap": True,
                     "gravity": "top"
                    }
                  ]
               }
            ]
         },
        "footer": {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                                           {
                                             "type": "button",
                                             "style": "secondary",
                                             "color": "#FFFFFF",
                                             "height": "sm",
                                             "gravity": "center",
                                             "flex": 1,
                                             "action": {
                                             "type": "uri",
                                             "label": "BOT TAG 2020",
                                             "uri": "https://line.me/ti/p/~0969245004",
                                            }
                                          },
                                        {
                                           "type": "spacer",
                                           "size": "sm",
                                         }
                                       ],
                                    "flex": 0
                                   }
                                }
                            }                        
                    sendTemplate(to, data)       

                elif text.lower() == "คำสั่งไวรัส" or text.lower() == "ไวรัส":
                    sas = "™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣\n"                
                    sa = "• 🐷 ส่งหัวใจ [จำนวน]@ \n"
                    sa += "• 🐷 ส่งคลิป [จำนวน]@\n"
                    sa += "• 🐷 แจกของขวัญ [จำนวน]@\n"
                    sa += "• 🐷 ส่งนอน [จำนวน]@\n"
                    sa += "• 🐷 ส่งความรัก [จำนวน]@\n"   
                    sa += "• 🐷 ส่งความคิดถึง [จำนวน]@\n"
                    sa += "• 🐷 ส่งของขวัญ [จำนวน]@\n"
                    sa += "\n"
                    sa += "\n"
                    helps = "{}".format(str(sa))
                    g = "https://sv1.picz.in.th/images/2020/01/28/RvGUPb.png"
                    data = {
                            "type": "flex",
                                    "altText": "MENU TEST",
                                        "contents": {
                                        "styles": {
                                        "header": {
                                        "backgroundColor":"#66FFFF"
                                        },
                                        "body": {
                                        "backgroundColor": "#FFFFFF"
                                        },
                                        "footer": {
                                          "backgroundColor": "#66FFFF"
                                        }
                                        },
                                        "type": "bubble",
                                        "header": {
                                        "type": "box",
                                        "layout": "horizontal",
                                        "contents": [
                                                           {
                                                            "type": "button",
                                                            "style": "secondary",
                                                            "color": "#FFFFFF",
                                                            "height": "sm",
                                                            "gravity": "center",
                                                            "flex": 1,
                                                            "action": {
                                                            "type": "uri",
                                                            "label": "คำสั่ง ส่งไวรัส",
                                                            "uri": "https://line.me/ti/p/~0969245004"
                                                            }
                                                          },
                                                       ]
                                                   },
                                                   "body": {
                                                   "type": "box",
                                                   "layout": "horizontal",
                                                   "spacing": "md",
                                          "contents": [
                                          {
                                          "type": "box",
                                          "layout": "vertical",
                                          "flex": 0,
                                   "contents": [
                                   {
                                    "type": "image",
                                    "url": g,
                                    "gravity": "bottom"
                                    }
                                  ]
                               }, 
                            {
                             "type": "separator",
                             "color": "#FF9900"
                              }, 
                             {
                             "type": "box",
                             "layout": "vertical",
                             "flex": 2,
                      "contents": [
                      {
                       "type": "text",
                       "text": "{}".format(sa),
                       "color": "#000000",
                       "size": "sm",
                       "weight": "bold",
                      "flex": 3,
                      "wrap": True,
                     "gravity": "top"
                    }
                  ]
               }
            ]
         },
        "footer": {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                                           {
                                             "type": "button",
                                             "style": "secondary",
                                             "color": "#FFFFFF",
                                             "height": "sm",
                                             "gravity": "center",
                                             "flex": 1,
                                             "action": {
                                             "type": "uri",
                                             "label": "BOT TAG 2020",
                                             "uri": "https://line.me/ti/p/~0969245004",
                                            }
                                          },
                                        {
                                           "type": "spacer",
                                           "size": "sm",
                                         }
                                       ],
                                    "flex": 0
                                   }
                                }
                            }                        
                    sendTemplate(to, data)       

                elif text.lower() == "คำสั่งป้องกัน" or text.lower() == "ชุดป้องกัน":
                    sas = "™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣\n"
                    sa = "• 🐷 ระบบป้องกันกลุ่ม🐷 \n"
                    sa += "\n"
                    sa += "\n"
                    sa += "• 🐷 กันเชิญ เปิด\n"
                    sa += "• 🐷 กันลิ้ง เปิด\n"   
                    sa += "• 🐷 กันเตะ เปิด\n"
                    sa += "\n"
                    sa += "\n"
                    sa += "• 🐷 กันเชิญ ปิด\n"
                    sa += "• 🐷 กันลิ้ง ปิด\n"
                    sa += "• 🐷 กันเตะ ปิด\n"
                    sa += "\n"
                    sa += "\n"
                    helps = "{}".format(str(sa))
                    g = "https://sv1.picz.in.th/images/2020/01/28/RvGTen.png"
                    data = {
                            "type": "flex",
                                    "altText": "MENU TEST",
                                        "contents": {
                                        "styles": {
                                        "header": {
                                        "backgroundColor":"#66FFFF"
                                        },
                                        "body": {
                                        "backgroundColor": "#FFFFFF"
                                        },
                                        "footer": {
                                          "backgroundColor": "#66FFFF"
                                        }
                                        },
                                        "type": "bubble",
                                        "header": {
                                        "type": "box",
                                        "layout": "horizontal",
                                        "contents": [
                                                           {
                                                            "type": "button",
                                                            "style": "secondary",
                                                            "color": "#FFFFFF",
                                                            "height": "sm",
                                                            "gravity": "center",
                                                            "flex": 1,
                                                            "action": {
                                                            "type": "uri",
                                                            "label": "คำสั่ง ชุดป้องกัน",
                                                            "uri": "https://line.me/ti/p/~0969245004"
                                                            }
                                                          },
                                                       ]
                                                   },
                                                   "body": {
                                                   "type": "box",
                                                   "layout": "horizontal",
                                                   "spacing": "md",
                                          "contents": [
                                          {
                                          "type": "box",
                                          "layout": "vertical",
                                          "flex": 0,
                                   "contents": [
                                   {
                                    "type": "image",
                                    "url": g,
                                    "gravity": "bottom"
                                    }
                                  ]
                               }, 
                            {
                             "type": "separator",
                             "color": "#FF9900"
                              }, 
                             {
                             "type": "box",
                             "layout": "vertical",
                             "flex": 2,
                      "contents": [
                      {
                       "type": "text",
                       "text": "{}".format(sa),
                       "color": "#000000",
                       "size": "sm",
                       "weight": "bold",
                      "flex": 3,
                      "wrap": True,
                     "gravity": "top"
                    }
                  ]
               }
            ]
         },
        "footer": {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                                           {
                                             "type": "button",
                                             "style": "secondary",
                                             "color": "#FFFFFF",
                                             "height": "sm",
                                             "gravity": "center",
                                             "flex": 1,
                                             "action": {
                                             "type": "uri",
                                             "label": "BOT TAG 2020",
                                             "uri": "https://line.me/ti/p/~0969245004",
                                            }
                                          },
                                        {
                                           "type": "spacer",
                                           "size": "sm",
                                         }
                                       ],
                                    "flex": 0
                                   }
                                }
                            }                        
                    sendTemplate(to, data)           

                elif text.lower() == "คำสั่งตั้งค่า" or text.lower() == "ตั้งค่า":
                    sas = "™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣\n"
                    sa = "• 🐷เชคค่า\n"
                    sa += "• 🐷เปิดต้อนรับ\n"
                    sa += "• 🐷เปิดคนออก\n"
                    sa += "• 🐷เปิดทักเตะ\n"
                    sa += "• 🐷เปิดแทค\n"
                    sa += "• 🐷เปิดแทค2\n"
                    sa += "• 🐷เปิดออก\n"
                    sa += "• 🐷เปิดอ่าน\n"
                    sa += "• 🐷เปิดกันรัน\n"
                    sa += "• 🐷เปิดเข้า\n"
                    sa += "• 🐷เปิดบล็อค\n"
                    sa += "• 🐷เปิดไลค์\n"
                    sa += "\n"                    
                    sa += "• 🐷ปิดต้อนรับ\n"
                    sa += "• 🐷ปิดคนออก\n"
                    sa += "• 🐷ปิดทักเตะ\n"
                    sa += "• 🐷ปิดแทค\n"
                    sa += "• 🐷ปิดแทค2\n"
                    sa += "• 🐷ปิดออก\n"
                    sa += "• 🐷ปิดอ่าน\n"
                    sa += "• 🐷ปิดกันรัน\n"
                    sa += "• 🐷ปิดเข้า\n"
                    sa += "• 🐷ปิดบล็อค\n"
                    sa += "• 🐷ปิดไลค์\n"
                    helps = "{}".format(str(sa))
                    g = "https://sv1.picz.in.th/images/2020/01/29/RG9Kx8.png"
                    data = {
                            "type": "flex",
                                    "altText": "MENU TEST",
                                        "contents": {
                                        "styles": {
                                        "header": {
                                        "backgroundColor":"#66FFFF"
                                        },
                                        "body": {
                                        "backgroundColor": "#FFFFFF"
                                        },
                                        "footer": {
                                          "backgroundColor": "#66FFFF"
                                        }
                                        },
                                        "type": "bubble",
                                        "header": {
                                        "type": "box",
                                        "layout": "horizontal",
                                        "contents": [
                                                           {
                                                            "type": "button",
                                                            "style": "secondary",
                                                            "color": "#FFFFFF",
                                                            "height": "sm",
                                                            "gravity": "center",
                                                            "flex": 1,
                                                            "action": {
                                                            "type": "uri",
                                                            "label": "ชุดคำสั่ง ตั้งค่าบอท",
                                                            "uri": "line://app/1602687308-GXq4Vvk9?type=text&text=ติดต่อ"
                                                            }
                                                          },
                                                       ]
                                                   },
                                                   "body": {
                                                   "type": "box",
                                                   "layout": "horizontal",
                                                   "spacing": "md",
                                          "contents": [
                                          {
                                          "type": "box",
                                          "layout": "vertical",
                                          "flex": 0,
                                   "contents": [
                                   {
                                    "type": "image",
                                    "url": g,
                                    "gravity": "bottom"
                                    }
                                  ]
                               }, 
                            {
                             "type": "separator",
                             "color": "#FF9900"
                              }, 
                             {
                             "type": "box",
                             "layout": "vertical",
                             "flex": 2,
                      "contents": [
                      {
                       "type": "text",
                       "text": "{}".format(sa),
                       "color": "#000000",
                       "size": "sm",
                       "weight": "bold",
                      "flex": 3,
                      "wrap": True,
                     "gravity": "top"
                    }
                  ]
               }
            ]
         },
        "footer": {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                                           {
                                             "type": "button",
                                             "style": "secondary",
                                             "color": "#FFFFFF",
                                             "height": "sm",
                                             "gravity": "center",
                                             "flex": 1,
                                             "action": {
                                             "type": "uri",
                                             "label": "BOT TAG 2020",
                                             "uri": "https://line.me/ti/p/~0969245004",
                                            }
                                          },
                                        {
                                           "type": "spacer",
                                           "size": "sm",
                                         }
                                       ],
                                    "flex": 0
                                   }
                                }
                            }
                    sendTemplate(to, data)        

                elif text.lower() == "คำสั่งกลุ่ม" or text.lower() == "คำสั่งกลุ่ม1":
                    sas = "™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣\n"
                    sa = "• 🐷ข้อมูลกลุ่ม\n"
                    sa += "• 🐷แทค\n"
                    sa += "• 🐷รูปทั้งห้อง\n"
                    sa += "• 🐷สมาชิกกลุ่ม\n"
                    sa += "• 🐷ไอดีกลุ่ม\n"
                    sa += "• 🐷ปกกลุ่ม\n"
                    sa += "• 🐷ชื่อกลุ่ม\n"
                    sa += "• 🐷แอด\n"
                    sa += "• 🐷แอดมิน\n"
                    sa += "• 🐷วันที่\n"
                    sa += "• 🐷เปิดแอบ\n"
                    sa += "• 🐷ปิดแอบ\n"
                    sa += "• 🐷ลิ้ง\n"
                    sa += "• 🐷เปิดลิ้ง\n"
                    sa += "• 🐷ปิดลิ้ง\n"   
                    sa += "• 🐷/เทส\n"
                    sa += "• 🐷ลบสิริ\n"
                    sa += "• 🐷บินห้อง\n"
                    sa += "• 🐷ประกูด [ข้อความ]\n"
                    sa += "• 🐷ตั้งเวลา\n"
                    sa += "• 🐷อ่าน\n"
                    sa += "• 🐷ตั้งเวลาใหม่\n"
                    sa += "• 🐷เลิกตั้งเวลา\n"
                    sa += "• 🐷ยกเชิญ\n"
                    helps = "{}".format(str(sa))
                    g = "https://sv1.picz.in.th/images/2020/01/29/RGUviJ.png"
                    data = {
                            "type": "flex",
                                    "altText": "MENU TEST",
                                        "contents": {
                                        "styles": {
                                        "header": {
                                        "backgroundColor":"#66FFFF"
                                        },
                                        "body": {
                                        "backgroundColor": "#FFFFFF"
                                        },
                                        "footer": {
                                          "backgroundColor": "#66FFFF"
                                        }
                                        },
                                        "type": "bubble",
                                        "header": {
                                        "type": "box",
                                        "layout": "horizontal",
                                        "contents": [
                                                           {
                                                            "type": "button",
                                                            "style": "secondary",
                                                            "color": "#FFFFFF",
                                                            "height": "sm",
                                                            "gravity": "center",
                                                            "flex": 1,
                                                            "action": {
                                                            "type": "uri",
                                                            "label": "ชุดคำสั่ง กลุ่ม",
                                                            "uri": "line://app/1602687308-GXq4Vvk9?type=text&text=ติดต่อ"
                                                            }
                                                          },
                                                       ]
                                                   },
                                                   "body": {
                                                   "type": "box",
                                                   "layout": "horizontal",
                                                   "spacing": "md",
                                          "contents": [
                                          {
                                          "type": "box",
                                          "layout": "vertical",
                                          "flex": 0,
                                   "contents": [
                                   {
                                    "type": "image",
                                    "url": g,
                                    "gravity": "bottom"
                                    }
                                  ]
                               }, 
                            {
                             "type": "separator",
                             "color": "#FF9900"
                              }, 
                             {
                             "type": "box",
                             "layout": "vertical",
                             "flex": 2,
                      "contents": [
                      {
                       "type": "text",
                       "text": "{}".format(sa),
                       "color": "#000000",
                       "size": "sm",
                       "weight": "bold",
                      "flex": 3,
                      "wrap": True,
                     "gravity": "top"
                    }
                  ]
               }
            ]
         },
        "footer": {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                                           {
                                             "type": "button",
                                             "style": "secondary",
                                             "color": "#FFFFFF",
                                             "height": "sm",
                                             "gravity": "center",
                                             "flex": 1,
                                             "action": {
                                             "type": "uri",
                                             "label": "BOT TAG 2020",
                                             "uri": "https://line.me/ti/p/~0969245004",
                                            }
                                          },
                                        {
                                           "type": "spacer",
                                           "size": "sm",
                                         }
                                       ],
                                    "flex": 0
                                   }
                                }
                            }
                    sendTemplate(to, data)      

                elif text.lower() == "คำสั่งมีเดีย" or text.lower() == "มีเดีย1":
                    sas = "™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣\n"
                    sa = "• 🐷Me\n"
                    sa += "• 🐷ยูทูป [ข้อความ]\n"
                    sa += "• 🐷พูด [ข้อความ]\n"
                    sa += "• 🐷ติดต่อ\n"
                    sa += "• 🐷เขียน [ข้อความ]\n"
                    sa += "• 🐷ข้อมูล\n"
                    sa += "• 🐷ข้อมูลบอท\n"
                    sa += "• 🐷แจกคับ\n"
                    sa += "• 🐷แจกๆ\n"
                    sa += "• 🐷เพลสโต [ข้อความ]\n"
                    sa += "• 🐷ขอเพลง [ข้อความ]\n"
                    sa += "• 🐷เพลง [ข้อความ]\n"
                    sa += "• 🐷Github [ข้อความ]\n"
                    sa += "• 🐷กูเกิ้ล [ข้อความ]\n"
                    sa += "• 🐷เฟส [ข้อความ]\n"   
                    sa += "• 🐷Spam on/off\n"
                    sa += "• 🐷สแปมแทค @\n"                    
                    helps = "{}".format(str(sa))
                    g = "https://sv1.picz.in.th/images/2020/01/29/RGEME2.png"
                    data = {
                            "type": "flex",
                                    "altText": "MENU TEST",
                                        "contents": {
                                        "styles": {
                                        "header": {
                                        "backgroundColor":"#66FFFF"
                                        },
                                        "body": {
                                        "backgroundColor": "#FFFFFF"
                                        },
                                        "footer": {
                                          "backgroundColor": "#66FFFF"
                                        }
                                        },
                                        "type": "bubble",
                                        "header": {
                                        "type": "box",
                                        "layout": "horizontal",
                                        "contents": [
                                                           {
                                                            "type": "button",
                                                            "style": "secondary",
                                                            "color": "#FFFFFF",
                                                            "height": "sm",
                                                            "gravity": "center",
                                                            "flex": 1,
                                                            "action": {
                                                            "type": "uri",
                                                            "label": "ชุดคำสั่ง มีเดีย",
                                                            "uri": "line://app/1602687308-GXq4Vvk9?type=text&text=ติดต่อ"
                                                            }
                                                          },
                                                       ]
                                                   },
                                                   "body": {
                                                   "type": "box",
                                                   "layout": "horizontal",
                                                   "spacing": "md",
                                          "contents": [
                                          {
                                          "type": "box",
                                          "layout": "vertical",
                                          "flex": 0,
                                   "contents": [
                                   {
                                    "type": "image",
                                    "url": g,
                                    "gravity": "bottom"
                                    }
                                  ]
                               }, 
                            {
                             "type": "separator",
                             "color": "#FF9900"
                              }, 
                             {
                             "type": "box",
                             "layout": "vertical",
                             "flex": 2,
                      "contents": [
                      {
                       "type": "text",
                       "text": "{}".format(sa),
                       "color": "#000000",
                       "size": "sm",
                       "weight": "bold",
                      "flex": 3,
                      "wrap": True,
                     "gravity": "top"
                    }
                  ]
               }
            ]
         },
        "footer": {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                                           {
                                             "type": "button",
                                             "style": "secondary",
                                             "color": "#FFFFFF",
                                             "height": "sm",
                                             "gravity": "center",
                                             "flex": 1,
                                             "action": {
                                             "type": "uri",
                                             "label": "BOT TAG 2020",
                                             "uri": "https://line.me/ti/p/~0969245004",
                                            }
                                          },
                                        {
                                           "type": "spacer",
                                           "size": "sm",
                                         }
                                       ],
                                    "flex": 0
                                   }
                                }
                            }
                    sendTemplate(to, data)      

                elif text.lower() == "คำสั่งทั่วไป" or text.lower() == "ทั่วไป":
                    sas = "™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣\n"
                    sa = "• 🐷คท\n"
                    sa += "• 🐷ผส\n"
                    sa += "• 🐷มิดบอท\n"
                    sa += "• 🐷ชื่อบอท\n"
                    sa += "• 🐷ตัสบอท\n"
                    sa += "• 🐷ดิสบอท\n"
                    sa += "• 🐷วีดีโอบอท\n"
                    sa += "• 🐷ปกบอท\n"
                    sa += ""
                    sa += "• 🐷คท @\n"
                    sa += "• 🐷มิด @\n"
                    sa += "• 🐷ชื่อ @\n"
                    sa += "• 🐷ดิส @\n"
                    sa += "• 🐷ปก @\n"
                    sa += "• 🐷วีดีโอ @\n"   
                    sa += "• 🐷ข้อมูล @\n"
                    sa += "• 🐷รีบอท\n"
                    sa += "• 🐷ลบแชทบอท\n"
                    sa += "• 🐷บอทออก\n"
                    sa += "• 🐷บอทออกทุกกลุ่ม\n"
                    sa += "• 🐷กลุ่ม\n"
                    sa += "• 🐷เช็คกลุ่ม\n"
                    sa += "• 🐷/ประกาศ [ข้อความ]\n"
                    sa += "• 🐷ยกเชิญ\n"
                    sa += "• 🐷ลิ้งเฟก\n"
                    helps = "{}".format(str(sa))
                    g = "https://sv1.picz.in.th/images/2020/01/29/RGDsRk.png"
                    data = {
                            "type": "flex",
                                    "altText": "MENU TEST",
                                        "contents": {
                                        "styles": {
                                        "header": {
                                        "backgroundColor":"#66FFFF"
                                        },
                                        "body": {
                                        "backgroundColor": "#FFFFFF"
                                        },
                                        "footer": {
                                          "backgroundColor": "#66FFFF"
                                        }
                                        },
                                        "type": "bubble",
                                        "header": {
                                        "type": "box",
                                        "layout": "horizontal",
                                        "contents": [
                                                           {
                                                            "type": "button",
                                                            "style": "secondary",
                                                            "color": "#FFFFFF",
                                                            "height": "sm",
                                                            "gravity": "center",
                                                            "flex": 1,
                                                            "action": {
                                                            "type": "uri",
                                                            "label": "ชุดคำสั่ง ทั่วไป",
                                                            "uri": "line://app/1602687308-GXq4Vvk9?type=text&text=ติดต่อ"
                                                            }
                                                          },
                                                       ]
                                                   },
                                                   "body": {
                                                   "type": "box",
                                                   "layout": "horizontal",
                                                   "spacing": "md",
                                          "contents": [
                                          {
                                          "type": "box",
                                          "layout": "vertical",
                                          "flex": 0,
                                   "contents": [
                                   {
                                    "type": "image",
                                    "url": g,
                                    "gravity": "bottom"
                                    }
                                  ]
                               }, 
                            {
                             "type": "separator",
                             "color": "#FF9900"
                              }, 
                             {
                             "type": "box",
                             "layout": "vertical",
                             "flex": 2,
                      "contents": [
                      {
                       "type": "text",
                       "text": "{}".format(sa),
                       "color": "#000000",
                       "size": "sm",
                       "weight": "bold",
                      "flex": 3,
                      "wrap": True,
                     "gravity": "top"
                    }
                  ]
               }
            ]
         },
        "footer": {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                                           {
                                             "type": "button",
                                             "style": "secondary",
                                             "color": "#FFFFFF",
                                             "height": "sm",
                                             "gravity": "center",
                                             "flex": 1,
                                             "action": {
                                             "type": "uri",
                                             "label": "BOT TAG 2020",
                                             "uri": "https://line.me/ti/p/~0969245004",
                                            }
                                          },
                                        {
                                           "type": "spacer",
                                           "size": "sm",
                                         }
                                       ],
                                    "flex": 0
                                   }
                                }
                            }
                    sendTemplate(to, data)      

                elif text.lower() == "คำสั่งapi" or text.lower() == "คำสั่งaip":
                    sas = "™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣\n"
                    sa = "• 🐷หลุด\n"
                    sa += "• 🐷งง\n"
                    sa += "• 🐷บอท\n"
                    sa += "• 🐷 .\n"
                    sa += "• 🐷จุด\n"
                    sa += "• 🐷กำ\n"
                    sa += "• 🐷ดีจ้า\n"
                    sa += "• 🐷มอนิ่ง\n"
                    sa += "• 🐷ฝรรดี\n"
                    sa += "• 🐷รอ\n"
                    sa += "• 🐷5555\n"                 
                    helps = "{}".format(str(sa))
                    g = "https://sv1.picz.in.th/images/2020/01/29/RGAxbS.png"
                    data = {
                            "type": "flex",
                                    "altText": "MENU TEST",
                                        "contents": {
                                        "styles": {
                                        "header": {
                                        "backgroundColor":"#66FFFF"
                                        },
                                        "body": {
                                        "backgroundColor": "#FFFFFF"
                                        },
                                        "footer": {
                                          "backgroundColor": "#66FFFF"
                                        }
                                        },
                                        "type": "bubble",
                                        "header": {
                                        "type": "box",
                                        "layout": "horizontal",
                                        "contents": [
                                                           {
                                                            "type": "button",
                                                            "style": "secondary",
                                                            "color": "#FFFFFF",
                                                            "height": "sm",
                                                            "gravity": "center",
                                                            "flex": 1,
                                                            "action": {
                                                            "type": "uri",
                                                            "label": "ชุดคำสั่ง บอทapi",
                                                            "uri": "line://app/1602687308-GXq4Vvk9?type=text&text=ติดต่อ"
                                                            }
                                                          },
                                                       ]
                                                   },
                                                   "body": {
                                                   "type": "box",
                                                   "layout": "horizontal",
                                                   "spacing": "md",
                                          "contents": [
                                          {
                                          "type": "box",
                                          "layout": "vertical",
                                          "flex": 0,
                                   "contents": [
                                   {
                                    "type": "image",
                                    "url": g,
                                    "gravity": "bottom"
                                    }
                                  ]
                               }, 
                            {
                             "type": "separator",
                             "color": "#FF9900"
                              }, 
                             {
                             "type": "box",
                             "layout": "vertical",
                             "flex": 2,
                      "contents": [
                      {
                       "type": "text",
                       "text": "{}".format(sa),
                       "color": "#000000",
                       "size": "sm",
                       "weight": "bold",
                      "flex": 3,
                      "wrap": True,
                     "gravity": "top"
                    }
                  ]
               }
            ]
         },
        "footer": {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                                           {
                                             "type": "button",
                                             "style": "secondary",
                                             "color": "#FFFFFF",
                                             "height": "sm",
                                             "gravity": "center",
                                             "flex": 1,
                                             "action": {
                                             "type": "uri",
                                             "label": "BOT TAG 2020",
                                             "uri": "https://line.me/ti/p/~0969245004",
                                            }
                                          },
                                        {
                                           "type": "spacer",
                                           "size": "sm",
                                         }
                                       ],
                                    "flex": 0
                                   }
                                }
                            }
                    sendTemplate(to, data)     
                   
                if text.lower() == "help" or text.lower() == "คำสั่งบอท":                        
                            dataProfile = [
                                {
                                    "type": "bubble",
                                    "styles": {
                                        "header": {"backgroundColor":"#FFFFFF"},
                                        "hero": {"backgroundColor": "#FFFFFF"}, #"separator": True, "separatorColor": "#333333"},
                                        "footer": {"backgroundColor": "#66FFFF"}, #"separator": True, "separatorColor": "#333333"}
                                    },
                                    "header": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [
                                            {
                                                "type": "image",
                                                "url": 'https://sv1.picz.in.th/images/2020/02/02/RIHB3J.png',
                                                "size": "full"
                                            },
                                            {
                                                "type": "separator",
                                                "color": "#000000"
                                            },
                                            {                                                
                                                "contents": [
                                                    {
                                                    "text": "BOT TAG 2020",
                                                    "size": "xl",
                                                    "align": "center",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "bold",
                                                    "type": "text"
                                                    }
                                                ],
                                                "type": "box",
                                                "spacing": "sm",
                                                "layout": "vertical"
                                            },
                                            {
                                                "type": "separator",
                                                "color": "#000000"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤Me",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤ออน",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {                                            
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤คำสั่งป้องกัน",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                             },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤รีบอท",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤แรงม้า",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                             },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤ข้อมูล",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤ข้อมูลบอท",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                             },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤ข้อมูลกลุ่ม",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤แทค",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                             }
                                        ]
                                    },
                                    "footer": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [
                                            {
                                                "type": "box",
                                                "layout": "baseline",
                                                "contents": [
                                                    {
                                                        "type": "icon",
                                                        "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                        "size": "xxl"
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "BOT TAG 2020",
                                                        "align": "center",
                                                        "color": "#000000",
                                                        "size": "md"
                                                    },
                                                    {
                                                        "type": "spacer",
                                                        "size": "md",
                                                    }
                                                ]
                                            }
                                        ]
                                    }
                                },
                                {
                                    "type": "bubble",
                                    "styles": {
                                        "header": {"backgroundColor":"#FFFFFF"},
                                        "hero": {"backgroundColor": "#FFFFFF"}, #"separator": True, "separatorColor": "#333333"},
                                        "footer": {"backgroundColor": "#66FFFF"}, #"separator": True, "separatorColor": "#333333"}
                                    },
                                    "header": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [
                                            {
                                                "type": "image",
                                                "url": 'https://sv1.picz.in.th/images/2020/02/02/RIHB3J.png',
                                                "size": "full"
                                            },
                                            {
                                                "type": "separator",
                                                "color": "#000000"
                                            },
                                            {                                                
                                                "contents": [
                                                    {
                                                    "text": "BOT TAG 2020",
                                                    "size": "xl",
                                                    "align": "center",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "bold",
                                                    "type": "text"
                                                    }
                                                ],
                                                "type": "box",
                                                "spacing": "sm",
                                                "layout": "vertical"
                                            },
                                            {
                                                "type": "separator",
                                                "color": "#000000"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤แอด",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤แอดมิน",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {                                            
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤เชคค่า",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                             },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤ยกเชิญ",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤ไอดีกลุ่ม",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                             },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤ชื่อกลุ่ม",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤ปกกลุ่ม",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                             },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤/ประกาศ [ข้อความ]",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤ประกูด [ข้อความ]",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                             }
                                        ]
                                    },
                                    "footer": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [
                                            {
                                                "type": "box",
                                                "layout": "baseline",
                                                "contents": [
                                                    {
                                                        "type": "icon",
                                                        "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                        "size": "xxl"
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "BOT TAG 2020",
                                                        "align": "center",
                                                        "color": "#000000",
                                                        "size": "md"
                                                    },
                                                    {
                                                        "type": "spacer",
                                                        "size": "md",
                                                    }
                                                ]
                                            }
                                        ]
                                    }
                                },
                                {
                                    "type": "bubble",
                                    "styles": {
                                        "header": {"backgroundColor":"#FFFFFF"},
                                        "hero": {"backgroundColor": "#FFFFFF"}, #"separator": True, "separatorColor": "#333333"},
                                        "footer": {"backgroundColor": "#66FFFF"}, #"separator": True, "separatorColor": "#333333"}
                                    },
                                    "header": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [
                                            {
                                                "type": "image",
                                                "url": 'https://sv1.picz.in.th/images/2020/02/02/RIHB3J.png',
                                                "size": "full"
                                            },
                                            {
                                                "type": "separator",
                                                "color": "#000000"
                                            },
                                            {                                                
                                                "contents": [
                                                    {
                                                    "text": "BOT TAG 2020",
                                                    "size": "xl",
                                                    "align": "center",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "bold",
                                                    "type": "text"
                                                    }
                                                ],
                                                "type": "box",
                                                "spacing": "sm",
                                                "layout": "vertical"
                                            },
                                            {
                                                "type": "separator",
                                                "color": "#000000"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤ยูทูป [ข้อความ]",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤เพลสโต [ข้อความ]",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {                                            
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤กูเกิ้ล [ข้อความ]",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                             },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤ขอเพลง [ข้อความ]",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤เพลง [ข้อความ]",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                             },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤เฟส [ข้อความ]",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤Github [ข้อความ]",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                             },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤รูปทั้งห้อง",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤ข้อมูล @",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                             }
                                        ]
                                    },
                                    "footer": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [
                                            {
                                                "type": "box",
                                                "layout": "baseline",
                                                "contents": [
                                                    {
                                                        "type": "icon",
                                                        "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                        "size": "xxl"
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "BOT TAG 2020",
                                                        "align": "center",
                                                        "color": "#000000",
                                                        "size": "md"
                                                    },
                                                    {
                                                        "type": "spacer",
                                                        "size": "md",
                                                    }
                                                ]
                                            }
                                        ]
                                    }
                                },
                                {
                                    "type": "bubble",
                                    "styles": {
                                        "header": {"backgroundColor":"#FFFFFF"},
                                        "hero": {"backgroundColor": "#FFFFFF"}, #"separator": True, "separatorColor": "#333333"},
                                        "footer": {"backgroundColor": "#66FFFF"}, #"separator": True, "separatorColor": "#333333"}
                                    },
                                    "header": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [
                                            {
                                                "type": "image",
                                                "url": 'https://sv1.picz.in.th/images/2020/02/02/RIHB3J.png',
                                                "size": "full"
                                            },
                                            {
                                                "type": "separator",
                                                "color": "#000000"
                                            },
                                            {                                                
                                                "contents": [
                                                    {
                                                    "text": "BOT TAG 2020",
                                                    "size": "xl",
                                                    "align": "center",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "bold",
                                                    "type": "text"
                                                    }
                                                ],
                                                "type": "box",
                                                "spacing": "sm",
                                                "layout": "vertical"
                                            },
                                            {
                                                "type": "separator",
                                                "color": "#000000"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤คท",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤คท @",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {                                            
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤มิด @",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                             },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤ดิส @",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤ปก @",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                             },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤ชื่อ @",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤ตัส @",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                             },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤วีดีโอ @",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤เทสบอท",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                             }
                                        ]
                                    },
                                    "footer": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [
                                            {
                                                "type": "box",
                                                "layout": "baseline",
                                                "contents": [
                                                    {
                                                        "type": "icon",
                                                        "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                        "size": "xxl"
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "BOT TAG 2020",
                                                        "align": "center",
                                                        "color": "#000000",
                                                        "size": "md"
                                                    },
                                                    {
                                                        "type": "spacer",
                                                        "size": "md",
                                                    }
                                                ]
                                            }
                                        ]
                                    }
                                },
                                {
                                    "type": "bubble",
                                    "styles": {
                                        "header": {"backgroundColor":"#FFFFFF"},
                                        "hero": {"backgroundColor": "#FFFFFF"}, #"separator": True, "separatorColor": "#333333"},
                                        "footer": {"backgroundColor": "#66FFFF"}, #"separator": True, "separatorColor": "#333333"}
                                    },
                                    "header": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [
                                            {
                                                "type": "image",
                                                "url": 'https://sv1.picz.in.th/images/2020/02/02/RIHB3J.png',
                                                "size": "full"
                                            },
                                            {
                                                "type": "separator",
                                                "color": "#000000"
                                            },
                                            {                                                
                                                "contents": [
                                                    {
                                                    "text": "BOT TAG 2020",
                                                    "size": "xl",
                                                    "align": "center",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "bold",
                                                    "type": "text"
                                                    }
                                                ],
                                                "type": "box",
                                                "spacing": "sm",
                                                "layout": "vertical"
                                            },
                                            {
                                                "type": "separator",
                                                "color": "#000000"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤ตั้งเวลา",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤เลิกตั้งเวลา",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {                                            
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤ตั้งเวลาใหม่",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                             },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤อ่าน",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤ดิสบอท",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                             },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤มิดบอท",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤ชื่อบอท",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                             },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤ตัสบอท",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤วีดีโอบอท",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                             }
                                        ]
                                    },
                                    "footer": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [
                                            {
                                                "type": "box",
                                                "layout": "baseline",
                                                "contents": [
                                                    {
                                                        "type": "icon",
                                                        "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                        "size": "xxl"
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "BOT TAG 2020",
                                                        "align": "center",
                                                        "color": "#000000",
                                                        "size": "md"
                                                    },
                                                    {
                                                        "type": "spacer",
                                                        "size": "md",
                                                    }
                                                ]
                                            }
                                        ]
                                    }
                                },
                                {
                                    "type": "bubble",
                                    "styles": {
                                        "header": {"backgroundColor":"#FFFFFF"},
                                        "hero": {"backgroundColor": "#FFFFFF"}, #"separator": True, "separatorColor": "#333333"},
                                        "footer": {"backgroundColor": "#66FFFF"}, #"separator": True, "separatorColor": "#333333"}
                                    },
                                    "header": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [
                                            {
                                                "type": "image",
                                                "url": 'https://sv1.picz.in.th/images/2020/02/02/RIHB3J.png',
                                                "size": "full"
                                            },
                                            {
                                                "type": "separator",
                                                "color": "#000000"
                                            },
                                            {                                                
                                                "contents": [
                                                    {
                                                    "text": "BOT TAG 2020",
                                                    "size": "xl",
                                                    "align": "center",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "bold",
                                                    "type": "text"
                                                    }
                                                ],
                                                "type": "box",
                                                "spacing": "sm",
                                                "layout": "vertical"
                                            },
                                            {
                                                "type": "separator",
                                                "color": "#000000"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤เปิดแอบ",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤ปิดแอบ",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {                                            
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤ผส",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                             },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤ลบแชทบอท",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤บอทออก",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                             },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤กลุ่ม",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤เช็คกลุ่ม",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                             },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤ลิ้งเฟก",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤ติดต่อ",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                             }
                                        ]
                                    },
                                    "footer": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [
                                            {
                                                "type": "box",
                                                "layout": "baseline",
                                                "contents": [
                                                    {
                                                        "type": "icon",
                                                        "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                        "size": "xxl"
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "BOT TAG 2020",
                                                        "align": "center",
                                                        "color": "#000000",
                                                        "size": "md"
                                                    },
                                                    {
                                                        "type": "spacer",
                                                        "size": "md",
                                                    }
                                                ]
                                            }
                                        ]
                                    }
                                },
                                {
                                    "type": "bubble",
                                    "styles": {
                                        "header": {"backgroundColor":"#FFFFFF"},
                                        "hero": {"backgroundColor": "#FFFFFF"}, #"separator": True, "separatorColor": "#333333"},
                                        "footer": {"backgroundColor": "#66FFFF"}, #"separator": True, "separatorColor": "#333333"}
                                    },
                                    "header": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [
                                            {
                                                "type": "image",
                                                "url": 'https://sv1.picz.in.th/images/2020/02/02/RIHB3J.png',
                                                "size": "full"
                                            },
                                            {
                                                "type": "separator",
                                                "color": "#000000"
                                            },
                                            {                                                
                                                "contents": [
                                                    {
                                                    "text": "BOT TAG 2020",
                                                    "size": "xl",
                                                    "align": "center",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "bold",
                                                    "type": "text"
                                                    }
                                                ],
                                                "type": "box",
                                                "spacing": "sm",
                                                "layout": "vertical"
                                            },
                                            {
                                                "type": "separator",
                                                "color": "#000000"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤เปิดแทค",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤เปิดแทค2",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {                                            
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤เปิดทักเตะ",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                             },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤เปิดต้อนรับ",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤เปิดคนออก",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                             },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤เปิดอ่าน",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤เปิดไลค์",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                             },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": "◑➤เปิดบล็อค ",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤ตั้งค่า",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                             }
                                        ]
                                    },
                                    "footer": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [
                                            {
                                                "type": "box",
                                                "layout": "baseline",
                                                "contents": [
                                                    {
                                                        "type": "icon",
                                                        "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                        "size": "xxl"
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "BOT TAG 2020",
                                                        "align": "center",
                                                        "color": "#000000",
                                                        "size": "md"
                                                    },
                                                    {
                                                        "type": "spacer",
                                                        "size": "md",
                                                    }
                                                ]
                                            }
                                        ]
                                    }
                                },
                                {
                                    "type": "bubble",
                                    "styles": {
                                        "header": {"backgroundColor":"#FFFFFF"},
                                        "hero": {"backgroundColor": "#FFFFFF"}, #"separator": True, "separatorColor": "#333333"},
                                        "footer": {"backgroundColor": "#66FFFF"}, #"separator": True, "separatorColor": "#333333"}
                                    },
                                    "header": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [
                                            {
                                                "type": "image",
                                                "url": 'https://sv1.picz.in.th/images/2020/02/02/RIHB3J.png',
                                                "size": "full"
                                            },
                                            {
                                                "type": "separator",
                                                "color": "#000000"
                                            },
                                            {                                                
                                                "contents": [
                                                    {
                                                    "text": "BOT TAG 2020",
                                                    "size": "xl",
                                                    "align": "center",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "bold",
                                                    "type": "text"
                                                    }
                                                ],
                                                "type": "box",
                                                "spacing": "sm",
                                                "layout": "vertical"
                                            },
                                            {
                                                "type": "separator",
                                                "color": "#000000"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤ปิดแทค",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤ปิดแทค2",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {                                            
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤ปิดทักเตะ",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                             },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤ปิดต้อนรับ",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤ปิดคนออก",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                             },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤ปิดอ่าน",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤ปิดไลค์",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                             },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤ปิดบล็อค",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                            },
                                            {
                                                "contents": [
                                                {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                    "type": "icon",
                                                    "size": "md"
                                                },
                                                {
                                                    "text": " ◑➤คำสั่งป้องกัน",
                                                    "size": "md",
                                                    "margin": "none",
                                                    "color": "#000000",
                                                    'flex': 1,
                                                    "weight": "regular",
                                                    "type": "text"
                                                    }
                                                ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                             }
                                        ]
                                    },
                                    "footer": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [
                                            {
                                                "type": "box",
                                                "layout": "baseline",
                                                "contents": [
                                                    {
                                                        "type": "icon",
                                                        "url": "https://sv1.picz.in.th/images/2020/02/02/RIVMu2.png",
                                                        "size": "xxl"
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "BOT TAG 2020",
                                                        "align": "center",
                                                        "color": "#000000",
                                                        "size": "md"
                                                    },
                                                    {
                                                        "type": "spacer",
                                                        "size": "md",
                                                    }
                                                ]
                                            }
                                        ]
                                    }
                                }
                            ]
                            data = {
                                "type": "flex",
                                "altText": "Help Message",
                                "contents": {
                                    "type": "carousel",
                                    "contents": dataProfile
                                }
                            }
                            sendTemplate(to, data)          
               
                elif text.lower() == "โฆษณา" or text.lower() == ".โฆษณา":                                       
                            ret = "─┅═✥🔘ᵀᴴᴬᴵᴸᴬᴺᴰ🔘✥═┅─\n"
                            ret += "💢 T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣\n"
                            ret += "╠══════════════════\n"
                            ret += "╠  ─┅═✥🔘ᵀᴴᴬᴵᴸᴬᴺᴰ🔘✥═┅─\n"
                            ret += "╠       💀[ SELFBOTLINE]💀\n"
                            ret += "╠══════════════════\n"
                            ret += "╠📌มีบริการให้เช่าเชลบอท\n"
                            ret += "╠📌ขายไฟล์บอททุกชนิด + สอนทำ\n"
                            ret += "╠📌ไลน์ครึ่งคนครึ่งบอท\n"
                            ret += "╠📌ราคาว่ากันตามคุณภาพครับ\n"
                            ret += "╠📌ราคาแรกเข้าจ่าย300บาท\n"
                            ret += "╠📌เดือนต่อไป จ่าย200บาท\n"
                            ret += "╠📌เพิ่มคิกเกอร์ตัวละ100\n"
                            ret += "╠▶ป้องกันกลุ่มได้\n"
                            ret += "╠▶มีเแสกนคำหยาบกันบอทบิน\n"
                            ret += "╠▶แอบดูคนอ่านแบบดึง คท.ได้\n"
                            ret += "╠▶แทคได้,รันแชทได้\n"
                            ret += "╠▶สั่งบล็อคใครก็ได้\n"
                            ret += "╠▶ลบแชทได้ , มุดลิ้งค์ได้\n"
                            ret += "╠▶เช็คโพส,คท,ข้อมูลคนอื่นได้\n"
                            ret += "╠▶เช็คข้อมูลตัวเอง,ข้อมูลกลุ่มได้\n"
                            ret += "╠▶ปฏิเสธคำเชิญแบบใส่ข้อความได้\n"
                            ret += "╠▶ดึงห้องรวมได้\n"
                            ret += "╠▶ตั้งค่าปฏิเสธกลุ่มเชิญได้\n"
                            ret += "╠▶เล่นเซลในแชทสต.ได้\n"
                            ret += "╠▶ตั้งข้อความคนเข้าคนออกได้\n"
                            ret += "╠▶ตั้งข้อความคนลบสมาชิกได้\n"
                            ret += "╠▶ตั้งข้อความคนแอดได้\n"
                            ret += "╠▶เรียกดูการตั้งค่าข้อความได้\n"
                            ret += "╠═══════════════════\n"
                            ret += "╠▶ฟังชั่นล้นหลาม คุณภาพแน่นปึ๊ก\n"
                            ret += "╠▶กำลังรอให้คุณเป็นเจ้าของ....\n"
                            ret += "╠═══════════════════\n"
                            ret += "╠▶(📌ทักก่อนแอด...คับ)\n"
                            ret += "╠═══════════════════\n"
                            ret += "╔═════════════════┓\n"
                            ret += "╠™[T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣]\n"
                            ret += "╚═════════════════┛\n"
                            ret += "╠═══════════════════\n"
                            ret += "╠เป็นเจ้าของเซลบอทคุณภาพดี\n"
                            ret += "╠ [ 📌 ไฟล์..ออโต้บล็อค ]\n"
                            ret += "╠▶ แอดมาสอบถามเลยคับ\n"
                            ret += "╠ ไลน์ไอดี 0969245004\n"
                            ret += "╠💢 T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣\n"
                            ret += "╠═══════════════════\n"
                            ret += "╚══[ รัปประกันความพอใจ ]\n"                           
                            hello = "{}".format(str(ret))
                            data = {
                                    "type": "flex",
                                    "altText": "โฆษณา",
                                        "contents": {
                                        "styles": {
                                        "body": {
                                        "backgroundColor": "#FFFFFF"
                                        },
                                        "footer": {
                                          "backgroundColor": "#000000"
                                        }
                                        },
                                            "type": "bubble",
                                                "hero": {
                                                    "type": "image",
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RMAxZI.jpg",
                                                    "size": "full",
                                                    "aspectRatio": "20:13",
                                                    "aspectMode": "cover",
                                                },
                                            "body": {
                                            "contents": [
                                              {
                                                "contents": [
                                                  {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIHB3J.png",
                                                    "type": "image"
                                                  },
                                                ],
                                                "type": "box",
                                                "spacing": "sm",
                                                "layout": "vertical"
                                              },
                                              {
                                                "type": "separator",
                                                "color": "#000000"
                                              },
                                              {
                                                "contents": [
                                                  {
                                                    "text": "SELFBOT LINE 2020",
                                                    "size": "xl",
                                                    "align": "center",
                                                    "color": "#000000",
                                                    "wrap": True,
                                                    "weight": "bold",
                                                    "type": "text"
                                                  }
                                                ],
                                                "type": "box",
                                                "spacing": "sm",
                                                "layout": "vertical"
                                              },
                                              {
                                                "type": "separator",
                                                "color": "#000000"
                                              },
                                              {
                                                "contents": [
                                                  {
                                                    "contents": [
                                                      {
                                                        "url": "https://sv1.picz.in.th/images/2020/02/02/RIHB3J.png",
                                                        "type": "icon",
                                                        "size": "md"
                                                      },
                                                      {
                                                        "text":"{}".format(str(ret)),
                                                        "size": "sm",
                                                        "margin": "none",
                                                        "color": "#6F4E37",
                                                        "wrap": True,
                                                        "weight": "regular",
                                                        "type": "text"
                                                      }
                                                    ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                                  }
                                                ],          
                                                "type": "box",
                                                "layout": "vertical"
                                              }
                                            ],
                                            "type": "box",
                                            "spacing": "md",
                                            "layout": "vertical"
                                        },
                                        "footer": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [
                                            {
                                                "type": "button",
                                                "style": "link",
                                                "height": "sm",
                                                "action": {
                                                    "type": "uri",
                                                    "label": "ติดต่อสอบถาม กดที่นี่",
                                                    "uri": "https://line.me/ti/p/~0969245004",
                                                }
                                        },
                                        {
                                            "type": "spacer",
                                            "size": "sm",
                                        }
                                    ],
                                    "flex": 0
                                    }
                                }
                            }
                            sendTemplate(to, data)
              
                elif text.lower() == "คู่มือ" or text.lower() == "บริการหลังการขาย":     
                            ret = "─┅═✥🔘ᵀᴴᴬᴵᴸᴬᴺᴰ🔘✥═┅─\n"                                                           
                            ret += "╠══════════════════\n"
                            ret += "╠    T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣\n"
                            ret += "╠     🦁[ แจ้งลูกค้าบอท]🦁\n"
                            ret += "╠══════════════════\n"
                            ret += "╠📌คู่มือการใช้งานบอท เบื้องต้น\n"
                            ret += "╠📌พิมคำว่า Help หรือ คำสั่ง\n"
                            ret += "╠📌ต้องการดูการตั้งค่าพิม เชคค่า\n"
                            ret += "╠📌ให้พิมตามใบคำสั่งเป๊ะๆนะคับ\n"
                            ret += "╠══════════════════\n"
                            ret += "╠📌ส่วนคำสั่งเฉพาะกลุ่ม\n"
                            ret += "╠📌ต้องการป้องกันกลุ่มไหน\n"
                            ret += "╠📌ให้พิมลงกลุ่มนั้น\n"
                            ret += "╠══════════════════\n"
                            ret += "╠▶⚡บริการหลังการขาย⚡\n"
                            ret += "╠══════════════════\n"
                            ret += "╠▶หากลูกค้า ต้องการเปลี่ยนรูป\n"
                            ret += "╠▶ เปลี่ยนสี เปลี่ยนชื่อบอท\n"
                            ret += "╠▶ติดต่อคนขายได้ทันทีคับ\n"
                            ret += "╠▶มีค่าไช้จ่ายเพียงไม่กี่บาท\n"
                            ret += "╠══════════════════\n"
                            ret += "╠▶หากบอทมีปัญหา\n"
                            ret += "╠▶บอทไม่ตอบ ขอลิ้งไม่ได้\n"
                            ret += "╠▶⚡แจ้งคนขายได้24ชม.คับ\n"
                            ret += "╠══════════════════\n"
                            ret += "╠▶🚫กรณีลูกค้า แก้ไขดัดแปลงไฟล์\n"                           
                            ret += "╠▶🚫ทางเราขอไม่รับผิดชอบไดๆทั้งสิ้น\n"
                            ret += "╠══════════════════\n"
                            ret += "╠💢 T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣\n"
                            ret += "╠═══════════════════\n"
                            ret += "╚══[ T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣]\n"                           
                            hello = "{}".format(str(ret))
                            data = {
                                    "type": "flex",
                                    "altText": "โฆษณา",
                                        "contents": {
                                        "styles": {
                                        "body": {
                                        "backgroundColor": "#FFFFFF"
                                        },
                                        "footer": {
                                          "backgroundColor": "#000000"
                                        }
                                        },
                                            "type": "bubble",
                                                "hero": {
                                                    "type": "image",
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RMAxZI.jpg",
                                                    "size": "full",
                                                    "aspectRatio": "20:13",
                                                    "aspectMode": "cover",
                                                },
                                            "body": {
                                            "contents": [
                                              {
                                                "contents": [
                                                  {
                                                    "url": "https://sv1.picz.in.th/images/2020/02/02/RIHB3J.png",
                                                    "type": "image"
                                                  },
                                                ],
                                                "type": "box",
                                                "spacing": "sm",
                                                "layout": "vertical"
                                              },
                                              {
                                                "type": "separator",
                                                "color": "#000000"
                                              },
                                              {
                                                "contents": [
                                                  {
                                                    "text": "SELFBOT LINE 2020",
                                                    "size": "xl",
                                                    "align": "center",
                                                    "color": "#000000",
                                                    "wrap": True,
                                                    "weight": "bold",
                                                    "type": "text"
                                                  }
                                                ],
                                                "type": "box",
                                                "spacing": "sm",
                                                "layout": "vertical"
                                              },
                                              {
                                                "type": "separator",
                                                "color": "#000000"
                                              },
                                              {
                                                "contents": [
                                                  {
                                                    "contents": [
                                                      {
                                                        "url": "https://sv1.picz.in.th/images/2020/02/02/RIHB3J.png",
                                                        "type": "icon",
                                                        "size": "md"
                                                      },
                                                      {
                                                        "text":"{}".format(str(ret)),
                                                        "size": "sm",
                                                        "margin": "none",
                                                        "color": "#6F4E37",
                                                        "wrap": True,
                                                        "weight": "regular",
                                                        "type": "text"
                                                      }
                                                    ],
                                                    "type": "box",
                                                    "layout": "baseline"
                                                  }
                                                ],          
                                                "type": "box",
                                                "layout": "vertical"
                                              }
                                            ],
                                            "type": "box",
                                            "spacing": "md",
                                            "layout": "vertical"
                                        },
                                        "footer": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [
                                            {
                                                "type": "button",
                                                "style": "link",
                                                "height": "sm",
                                                "action": {
                                                    "type": "uri",
                                                    "label": "ติดต่อคนขาย กดที่นี่",
                                                    "uri": "https://line.me/ti/p/~0969245004",
                                                }
                                        },
                                        {
                                            "type": "spacer",
                                            "size": "sm",
                                        }
                                    ],
                                    "flex": 0
                                    }
                                }
                            }
                            sendTemplate(to, data)                                               
#-------------------------------------------------------------------------------                   
                if text.lower() == 'ยกเชิญ':
                                    if msg.toType == 2:
                                        group = line.getGroup(receiver)
                                        gMembMids = [contact.mid for contact in group.invitee]
                                        k = len(gMembMids)//30
                                        line.sendMessage(msg.to,"👉 สมาชิคค้างเชิญจำนวน {} คน👈 \n\nโปรดรอสักครู่...".format(str(len(gMembMids))))
                                        num=1
                                        for i in range(k+1):
                                            for j in gMembMids[i*30 : (i+1)*30]:
                                                time.sleep(random.uniform(0.5,0.4))
                                                line.cancelGroupInvitation(msg.to,[j])
                                                print ("[Command] "+str(num)+" => "+str(len(gMembMids))+" cancel members")
                                                num = num+1
                                            line.sendMessage(receiver,"พัก 10-15 วินาที🕛แล้วจะยกค้างเชิญต่ออีก 30 คนจนก่วาจะหมด")
                                            time.sleep(random.uniform(15,10))
                                        line.sendMessage(receiver,"👉 ยกค้างเชิญ จำนวน {} คน เรียบร้อยแล้ว👏".format(str(len(gMembMids))))
                                        time.sleep(random.uniform(0.95,1))
                                        line.sendMessage(receiver, None, contentMetadata={"STKID": "52114113","STKPKGID": "11539","STKVER": "1" }, contentType=7)
                                        gname = line.getGroup(receiver).name
                                        line.sendMessage(Notify,"👉 ยกค้างเชิญ >> "+gname+"  <<👏 \n จำนวน {} คน เรียบร้อยแล้ว👏\n".format(str(len(gMembMids))))
                                        time.sleep(random.uniform(0.95,1))
                                        line.leaveGroup(receiver)
                                								
                                    line.sendMessage(receiver,"[ไม่มีคนให้ผมยกเชิญ ลาก๋อย]")
                                    line.sendMessage(receiver, None, contentMetadata={"STKID": "52114113","STKPKGID": "11539","STKVER": "1" }, contentType=7)
                                    line.leaveGroup(receiver)
#=================================
                elif text.lower() == 'แทคล่องหน':
                    gs = line.getGroup(to)
                    targets = []
                    for g in gs.members:
                        if g.displayName in "":
                            targets.append(g.mid)
                    if targets == []:
                        line.sendMessage(to, "🤔แน๊ะไม่มีคนใส่ร่องหนในกลุ่มนี้😂")
                    else:
                        mc = ""
                        for target in targets:
                            mc += sendMessageWithMention(to,target) + "\n"
                        line.sendMessage(to, mc)
                elif text.lower() == 'มิดล่องหน':
                    gs = line.getGroup(to)
                    lists = []
                    for g in gs.members:
                        if g.displayName in "":
                            lists.append(g.mid)
                    if lists == []:
                        line.sendMessage(to, "🤗ไม่มีmidคนใส่ร่องหน🤗")
                    else:
                        mc = ""
                        for mi_d in lists:
                            mc += "->" + mi_d + "\n"
                        line.sendMessage(to,mc)
                elif text.lower() == 'คทล่องหน':
                    gs = line.getGroup(to)
                    lists = []
                    for g in gs.members:
                        if g.displayName in "":
                            lists.append(g.mid)
                    if lists == []:
                        line.sendMessage(to, "🤔แน๊ะไม่มีคนใส่ร่องหนในกลุ่มนี้😂")
                    else:
                        for ls in lists:
                            contact = line.getContact(ls)
                            mi_d = contact.mid
                            line.sendContact(to, mi_d)

                elif msg.text.lower().startswith("พูด "):
                    sep = text.split(" ")
                    say = text.replace(sep[0] + " ", "")
                    lang = 'th'
                    tts = gTTS(text=say, lang=lang)
                    tts.save("hasil.mp3")
                    line.sendAudio(to, "hasil.mp3")
#-------------------------------------------------------------------------
                elif msg.text.lower().startswith("ยูทูป "):
                            sep = text.split(" ")
                            search = text.replace(sep[0] + " ","")
                            r = requests.get("https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=10&q={}&type=video&key=AIzaSyAF-_5PLCt8DwhYc7LBskesUnsm1gFHSP8".format(str(search)))
                            data = r.text
                            a = json.loads(data)
                            if a["items"] != []:
                                ret_ = []
                                yt = []
                                for music in a["items"]:
                                    ret_.append({
                                        "type": "bubble",
                                        "styles": {
                                            "header": {
                                                "backgroundColor": "#66FFFF"
                                            },
                                            "body": {
                                               "backgroundColor": "#ffffff",
                                               "separator": True,
                                               "separatorColor": "#FFFFFF"
                                            },
                                            "footer": {
                                                "backgroundColor": "#66FFFF",
                                                "separator": True,
                                               "separatorColor": "#66FFFF"
                                           }
                                        },
                                        "header": {
                                            "type": "box",
                                            "layout": "baseline",
                                            "contents": [
                                                    {
                                                        "type": "icon",
                                                        "url": 'https://sv1.picz.in.th/images/2019/08/08/KIIbGy.jpg',
                                                        "size": "xl"
                                                    },
                                                   {
                                                    "type": "text",
                                                    "text": "••••   🌟YOUTUBE 🌟  ••••",
                                                     "margin": "xxl",
                                                    "weight": "bold",
                                                    "color": "#000000",
                                                    "size": "sm"
                                                }
                                            ]
                                        },
                                        "hero": {
                                            "type": "image",
                                            "url": "https://i.ytimg.com/vi/{}/maxresdefault.jpg".format(music['id']['videoId']),
                                            "size": "full",
                                            "aspectRatio": "20:13",
                                            "aspectMode": "cover",
                                            "action": {
                                                "type": "uri",
                                                "uri": "line://app/1560169633-yaJ7kAZB?type=text&text=🌟🌟•คาราวะพี่แบงค์•🌟🌟"
                                            }
                                        },
                                        "body": {
                                            "type": "box",
                                            "spacing": "md",
                                            "layout": "horizontal",
                                            "contents": [{
                                                "type": "box",
                                                "spacing": "none",
                                                "flex": 1,
                                                "layout": "vertical",
                                                "contents": [{
                                                    "type": "image",
                                                    "url": "https://cdn2.iconfinder.com/data/icons/social-icons-circular-color/512/youtube-512.png",
                                                    "aspectMode": "cover",
                                                    "gravity": "bottom",
                                                    "size": "sm",
                                                    "aspectRatio": "1:1",
                                                    "action": {
                                                      "type": "uri",
                                                      "uri": "https://www.youtube.com/watch?v=%s" % music['id']['videoId']
                                                    }
                                                }]
                                            }, {
                                                "type": "separator",
                                                "color": "#000000"
                                            }, {
                                                "type": "box",
                                                "contents": [{
                                                    "type": "text",
                                                    "text": "Title",
                                                    "color": "#000000",
                                                    "size": "md",
                                                    "weight": "bold",
                                                    "flex": 1,
                                                    "gravity": "top"
                                                }, {
                                                    "type": "text",
                                                    "text": "%s" % music['snippet']['title'],
                                                    "color": "#000000",
                                                    "size": "sm",
                                                    "weight": "bold",
                                                    "flex": 3,
                                                    "wrap": True,
                                                    "gravity": "top"
                                                }],
                                                "flex": 2,
                                                "layout": "vertical"
                                            }]
                                        },
                                        "footer": {
                                            "type": "box",
                                            "layout": "vertical",
                                            "contents": [{
                                                "type": "box",
                                                "layout": "horizontal",
                                                "contents": [{
                                                    "type": "button",
                                                    "flex": 2,
                                                    "style": "primary",
                                                    "color": "#000000",
                                                    "height": "sm",
                                                    "action": {
                                                        "type": "uri",
                                                        "label": "Page",
                                                        "uri": "https://www.youtube.com/watch?v={}".format(str(music['id']['videoId']))
                                                    }
                                                }, {
                                                    "flex": 3,
                                                    "type": "button",
                                                    "margin": "sm",
                                                    "style": "primary",
                                                    "color": "#000000",
                                                    "height": "sm",
                                                    "action": {
                                                        "type": "uri",
                                                        "label": "Mp3",
                                                        "uri": "line://app/1560169633-yaJ7kAZB?type=text&text=youtubemp3%20https://www.youtube.com/watch?v={}".format(str(music['id']['videoId']))
                                                    }
                                                }]
                                            }, {
                                                "type": "button",
                                                "margin": "sm",
                                                "style": "primary",
                                                "color": "#000000",
                                                "height": "sm",
                                                "action": {
                                                    "type": "uri",
                                                    "label": "Mp4",
                                                    "uri": "line://app/1560169633-yaJ7kAZB?type=text&text=youtubemp4%20https://www.youtube.com/watch?v={}".format(str(music['id']['videoId']))
                                                }
                                            }]
                                        }
                                    }
                                )
                                    yt.append('https://www.youtube.com/watch?v=' +music['id']['videoId'])
                                k = len(ret_)//10
                                for aa in range(k+1):
                                    data = {
                                        "type": "flex",
                                        "altText": "☆• Youtube AVENGERS •☆",
                                        "contents": {
                                            "type": "carousel",
                                            "contents": ret_[aa*10 : (aa+1)*10]
                                        }
                                    }
                                    sendTemplate(to, data)
#gif pic-------------------------------------------------------------------------------------------------------------------------------
                elif msg.text in ["แดนช์","แดนซ์","เอจังแดนช์","dance1","เอจังแดนซ์"]:
                   chivaree={"type":"template","altText":"✯ Chivaree Sticker ✯","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/01/13/9VpXa2.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1560169633-yaJ7kAZB?type=text&text=••✯%20AVENGERS%20✯••",}}]}}
                   sendTemplate(to, chivaree)
#============= โหมดกิฟสติ้กเกอร์ ==============================================================================================    
                elif msg.text in ["นักฆ่า"]:
                   chivaree1={"type":"template","altText":"✯ NN Sticker ✯","template":{
                     "type":"image_carousel","columns":[{"imageUrl":"https://img.live/images/2019/01/03/a019.gif","size":"xxxl","aspectRatio":"1:2","action":{
                             "type":"uri","uri": "line://app/1560169633-yaJ7kAZB?type=text&text=••✯%20AVENGERS%20✯••",}}]}}
                   chivaree2={"type":"template","altText":"✯ NN ✯","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/01/13/9VL3pa.gif",
                                       "size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1560169633-yaJ7kAZB?type=text&text=••✯%20™AVENGERS%20✯••",}}]}}
                   sendTemplate(to, chivaree1)
                   sendTemplate(to, chivaree2)
                elif msg.text in ["บึ้ม","บ้านบึ้ม"]:
                   chivaree={"type":"template","altText":"✯ NN Sticker ✯","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/02/07/TQsIAy.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1560169633-yaJ7kAZB?type=text&text=••✯%20AVENGERS%20✯••",}}]}}
                   sendTemplate(to, chivaree)
                elif text.lower() == "เค้าสั่น":
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/01/13/9VmsQW.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)
                elif text.lower() == "เค้างง":
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/01/13/9VmeZR.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)
                elif msg.text in ["เค้าดีใจ","เย้ๆ"]:
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/01/13/9Vmms0.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)
                elif text.lower() == "เค้าเขิล":
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://img.live/images/2019/01/02/chivaree3.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)
                elif msg.text in ["เค้าอาย"]:
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/01/13/9VmI9Z.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)
                elif text.lower() == "เค้าเชื่อ":
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/01/13/9VySrl.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)
                elif text.lower() == "เค้าโอเค":
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://img.live/images/2019/01/02/chivaree78.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)
                elif text.lower() == "เค้าไม่เถียง":
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/01/13/9Vvzdu.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟??",}}]}}
                   sendTemplate(to, data)
                elif msg.text in ["เค้าเผ่น","วิ่งๆ","เผ่นสิ"]:
                   data={"type":"template","altText":"🌟?? NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/01/12/9Hj89n.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)
                elif text.lower() == "เค้าเครียด":
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/01/13/9X4Vjl.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)
                elif msg.text in ["เค้าหิว"]:
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/01/13/9VvMFQ.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)
                elif text.lower() == "เค้าพร้อม":
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://img.live/images/2019/01/03/a011.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)
                elif text.lower() == "เค้าชอบ":
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/01/13/9X4Wxu.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)                  
                elif msg.text in ["อาบน้ำ","เค้าอาบน้ำ"]:
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/01/13/9Vvoyb.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)                  
                elif text.lower() == "เค้าจะเอา":
                   data={"type":"template","altText":"??🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/01/13/9X4dnZ.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)                 
                elif text.lower() == "จัดไป":
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/08/11/ZSGn2t.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)                 
                elif msg.text in ["โยก","โยกๆ"]:
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/08/11/ZSGHTl.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)                  
                elif msg.text in ["ว้าว","ว้าวว"]:
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/08/11/ZSGItW.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)                     
                elif msg.text in ["ขอบคุณ","ขอบคุน"]:
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/08/11/ZSJt50.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)                      
                elif msg.text in ["เห้อ","เห้ออ"]:
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/08/11/ZSJsJ2.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)                      
                elif msg.text in ["เศร้า","เบื่อ"]:
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/08/11/ZSJvLz.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)                   
                elif msg.text in ["โอเค","โอเคร"]:
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/08/11/ZSJIuI.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)                    
                elif msg.text in ["กัปตัน","แคป"]:
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/08/11/ZSewZI.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)                    
                elif msg.text in ["วานด้า","วันด้า"]:
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/08/11/ZSe1sP.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)                 
                elif msg.text in ["แนท","นาตาชา"]:
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/08/11/ZSec9e.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)                    
                elif msg.text in ["ฟรุ้งฟริ้ง","มุ้งมิ้ง"]:
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/08/11/ZSeQUE.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)                    
                elif msg.text in ["ยิง","เหอะ"]:
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/08/11/ZSebyn.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)                    
                elif msg.text in ["บาย","ไปละ"]:
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/08/11/ZSesUy.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)                
                elif msg.text in ["หึหึ","ธานอส"]:
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/08/11/ZSeGH0.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)                 
                elif msg.text in ["เย่","ธอร์"]:
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/08/11/ZSmgIb.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)                   
                elif msg.text in ["เบิดเดย์","วันเกิด"]:
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/08/11/ZSmqhz.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)                    
                elif msg.text in ["ชอบ","ถูกใจ"]:
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/08/11/ZSm6Vv.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)                   
                elif msg.text in ["น่ารัก","น่ารักก"]:
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/08/11/ZSmrYE.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)                   
                elif msg.text in ["รัก","รักนะ"]:
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/08/11/ZSyqPS.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)                   
                elif msg.text in ["เหรอ","ใช่เหรอ"]:
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/08/11/ZSybbW.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)                    
                elif msg.text in ["ร้อน","ร้อนน"]:
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/08/11/ZSyja2.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)                   
                elif msg.text in ["จุฟ","จุฟๆ"]:
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/08/11/ZSFHtS.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)                  
                elif msg.text in ["สวัสดี","หวัดดี"]:
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/08/11/ZSFvq2.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)                  
                elif msg.text in ["โหล","ฮาโหล"]:
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/08/11/ZSFMof.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)                 
                elif msg.text in ["ฝันดี","ฝรรดี"]:
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/08/11/ZSI4i0.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)                 
                elif msg.text in ["เผ่น","เผ่นๆ"]:
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/08/11/ZSIZiE.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)                
                elif msg.text in ["เพลีย","เพลียย"]:
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/08/11/ZSMjae.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)                
                elif msg.text in ["เร็ว","ไวๆ"]:
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/08/11/ZSMo4l.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)               
                elif msg.text in ["ล้อเล่นๆ","ล้อเล่นๆๆ"]:
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/08/11/ZSMDQk.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)      
                elif msg.text in ["พิม่อน"]:
                   chivaree1={"type":"template","altText":"✯ NN Sticker ✯","template":{
                     "type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/08/17/Z9G3G9.gif","size":"xxxl","aspectRatio":"1:2","action":{
                             "type":"uri","uri": "line://app/1560169633-yaJ7kAZB?type=text&text=••✯%20AVENGERS%20✯••",}}]}}
                   chivaree2={"type":"template","altText":"✯ NN ✯","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/08/17/Z9GK7a.gif",
                                       "size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1560169633-yaJ7kAZB?type=text&text=••✯%20™AVENGERS%20✯••",}}]}}   
                   chivaree3={"type":"template","altText":"✯ NN ✯","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/08/17/Z9GgF8.gif",
                                       "size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1560169633-yaJ7kAZB?type=text&text=••✯%20™AVENGERS%20✯••",}}]}}     
                   sendTemplate(to, chivaree1)
                   sendTemplate(to, chivaree2)
                   sendTemplate(to, chivaree3)           
                elif msg.text in ["เหอะ","ต่าย"]:
                   data={"type":"template","altText":"🌟🌟 NN Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/08/17/ZThcTy.png","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•AVENGERS•🌟🌟",}}]}}
                   sendTemplate(to, data)     
                elif text.lower() == "กิฟ" or text.lower() == "คำสั่งกิฟ":
                    sas = "™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣\n"
                    sa = "• 🐷นักฆ่า \n"
                    sa += "• 🐷แดนซ์\n"
                    sa += "• 🐷บึ้ม\n"
                    sa += "• 🐷เค้าสั่น\n"
                    sa += "• 🐷เค้างง\n"
                    sa += "• 🐷เค้าดีใจ\n"
                    sa += "• 🐷เค้าเขิล\n"
                    sa += "• 🐷เค้าอาย\n"
                    sa += "• 🐷เค้าเชื่อ\n"
                    sa += "• 🐷เค้าโอเค\n"
                    sa += "• 🐷เค้าไม่เถียง\n"
                    sa += "• 🐷เค้าเผ่น\n"
                    sa += "• 🐷เค้าเครียด\n"
                    sa += "• 🐷เค้าหิว\n"
                    sa += "• 🐷เค้าพร้อม\n"
                    sa += "• 🐷เค้าชอบ\n"
                    sa += "• 🐷อาบน้ำ\n"
                    sa += "• 🐷เค้าจะเอา\n"
                    sa += "• 💓จัดไป\n"
                    sa += "• 💓โยก\n"
                    sa += "• 💓ว้าว\n"                  
                    sa += "• 💓ขอบคุณ\n"
                    sa += "• 💓เห้อ\n"
                    sa += "• 💓เศร้า\n"
                    sa += "• 💓โอเคร\n"
                    sa += "• 💓กัปตัน\n"
                    sa += "• 💓วันด้า\n"
                    sa += "• 💓แนท\n"
                    sa += "• 💓ฟรุ้งฟริ้ง\n"
                    sa += "• 💓ยิง\n"
                    sa += "• 💓บาย\n"
                    sa += "• 💓หึหึ\n"
                    sa += "• 💓เย่\n"
                    sa += "• 💓เบิดเดย์\n"
                    sa += "• 💓ถูกใจ\n"
                    sa += "• 💓น่ารัก\n"
                    sa += "• 💓รัก\n"
                    sa += "• 💓เหรอ \n"
                    sa += "• 💓ร้อน\n"
                    sa += "• 💓จุฟ\n"
                    sa += "• 💓สวัสดี\n"
                    sa += "• 💓ฮาโหล\n"
                    sa += "• 💓ฝันดี\n"
                    sa += "• 💓เผ่น\n"
                    sa += "• 💓เพลีย\n"
                    sa += "• 💓เร็ว\n"
                    sa += "• 💓ล้อเล่น\n"
                    helps = "{}".format(str(sa))
                    g = "https://sv1.picz.in.th/images/2020/01/28/Rv4Iyq.png"
                    data = {
                            "type": "flex",
                                    "altText": "MENU TEST",
                                        "contents": {
                                        "styles": {
                                        "header": {
                                        "backgroundColor":"#66FFFF"
                                        },
                                        "body": {
                                        "backgroundColor": "#FFFFFF"
                                        },
                                        "footer": {
                                          "backgroundColor": "#66FFFF"
                                        }
                                        },
                                        "type": "bubble",
                                        "header": {
                                        "type": "box",
                                        "layout": "horizontal",
                                        "contents": [
                                                           {
                                                            "type": "button",
                                                            "style": "secondary",
                                                            "color": "#FFFFFF",
                                                            "height": "sm",
                                                            "gravity": "center",
                                                            "flex": 1,
                                                            "action": {
                                                            "type": "uri",
                                                            "label": "คำสั่ง สติ้กเกอร์",
                                                            "uri": "line://app/1602687308-GXq4Vvk9?type=text&text=ติดต่อ"
                                                            }
                                                          },
                                                       ]
                                                   },
                                                   "body": {
                                                   "type": "box",
                                                   "layout": "horizontal",
                                                   "spacing": "md",
                                          "contents": [
                                          {
                                          "type": "box",
                                          "layout": "vertical",
                                          "flex": 0,
                                   "contents": [
                                   {
                                    "type": "image",
                                    "url": g,
                                    "gravity": "bottom"
                                    }
                                  ]
                               }, 
                            {
                             "type": "separator",
                             "color": "#FF9900"
                              }, 
                             {
                             "type": "box",
                             "layout": "vertical",
                             "flex": 2,
                      "contents": [
                      {
                       "type": "text",
                       "text": "{}".format(sa),
                       "color": "#000000",
                       "size": "sm",
                       "weight": "bold",
                      "flex": 3,
                      "wrap": True,
                     "gravity": "top"
                    }
                  ]
               }
            ]
         },
        "footer": {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                                           {
                                             "type": "button",
                                             "style": "secondary",
                                             "color": "#FFFFFF",
                                             "height": "sm",
                                             "gravity": "center",
                                             "flex": 1,
                                             "action": {
                                             "type": "uri",
                                             "label": "BOT TAG 2020",
                                             "uri": "https://line.me/ti/p/~0969245004",
                                            }
                                          },
                                        {
                                           "type": "spacer",
                                           "size": "sm",
                                         }
                                       ],
                                    "flex": 0
                                   }
                                }
                            }
                    sendTemplate(to, data)         
#-------------------------------------------------------------------------------------------------------------
                elif text.lower() == 'รีบอท':
                    nn2(to, "กำลังรีบอท... โปรดรอสักครู่ ...")
                    time.sleep(1)
                    nn2(to, "🐷 สำเร็จ 🐷")
                    restartBot()     
#Api---------------------------------------------------------------------------------------------------------------------#                    
                elif text.lower() == 'หลุด':
                    nn2(to, "🐷 หลุดได้งายย บอทเทพ 🐷") 
                    time.sleep(1)                   
                    nn2(to, "🐷❣️💓  BOT API  💓❣️🐷")                    
                elif text.lower() == 'งง':
                    nn2(to, "🐷 งงต่อไป..นะครับ 🐷") 
                    time.sleep(1)                    
                    nn2(to, "🐷❣️💓  BOT API  💓❣️🐷")   
                elif text.lower() == 'บอท':
                    nn2(to, "🐷           ว่ากะไรครับ         🐷") 
                    time.sleep(1)                    
                    nn2(to, "🐷❣️💓  BOT API  💓❣️🐷")       
                elif text.lower() == '.':
                    nn2(to, "?? จุดตะมาย 🐷") 
                    time.sleep(1)                   
                    nn2(to, "🐷❣️💓  BOT API  💓❣️🐷")    
                elif text.lower() == 'จุด':
                    nn2(to, "🐷 จุดตะมาย 🐷") 
                    time.sleep(1)                   
                    nn2(to, "🐷❣️💓  BOT API  💓❣️🐷")     
                elif text.lower() == 'กำ':
                    nn2(to, "🐷 กำแท้ๆ 🐷") 
                    time.sleep(1)                   
                    nn2(to, "🐷❣️💓  BOT API  💓❣️🐷")       
                elif text.lower() == 'ดีจ้า':
                    nn2(to, "🐷 สวัสดีจ้าาา 🐷") 
                    time.sleep(1)                   
                    nn2(to, "🐷❣️💓  BOT API  💓❣️🐷")    
                elif text.lower() == 'มอนิ่ง':
                    nn2(to, "🐷 มอนิ่งจ้า 🐷") 
                    time.sleep(1)                   
                    nn2(to, "🐷❣️💓  BOT API  💓❣️🐷")   
                elif text.lower() == 'ฝรรดี':
                    nn2(to, "?? ฝันดีผีกัดดาก 🐷") 
                    time.sleep(1)                   
                    nn2(to, "🐷❣️💓  BOT API  💓❣️🐷") 
                elif text.lower() == 'รอ':
                    nn2(to, "🐷 ไม่นานจ้า 23ชั่วโมงเอง 🐷") 
                    time.sleep(1)                   
                    nn2(to, "🐷❣️💓  BOT API  💓❣️🐷")     
                elif text.lower() == '5555':
                    nn2(to, "🐷 ขำขนาดนี้ไปขี้เถอะ 🐷") 
                    time.sleep(1)                   
                    nn2(to, "🐷❣️💓  BOT API  💓❣️🐷")
#-----------------------------------------------------------------------------------------------------
                elif msg.text in ["ควย","หี","แตด","เย็ด","ไอสัต","ไอ้สัต","เหี้ย","ไอเหี้ย","ไอ้เหี้ย","ควยไร","ไอ้ห่า","ห่า","ครวย","อีสัส","อีสัต","อีเหี้ย","ไอ้ควาย","ไอ่ควาย","อิสัส","สัส","โง่"]:
                    nn2(to, "🔇พบคำหยาบระบบเตะควายทำงาน🔇") 
                    time.sleep(0.9)                   
                    line.kickoutFromGroup(receiver,[sender])
                    time.sleep(1)
                    nn2(to, "🔇ระบบเทพเตะควาย🔇")
                elif msg.text in ["เชลไก่","กะจอก","กระจอก","เชลกระจอก","บอทเหี้ย","กาก","กากก","เชลกาก","พ่อมึงตาย","ไอ้เลว","ระยำ","ชาติหมา","หน้าหี","เซลกาก","ไอ้บอทกาก","ไอ้เหี้ยบอท","พ่องตาย","ส้นตีน","แม่มึงอ่ะ","แม่มึงดิ","พ่อมึงดิ","บอทกาก"]:
                    nn2(to, "🔇พบคำหยาบระบบเตะควายทำงาน🔇") 
                    time.sleep(0.9)                   
                    line.kickoutFromGroup(receiver,[sender])
                    time.sleep(1)
                    nn2(to, "🔇ระบบเทพเตะควาย🔇")                          
                elif msg.text in ["!kickall","/kickall","!บิน","!หีแตด","หีแตด","!!บิน","leanse","group cleansed.","mulai",".winebot",".kickall","mayhem","kick on","Kick","Kick","บิน","บินน","บินกลุ่ม","ลบสิริ"]:
                    nn2(to, "🔇พบคำสั่งบินระบบเตะควายทำงาน🔇") 
                    time.sleep(0.9)                   
                    line.kickoutFromGroup(receiver,[sender])
                    time.sleep(1)
                    nn2(to, "🔇ระบบเทพเตะควาย🔇")              
 #---------------------------------ลูกเล่น--------------------------------------------------------------------------------------#                            
                elif text.lower() == "เทส1":
                    nn1(to,"「 AVENGRES BOT」")
                    time.sleep(1)
                    kittySend(to, "█▒... 10.0%")
                    time.sleep(1)
                    kittySend(to, "███▒... 25.0%")
                    time.sleep(1)
                    kittySend(to, "█████▒... 50.0%")
                    time.sleep(1)
                    kittySend(to, "███████▒... 75.0%")
                    time.sleep(1)
                    kittySend(to, "███████████..100.0%")  
                    time.sleep(1)
                    kittySend(to,"「👉บอทยังทำงานจ้าา👈」")   

                elif msg.text in ["เทส2","เทสบอท2"]:
                    chivaree1={
                       "type": "flex","altText": "☆•A-jang Test•☆","contents": { "type": "bubble",     
                       "body": {"type": "box","layout": "vertical",   "contents": [{"type": "text","text": "•••🌟🌟🌟 4 🌟🌟🌟•••","color": "#ffffff","align": "center","size": "xs"}]},
                       "styles": {"body": {"backgroundColor": "#ff0000"},"footer": {"backgroundColor": "#ffffff","separator": True,"separatorColor": "#000000"}}}}
                       
                    chivaree2={
                       "type": "flex","altText": "☆•A-jang API•☆","contents": { "type": "bubble",     
                       "body": {"type": "box","layout": "vertical",   "contents": [{"type": "text","text": "•••🌟🌟🌟 3 🌟🌟🌟•••","color": "#ff0099","align": "center","size": "xs"}]},
                       "styles": {"body": {"backgroundColor": "#ffffff"},"footer": {"backgroundColor": "#ffffff","separator": True,"separatorColor": "#000000"}}}}
                       
                    chivaree3={
                       "type": "flex","altText": "☆•A-jang API•☆","contents": { "type": "bubble",     
                       "body": {"type": "box","layout": "vertical",   "contents": [{"type": "text","text": "•••🌟🌟🌟 2 🌟🌟🌟•••","color": "#ffffff","align": "center","size": "xs"}]},
                       "styles": {"body": {"backgroundColor": "#0000ff"},"footer": {"backgroundColor": "#ffffff","separator": True,"separatorColor": "#000000"}}}}
                       
                    chivaree4={
                       "type": "flex","altText": "☆•A-jang API•☆","contents": { "type": "bubble",     
                       "body": {"type": "box","layout": "vertical",   "contents": [{"type": "text","text": "•••🌟🌟🌟 1 🌟🌟🌟•••","color": "#ff0099","align": "center","size": "xs"}]},
                       "styles": {"body": {"backgroundColor": "#ffffff"},"footer": {"backgroundColor": "#ffffff","separator": True,"separatorColor": "#000000"}}}}
                    
                    chivaree5={
                       "type": "flex","altText": "☆•Test API•☆","contents": { "type": "bubble",     
                       "body": {"type": "box","layout": "vertical",   "contents": [{"type": "text","text": "••🌟™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣🌟••","color": "#ffffff","align": "center","size": "xs"}]},
                       "styles": {"body": {"backgroundColor": "#ff0000"},"footer": {"backgroundColor": "#ffffff","separator": True,"separatorColor": "#000000"}}}}

                    sendTemplate(to, chivaree1)
                    time.sleep(1)
                    sendTemplate(to, chivaree2)
                    time.sleep(1)
                    sendTemplate(to, chivaree3)
                    time.sleep(1)
                    sendTemplate(to, chivaree4)
                    time.sleep(1)
                    sendTemplate(to, chivaree5)
                    
                elif msg.text in ["เทส3","เทส"]:
                    nn2(to, "▒........0%")   
                    time.sleep(1)
                    nn2(to, "█▒... 10.0%") 
                    time.sleep(1)                   
                    nn2(to, "██▒... 20.0%")
                    time.sleep(1)                   
                    nn2(to, "███▒... 30.0%")
                    time.sleep(1)
                    nn2(to, "████▒... 40.0%")
                    time.sleep(1)
                    nn2(to, "█████▒... 50.0%")
                    time.sleep(1)
                    nn2(to, "██████▒... 60.0%") 
                    time.sleep(1)
                    nn2(to, "███████▒... 70.0%") 
                    time.sleep(1)
                    nn2(to, "████████▒... 80.0%") 
                    time.sleep(1)
                    nn2(to, "█████████▒... 90.0%")  
                    time.sleep(1)
                    nn2(to, "███████████..100.0%")
                    time.sleep(1)
                    kittyText(to, "🌟 บอทเทพพร้อมทำงานคับ 🌟")       
#----------------------------------------------------------------------------------------------------#                      
                elif text.lower() == "เทสบอท" or text.lower() == "คำสั่งเทส":
                    sas = "™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣\n"
                    sa = "• 🐷 เทส \n"
                    sa += "• 🐷 เทส1\n"
                    sa += "• 🐷 เทส2\n"
                    sa += "• 🐷 เทส3\n"
                    sa += "• 🐷 เทสบอท\n"                    
                    helps = "{}".format(str(sa))
                    g = "https://sv1.picz.in.th/images/2020/01/28/Rv4Iyq.png"                 
                    data = {
                            "type": "flex",
                                    "altText": "MENU TEST",
                                        "contents": {
                                        "styles": {
                                        "header": {
                                        "backgroundColor":"#66FFFF"
                                        },
                                        "body": {
                                        "backgroundColor": "#FFFFFF"
                                        },
                                        "footer": {
                                          "backgroundColor": "#66FFFF"
                                        }
                                        },
                                        "type": "bubble",
                                        "header": {
                                        "type": "box",
                                        "layout": "horizontal",
                                        "contents": [
                                                           {
                                                            "type": "button",
                                                            "style": "secondary",
                                                            "color": "#FFFFFF",
                                                            "height": "sm",
                                                            "gravity": "center",
                                                            "flex": 1,
                                                            "action": {
                                                            "type": "uri",
                                                            "label": "คำสั่ง เทสบอท",
                                                            "uri": "line://app/1602687308-GXq4Vvk9?type=text&text=ติดต่อ"
                                                            }
                                                          },
                                                       ]
                                                   },
                                                   "body": {
                                                   "type": "box",
                                                   "layout": "horizontal",
                                                   "spacing": "md",
                                          "contents": [
                                          {
                                          "type": "box",
                                          "layout": "vertical",
                                          "flex": 0,
                                   "contents": [
                                   {
                                    "type": "image",
                                    "url": g,
                                    "gravity": "bottom"
                                    }
                                  ]
                               }, 
                            {
                             "type": "separator",
                             "color": "#FF9900"
                              }, 
                             {
                             "type": "box",
                             "layout": "vertical",
                             "flex": 2,
                      "contents": [
                      {
                       "type": "text",
                       "text": "{}".format(sa),
                       "color": "#000000",
                       "size": "sm",
                       "weight": "bold",
                      "flex": 3,
                      "wrap": True,
                     "gravity": "top"
                    }
                  ]
               }
            ]
         },
        "footer": {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                                           {
                                             "type": "button",
                                             "style": "secondary",
                                             "color": "#FFFFFF",
                                             "height": "sm",
                                             "gravity": "center",
                                             "flex": 1,
                                             "action": {
                                             "type": "uri",
                                             "label": "BOT TAG 2020",
                                             "uri": "https://line.me/ti/p/~0969245004",
                                            }
                                          },
                                        {
                                           "type": "spacer",
                                           "size": "sm",
                                         }
                                       ],
                                    "flex": 0
                                   }
                                }
                            }
                    sendTemplate(to, data)                               
#----------------------------------------------------------------------------#                    
                elif msg.text in ["ด่า","บอทด่า"]:
                    nn2(to, "🌟Now Loding.......🌟")   
                    time.sleep(1)
                    nn2(to, "❂•••• ไอ้ผีฉีกเรียน ••••❂") 
                    time.sleep(1)                   
                    nn2(to, "❂••• อีคางคกเห็นผี •••❂")
                    time.sleep(1)                   
                    nn2(to, "❂•• อีจระเข้เดินห้าง ••❂")
                    time.sleep(1)
                    nn2(to, "❂••••• ไอ้แกงบูด: •••••❂")
                    time.sleep(1)
                    nn2(to, "❂•••  อีสุวรรณมาลี  •••❂")
                    time.sleep(1)
                    nn2(to, "❂••• ไอ้ไก่ดุดพรก ••••❂") 
                    time.sleep(1)
                    nn2(to, "❂•••••ไอ้แตดสีรุ้ง •••••❂") 
                    time.sleep(1)
                    nn2(to, "❂•••• ไอ้ขี้มูกเขียว ••••❂") 
                    time.sleep(1)
                    nn2(to, "❂••••• ไอ้ผีขบส้ม •••••❂")  
                    time.sleep(1)
                    nn2(to, "❂••ไอ้หัวล้านใส่เยล ••❂")   
                    time.sleep(1)                   
                    nn2(to, "❂•อีหนังหน้าปลาจวด•❂") 
                    time.sleep(1)
                    nn2(to, "❂••• อีโกดังเก็บศพ •••❂") 
                    time.sleep(1)
                    nn2(to, "❂••• อีแย้แดกแห้ว: •••❂") 
                    time.sleep(1)
                    nn2(to, "❂• อีหลุมดำจักรวาล: •❂")  
                    time.sleep(1)
                    nn2(to, "❂• ไอ้สะตอโปรตุเกส •❂")  
                    time.sleep(1)
                    nn1(to, "❂• อีดาวเทียมไทคม: •❂\n💖 แม่งเสือกทุกสถานี 💖\n      จบข่าว แง๊นๆ~⭐")        

                elif msg.text in ["เอจังนับ","นับ"]:
                    nn2(to,"™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣")
                    time.sleep(1)
                    nn2(to,"❂➣-รอสักครู่คับ.......")
                    time.sleep(1)
                    nn2(to,"💖:::⭐ 1 ⭐:::💖")
                    time.sleep(1)
                    nn2(to,"💚:::⭐ 2 ⭐:::💚")
                    time.sleep(1)
                    nn2(to,"💙:::⭐ 3 ⭐:::💙")
                    time.sleep(1)
                    nn2(to,"💔:::⭐ 4 ⭐:::💔")
                    time.sleep(1)
                    nn2(to,"💖:::⭐ 5 ⭐:::💖")
                    time.sleep(1)
                    nn2(to,"💚:::⭐ 6 ⭐:::💚")
                    time.sleep(1)
                    nn2(to,"💙:::⭐ 7 ⭐:::💙")
                    time.sleep(1)
                    nn2(to,"💔:::⭐ 8 ⭐:::💔")
                    time.sleep(1)
                    nn2(to,"💖:::⭐ 9 ⭐:::💖")
                    time.sleep(1)
                    nn2(to,"💚:::⭐ 0 ⭐:::💚")       

                elif msg.text in ["เอจังนับจีน","นับจีน"]:
                    nn2(to,"™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣")
                    time.sleep(1)
                    nn2(to,"❂➣-รอสักครู่คับ....")
                    time.sleep(1)
                    nn2(to,"💖:::⭐ ขอโทษ ⭐:::💖")
                    time.sleep(1)
                    nn2(to,"💚:::⭐ ครับ ⭐:::💚")
                    time.sleep(1)
                    nn2(to,"💙:::⭐ ผม ⭐:::💙")
                    time.sleep(1)
                    nn2(to,"💔:::⭐ นับ ⭐:::💔")
                    time.sleep(1)
                    nn2(to,"💖:::⭐ จีน ⭐:::💖")
                    time.sleep(1)
                    nn2(to,"💖:::⭐ ไม่⭐:::💖")
                    time.sleep(1)
                    nn2(to,"💚:::⭐ ได้ ⭐:::💚")
                    time.sleep(1)
                    nn2(to,"💙:::⭐ โว้ย ⭐:::💙")
                    time.sleep(1)
                    nn2(to,"🌟ไอ้บ้า 🕒 " +datetime.today().strftime('%H:%M:%S')+ "🌟")         

                elif msg.text in ["เอจังนับไทย","นับไทย"]:
                    nn2(to,"™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣")
                    time.sleep(1)
                    nn2(to,"❂➣-รอสักครู่คับ........")
                    time.sleep(1)
                    nn2(to,"💖:::⭐ ๑ ⭐:::💖")
                    time.sleep(1)
                    nn2(to,"💚:::⭐ ๒ ⭐:::💚")
                    time.sleep(1)
                    nn2(to,"💙:::⭐ ๓ ⭐:::💙")
                    time.sleep(1)
                    nn2(to,"💔:::⭐ ๔ ⭐:::💔") 
                    time.sleep(1)
                    nn2(to,"💖:::⭐ ๕ ⭐:::💖") 
                    time.sleep(1)
                    nn2(to,"💚:::⭐ ๖ ⭐:::💚")
                    time.sleep(1)
                    nn2(to,"💙:::⭐ ๗ ⭐:::💙")  
                    time.sleep(1)
                    nn2(to,"💔:::⭐ ๘ ⭐:::💔")
                    time.sleep(1)
                    nn2(to,"💖:::⭐ ๙ ⭐:::💖")
                    time.sleep(1)
                    nn2(to,"💚:::⭐ 0 ⭐:::💚")
                    time.sleep(1)
                    nn2(to,"✥ ขอบพระทัยเจ้าค่ะ ✥")          

                elif msg.text in ["เอจังนับอังกฤษ","นับอังกฤษ"]:
                    nn2(to,"™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣")
                    time.sleep(1)
                    nn2(to,"❂➣-รอสักครู่คับ.......")
                    time.sleep(1)
                    nn2(to,"💖⭐ ••One•• ⭐💖")
                    time.sleep(1)
                    nn2(to,"💚⭐ ••Two•• ⭐💚")
                    time.sleep(1)
                    nn2(to,"💙⭐ •Three• ⭐💙")
                    time.sleep(1)
                    nn2(to,"💔⭐  •Four•  ⭐💔")
                    time.sleep(1)
                    nn2(to,"💖⭐ ••Five•• ⭐??")
                    time.sleep(1)
                    nn2(to,"💚⭐ •••Six••• ⭐💚")
                    time.sleep(1)
                    nn2(to,"💙⭐ •Seven• ⭐💙")
                    time.sleep(1)
                    nn2(to,"💔⭐  •Eight•  ⭐💔")
                    time.sleep(1)
                    nn2(to,"💖⭐ ••Nine•• ⭐💖")
                    time.sleep(1)
                    nn2(to,"💚⭐ ••Zero•• ⭐💚")
                    time.sleep(1)
                    nn2(to,"■•■•■• OK •■•■•■") 

                elif msg.text in ["เอจังนับอินโด","นับอินโด"]:
                    nn2(to,"™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣")
                    time.sleep(1)
                    nn2(to,"❂➣-รอสักครู่คับ..................")
                    time.sleep(1)
                    nn2(to,"💖⭐1 •••Satu••• 1⭐💖")
                    time.sleep(1)
                    nn2(to,"💚⭐2••••Dua••••2⭐💚")
                    time.sleep(1)
                    nn2(to,"💙⭐3 •••Tiga••• 3⭐💙")
                    time.sleep(1)
                    nn2(to,"💔⭐4 ••Empat••4⭐💔")
                    time.sleep(1)
                    nn2(to,"💖⭐5  ••Lima••  5⭐💖")
                    time.sleep(1)
                    nn2(to,"💚⭐6•••Enam•••6⭐💚")
                    time.sleep(1)
                    nn2(to,"💙⭐7  ••Tujuh•• 7⭐💙")
                    time.sleep(1)
                    nn2(to,"💔⭐8 •Delapan•8⭐💔")
                    time.sleep(1)
                    nn2(to,"💖⭐9 Sembilan 9⭐💖")
                    time.sleep(1)
                    nn2(to,"💚⭐0 ••••Nol•••• 0⭐💚")
                    time.sleep(1)
                    nn2(to,"nn@Indo 🕒 " +datetime.today().strftime('%H:%M:%S')+ "™")

                elif msg.text in ["เอจังนับสเปน","นับสเปน"]:
                    nn2(to,"™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣")
                    time.sleep(1)
                    nn2(to,"❂➣-รอสักครู่คับ......")
                    time.sleep(1)
                    nn2(to,"1.❂•••  รีลมาดริด")
                    time.sleep(1)
                    nn2(to,"2.❂••• บาเซโลน่า")
                    time.sleep(1)
                    nn2(to,"3.❂••• บาเลนเซีย")
                    time.sleep(1)
                    nn2(to,"4.❂•• แอตมาดริด")
                    time.sleep(1)
                    nn2(to,"5.❂•• ลาคอรุนญ่า")
                    time.sleep(1)
                    nn2(to,"6.❂••เอสปันญ่อล")
                    time.sleep(1)
                    nn2(to,"7.❂•••  โอซาซูน่า")
                    time.sleep(1)
                    nn2(to,"8.❂••• ซาราโกซ่า")
                    time.sleep(1)
                    nn2(to,"9.❂•••• บียาร์รีลล์")
                    time.sleep(1)
                    nn2(to,"0.❂••• เรอัลเบติส")
                    time.sleep(1)
                    nn2(to,"💜•⭐ขอบคุณคับ•⭐•💜")

                elif msg.text in ["เอจังนับไฮโซ","นับไฮโซ"]:                    
                    kittyText(to,"✧••••••❂✯❂••••••✧\n💖💖[[[[[ 1 ]]]]]💖💖\n ••••• " +datetime.today().strftime('%H:%M:%S')+ " •••••")
                    time.sleep(1)
                    kittyText(to,"✧••••••❂✯❂••••••✧\n💚💚[[[[[ 2 ]]]]]??💚\n ••••• " +datetime.today().strftime('%H:%M:%S')+ " •••••")
                    time.sleep(1)
                    kittyText(to,"✧••••••❂✯❂••••••✧\n💙💙[[[[[ 3 ]]]]]💙💙\n ••••• " +datetime.today().strftime('%H:%M:%S')+ " •••••")
                    time.sleep(1)
                    kittyText(to,"✧••••••❂✯❂••••••✧\n💔💔[[[[[ 4 ]]]]]💔💔\n ••••• " +datetime.today().strftime('%H:%M:%S')+ " •••••")
                    time.sleep(1)
                    kittyText(to,"✧••••••❂✯❂••••••✧\n💖💖[[[[[ 5 ]]]]]💖💖\n ••••• " +datetime.today().strftime('%H:%M:%S')+ " •••••")
                    time.sleep(1)
                    kittyText(to,"✧••••••❂✯❂••••••✧\n💚💚[[[[[ 6 ]]]]]💚💚\n ••••• " +datetime.today().strftime('%H:%M:%S')+ " •••••")
                    time.sleep(1)
                    kittyText(to,"✧••••••❂✯❂••••••✧\n💙💙[[[[[ 7 ]]]]]💙💙\n ••••• " +datetime.today().strftime('%H:%M:%S')+ " •••••")
                    time.sleep(1)
                    kittyText(to,"✧••••••❂✯❂••••••✧\n💔💔[[[[[ 8 ]]]]]💔์💔\n ••••• " +datetime.today().strftime('%H:%M:%S')+ " •••••")
                    time.sleep(1)
                    kittyText(to,"✧••••••❂✯❂••••••✧\n💖ั๊💖[[[[[ 9 ]]]]]💖💖\n ••••• " +datetime.today().strftime('%H:%M:%S')+ " •••••")
                    time.sleep(1)
                    kittyText(to,"✧••••••❂✯❂••••••✧\n💚💚[[[[[ 0 ]]]]]💚💚\n ••••• " +datetime.today().strftime('%H:%M:%S')+ " •••••")                    

                elif msg.text in ["ใครหล่อสุด","ใครเท่สุด","ใครเกรียนสุด","ใครอัจฉริยะสุด","ใครเก่งสุด","ใครเทพสุด"]:                    
                    nn2(to,"⭐ระบบอัจฉริยะกำลังทำงาน⭐")
                    time.sleep(1)
                    nn2(to,"🔍 Search Bot :::::::::::::::::::::")
                    time.sleep(1)
                    nn2(to,"Now Loding...............")
                    time.sleep(1)
                    nn2(to,"15% ❂•➣➣➣➣")
                    time.sleep(1)
                    nn2(to,"32% ❂•➣➣➣➣")
                    time.sleep(1)
                    nn2(to,"67% ❂•➣➣➣➣")
                    time.sleep(1)
                    nn2(to,"99% ❂•➣➣➣➣")
                    time.sleep(1)
                    nn2(to,"💖•Mission Complete•💖")
                    time.sleep(1)
                    nn2(to,"🌟৩้Ꭷ৩ꪶꪶ৩้৩: 🕟 " +datetime.today().strftime('%H:%M:%S')+ "🌟")
                    time.sleep(1)
                    line.sendContact(to, "u6f1426e90a67990ba6bc167fc93437a1")
                    time.sleep(1)
                    nn2(to,"🌟™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣🌟")                
                      
                elif text.lower() == "ดับไฟ":
                    nn2(to,"❌•🛑 อันตราย 🛑•❌")
                    time.sleep(1)
                    nn2(to,"💙:::⭐ 9 ⭐:::💙")
                    time.sleep(1)
                    nn2(to,"💚:::⭐ 8 ⭐:::💚")
                    time.sleep(1)
                    nn2(to,"💖:::⭐ 7 ⭐:::💖")
                    time.sleep(1)
                    nn2(to,"💚:::⭐ 6 ⭐:::💚")
                    time.sleep(1)
                    nn2(to,"💖:::⭐ 5 ⭐:::💖")
                    time.sleep(1)
                    nn2(to,"💔:::⭐ 4 ⭐:::💔")
                    time.sleep(1)
                    nn2(to,"💙:::⭐ 3 ⭐:::💙")
                    time.sleep(1)
                    nn2(to,"💚:::⭐ 2 ⭐:::💚")
                    time.sleep(1)
                    nn2(to,"💖:::⭐ 1 ⭐:::💖")
                    time.sleep(1)
                    nn2(to,"💚:::⭐ 0 ⭐:::💚")
                    time.sleep(1)
                    nn2(to,"🔸•😐ไปปิดเองดิ 😐•??")             
                  
                elif msg.text in ["เฟก","ลิ้งเฟก"]:
                   chivaree3={"type":"template","altText":"✯ NN Sticker ✯","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2020/01/28/Rv6itv.jpg","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9",}}]}}
                   chivaree33={"type":"template","altText":"✯ NN Sticker ✯","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2020/01/28/Rv6RoE.jpg","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=เฟก%20สำเร็จ",}}]}}
                   sendTemplate(to, chivaree3)
                   time.sleep(5)
                   nn2(to, "🐷💓   กดแล้วรอ10วินาที   💓🐷")
                   time.sleep(10)
                   sendTemplate(to, chivaree33)                                   
                elif text.lower() == "เฟก สำเร็จ":
                    nn2(to,"💓🐷   สำเร็จแล้ว   🐷💓")                   
#----------------------------------------------------------------------------#                         
                elif msg.text in ["รูปทั้งห้อง"]:
                  kontak = line.getGroup(to)
                  group = kontak.members
                  picall = []
                  for ids in group:
                    if len(picall) >= 400:
                      pass
                    else:
                      picall.append({
                        "imageUrl": "https://os.line.naver.jp/os/p/{}".format(ids.mid),
                        "action": {
                          "type": "uri",
                          "uri": "http://line.me/ti/p/~0969245004"
                          }
                        }
                      )
                  k = len(picall)//10
                  for aa in range(k+1):
                    data = {
                      "type": "template",
                      "altText": "{} membagikan janda".format(line.getProfile().displayName),
                      "template": {
                         "type": "image_carousel",
                         "columns": picall[aa*10 : (aa+1)*10]
                      }
                    }
                    sendTemplate(to, data)         
          
                elif msg.text.lower().startswith("สแปมแทค "):
                    sep = text.split(" ")
                    text = text.replace(sep[0] + " ","")
                    cond = text.split(" ")
                    jml = int(cond[0])
                    if msg.toType == 2:
                        group = line.getGroup(to)
                    for x in range(jml):
                        if 'MENTION' in msg.contentMetadata.keys()!= None:
                            names = re.findall(r'@(\w+)', text)
                            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                            mentionees = mention['MENTIONEES']
                            lists = []
                            for mention in mentionees:
                                if mention["M"] not in lists:
                                    lists.append(mention["M"])
                            for receiver in lists:
                                contact = line.getContact(receiver)
                                RhyN_(to, contact.mid)
                           
                elif "รันคอล" in msg.text.lower():
                    if msg.toType == 2:
                        sep = msg.text.split(" ")
                        resp = msg.text.replace(sep[0] + " ","")
                        num = int(resp)
                        try:
                            kittySend(to,"👉•ระบบเริ่มรันคอลคับ•👈")
                            kittySend(to, "📞........🔆 " +datetime.today().strftime('%H:%M:%S')+ "™ ") 
                        except:
                            pass
                        for var in range(num):
                            group = line.getGroup(msg.to)
                            members = [mem.mid for mem in group.members]
                            line.acquireGroupCallRoute(msg.to)
                            line.inviteIntoGroupCall(msg.to, contactIds=members)
                        kittyText(to,"🌟•รันคอลเสร็จเรียบร้อยคับ•🌟")        

                elif msg.text in ["ลบรัน","ล้างรัน"]:
                    chivaree = line.getGroupIdsInvited()
                    chivaree_timer = time.time()
                    if chivaree != [] and chivaree != None:
                        for ajang in chivaree:
                            time.sleep(random.uniform(4.5,5.0))
                            line.rejectGroupInvitation(ajang)
                    chivareeZ = time.time() - chivaree_timer
                    nn2(to, "🌟•ลบรันขั้นเทพ ไม่มีบัค•🌟")
                    time.sleep(1)
                    nn2(to, "• ™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣ •")
                    time.sleep(1)
                    nn2(to, "☆• ลบห้องรันไป {} ห้องคับ •☆".format(str(len(chivaree))))
                    time.sleep(1)                   
                    nn2(to, "• เวลาที่ใช้: %sวินาที" % (chivareeZ))                        
#--------------------------------------------------------------------------------------------------------------------------    
                elif msg.text in ["ป้องกัน"]:
                    nn2(to, "🌟พิมคำสั่ง ลงกลุ่มที่จะป้องกัน🌟")
                    time.sleep(1)
                    kittyText(to, "✧••••••••••••❂✧✯✧❂•••••••••••••✧\n   ✥™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣✥\n✧••••••••••••❂✧✯✧❂•••••••••••••✧\n\n          ♡•ชุดคำสั่งป้องกัน\n\n╭☆•☆•☆•☆•☆•☆•☆•☆•☆•☆•☆\n♡•กันเชิญ เปิด\n♡\n♡กันลิ้ง เปิด\n♡\n♡กันเตะ เปิด\n♡\n♡  😐😐😐😐😐😐😐😐\n╰☆•☆•☆•☆•☆•☆•☆•☆•☆•☆•☆\n\n✧••••••••••••❂✧✯✧❂•••••••••••••✧\n ♡วิธีใช้ : ถ้าต้องการปิด ใช้คำหลังว่าปิด♡")                             
#เชคสปีด==============================================================================#
                elif msg.text in ["Sp","แรงม้า"]:
                    ajang = time.time()
                    time.sleep(0.01)
                    chivaree_timer = time.time() - ajang
                    chivareeS={
                         "type": "flex",
                         "altText": "☆•™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣•☆",
                                 "contents": { 
                       "type": "bubble",     
                       "header": {
                         "type": "box",
                         "layout": "vertical",   
                         "contents": [
                           {     
                             "type": "text",
                             "text": "🐷ความเร็วบอท🐷",
                             "weight": "bold",
                             "color": "#000000",
                             "align": "center"
                           }]},
                       "hero": {
                           "type": "image",
                           "url": "https://sv1.picz.in.th/images/2020/01/28/RpCOvI.png",
                           "size": "full",
                           "aspectRatio": "1:1",
                            "aspectMode": "fit",
                            "action": {
                                 "type":"uri","uri":"line://app/1602687308-GXq4Vvk9?type=image&img=https://sv1.picz.in.th/images/2019/08/07/KIzyak.jpg"}},
                       "body": {"type": "box","layout": "vertical","contents": [{"type": "text","text": "%s วินาที" %(chivaree_timer),"color": "#000000","align": "center","weight": "bold","size":"md"},{"type": "text","text": "\nSPEED SELFBOT","size": "md","align": "center","color": "#000000","weight": "bold","gravity": "center","wrap": True,"flex": 1}]},
                        "styles": {
                          "header": {
                            "backgroundColor": "#66FFFF"
                            },
                            "hero": {
                              "separator": True,
                              "separatorColor": "#66FFFF",
                              "backgroundColor": "#66FFFF"
                            },
                            "body": {
                             "backgroundColor": "#66FFFF",
                            }}}}
                    sendTemplate(to, chivareeS) 
#--------------------------------------------------------------------------------------------------------------
                elif msg.text in ["ไฮสปีด","สปีดไฮ","สปูด","สปาด","สปุด"]:
                    nn2(msg.to, "™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣")
                    time.sleep(1)
                    nn2(to, "•─ ͜͡✯͜͡S͜͡p͜͡e͜͡e͜͡e͜͡d✯͜͡ѕ͜͡є͜͡ʟ͜͡ғ͜͡в͜͡о͜͡т͜͡✯─•")
                    start = time.time()
                    time.sleep(1)
                    elapsed_time = time.time() - start
                    kittyText(to, "%sseconds" % (elapsed_time)) 

                elif msg.text in ["4g",".357"]:
                    nn2(to, "■•■•■•■ O.K. ■•■•■•■")
                    time.sleep(1)
                    nn2(to, "✧•••••❂Tëst Speëd❂•••••✧")
                    start = time.time()
                    time.sleep(1)
                    elapsed_time = time.time() - start
                    nn2(to, "%sseconds" % (elapsed_time))

                elif msg.text in ["8g","เทสจรวด","Ais","3bb","Dtac"]:
                    nn2(to, "™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣")
                    time.sleep(1)
                    nn2(to, "•••••••• Tëst $peed ••••••••")
                    start = time.time()
                    time.sleep(1)
                    elapsed_time = time.time() - start
                    nn2(to, "%sseconds" % (elapsed_time))

                elif msg.text in ["9g",".45"]:
                    nn2(to, "™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣")
                    time.sleep(1)
                    nn2(to, "❂•➣➣➣ S.p.ë.e.d ➣➣➣➣")
                    start = time.time()
                    time.sleep(1)
                    elapsed_time = time.time() - start
                    nn2(to, "%sseconds" % (elapsed_time))

                elif msg.text in ["10g","M16"]:
                    nn2(to, "✧•••••••••❂✧✯✧❂••••••••••✧\n     ♡™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣♡\n✧•••••••••❂✧✯✧❂••••••••••✧")
                    time.sleep(1)
                    nn2(to, "❂•➣➣➣ S.p.ë.e.d ➣➣➣➣")
                    start = time.time()
                    time.sleep(1)
                    elapsed_time = time.time() - start
                    nn2(to, "%sseconds" % (elapsed_time))

                elif msg.text in ["11g","Hk"]:
                    nn2(to, "✧•••••••••❂✧✯✧❂••••••••••✧\n     Tëst : Prëmium Spëed™\n✧•••••••••❂✧✯✧❂••••••••••✧")
                    time.sleep(1)
                    nn2(to, "❂•➣➣➣ S.p.ë.e.d ➣➣➣➣")
                    start = time.time()
                    time.sleep(1)
                    elapsed_time = time.time() - start
                    nn2(to, "%sseconds" % (elapsed_time))

                elif msg.text in ["12g",".38","สปิด","สเปด","สแปด","สปัด"]:
                    nn2(to, "™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣")
                    time.sleep(1)
                    nn2(to,"❂•Speed•❂ : 🕒 " +datetime.today().strftime('%H:%M:%S')+ "™")
                    start = time.time()
                    time.sleep(1)
                    elapsed_time = time.time() - start
                    nn2(to, "%sseconds" % (elapsed_time))

                elif msg.text in ["13g",".22"]:
                    nn2(to, "Hî Speëd:•➣➣➣➣➣➣➣➣")
                    time.sleep(1)
                    nn2(to, "™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣")
                    start = time.time()
                    time.sleep(1)
                    elapsed_time = time.time() - start
                    nn2(to, "%sseconds" % (elapsed_time))

                elif msg.text in ["รถเต่า","Bmx","Bmw","Benz","ปอร์เช่","เบ้นซ์","จากัวร์","เฟอร์รารี่"]:
                    nn2(to, "■•■•■• 3500cc •■•■•■")
                    time.sleep(1)
                    nn2(to, "●•➤➤➤➤➤➤➤➤➤➤")
                    time.sleep(1)
                    nn2(to, "●•➤➤➤➤➤➤➤➤➤➤➤➤")
                    start = time.time()
                    time.sleep(1)
                    elapsed_time = time.time() - start
                    nn2(to, "%sseconds" % (elapsed_time))           
#-----------------------------------------------------------------------------------------------------#                           
                elif text.lower() == 'ติดต่อ':
                        	_session = requests.session()
                        	n1 = LiffChatContext(to)
                        	n2 = LiffContext(chat=n1)
                        	view = LiffViewRequest('1602687308-GXq4Vvk9', n2)
                        	token = line.liff.issueLiffView(view)
                        	url = 'https://api.line.me/message/v3/share'
                        	headers = {
                        		'Content-Type': 'application/json',
                        		'Authorization': 'Bearer %s' % token.accessToken
                        	}
                        	jsonData = {
                        		"to": to,
                        		"messages": [
                        			{
                        				"type": "template",
                        				"altText": "LINE",
                        				"template": {
                        					"type": "carousel",
                        					"actions": [],
                        					"columns": [
                                                {
                                                	"title": "สนใจบอทราคาประหยัดติดต่อ",
                                                	"text": "Self bot & บอทแทค",
                                                	"actions": [
                                                		{
                                                			"type": "uri",
                                                			"label": "คลิกเพื่อติดต่อ",
                                                			"uri": "line://ti/p/~0969245004"
                                                		}
                                                	]
                                                },
                                                {
                                                	"title": "Self Bot ราคาถูก สีสวยสดใส",
                                                	"text": "พร้อมรับสอนทำ ไม่มีรายเดือน",
                                                	"actions": [
                                                		{
                                                			"type": "uri",
                                                			"label": "คลิกเพื่อติดต่อ",
                                                			"uri": "line://ti/p/~0969245004"
                                                		}
                                                	]                                                		
                                                },
                                                {
                                                	"title": "รับทำโฆษณา ทุกรูปแบบ",
                                                	"text": "โฆษณาระบบFlex สีสวยงาม",
                                                	"actions": [
                                                		{
                                                			"type": "uri",
                                                			"label": "คลิกเพื่อติดต่อ",
                                                			"uri": "line://ti/p/~0969245004"
                                                		}
                                                	]                                                		
                                                },
                                                {                                                    
                                                	"title": "ขายไฟล์บอทไลน์ทุกชนิด",
                                                	"text": "เชลบอท บอทบิน บอทป้องกัน",
                                                	"actions": [
                                                		{
                                                			"type": "uri",
                                                			"label": "คลิกเพื่อติดต่อ",
                                                			"uri": "line://ti/p/~0969245004"
                                                		}
                                                	]                                                		
                                                },
                                                {                                                    
                                                	"title": "บอทแทคราคาประหยัด",
                                                	"text": "ลูกเล่นมากมาย สีสวยงาม",
                                                	"actions": [
                                                		{
                                                			"type": "uri",
                                                			"label": "กดที่นี่สิ",
                                                			"uri": "line://app/1602687308-GXq4Vvk9?type=text&text=คำสั่ง"                                                            
                                                		}                                                		
                                                	]
                                                }
                        					]
                        				}
                        			}
                        		]
                        	}
                        	data = json.dumps(jsonData)
                        	sendPost = _session.post(url, data=data, headers=headers)                            
#----------------------------------------------------------------------------#             
                elif text.lower().startswith("เขียน "):
                            s = "#000000"
                            a = "#ffffff"
                            khie = text.split(" ")
                            hey = text.replace(khie[0] + " ", "")
                            text = "{}".format(hey)
                            contact = line.getContact(lineMID)
                            cover = line.getProfileCoverURL(lineMID)
                            data = {
                                "type": "flex",
                                "altText": "flex",
                                "contents": {
                                      "type": "bubble",
                            'styles': {
                                "body": {
                                    "backgroundColor":a
                                },
                             },
                             "hero": {
                                 "type":"image",
                                 "url": "https://sv1.picz.in.th/images/2020/01/27/RXEKFl.png",
                                 "size":"full",
                                 "aspectRatio":"20:13",
                                 "aspectMode":"cover"
                            },
                            "body": {
                               "type": "box",
                                "layout": "vertical",
                                "contents": [            
                                            {
                                                "type": "text",
                                                "text": "{}".format(text),
                                                "wrap": True,
                                                "align": "start",
                                                "gravity": "center",
                                                "color": s,
                                                "size": "xxl"
                                            },
                                        ]
                                    }
                                }
                            }
                            sendTemplate(to, data)       
#-----------------ออน1-3-------------------------------------------------------------------------------------#                      
                elif text.lower() == "ออน" or text.lower() == "คำสั่งออน":
                    sas = "™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣\n"
                    sa = "• 🐷 ออน1 \n"
                    sa += "• 🐷 ออน2\n"
                    sa += "• 🐷 ออน3\n"
                    sa += "• 🐷 ออน4\n"
                    sa += "• 🐷 ออน5\n"                    
                    helps = "{}".format(str(sa))
                    g = "https://sv1.picz.in.th/images/2020/01/28/Rv4Iyq.png"
                    data = {
                            "type": "flex",
                                    "altText": "MENU TEST",
                                        "contents": {
                                        "styles": {
                                        "header": {
                                        "backgroundColor":"#66FFFF"
                                        },
                                        "body": {
                                        "backgroundColor": "#FFFFFF"
                                        },
                                        "footer": {
                                          "backgroundColor": "#66FFFF"
                                        }
                                        },
                                        "type": "bubble",
                                        "header": {
                                        "type": "box",
                                        "layout": "horizontal",
                                        "contents": [
                                                           {
                                                            "type": "button",
                                                            "style": "secondary",
                                                            "color": "#FFFFFF",
                                                            "height": "sm",
                                                            "gravity": "center",
                                                            "flex": 1,
                                                            "action": {
                                                            "type": "uri",
                                                            "label": "คำสั่ง ออนบอท",
                                                            "uri": "https://line.me/ti/p/~0969245004"
                                                            }
                                                          },
                                                       ]
                                                   },
                                                   "body": {
                                                   "type": "box",
                                                   "layout": "horizontal",
                                                   "spacing": "md",
                                          "contents": [
                                          {
                                          "type": "box",
                                          "layout": "vertical",
                                          "flex": 0,
                                   "contents": [
                                   {
                                    "type": "image",
                                    "url": g,
                                    "gravity": "bottom"
                                    }
                                  ]
                               }, 
                            {
                             "type": "separator",
                             "color": "#FF9900"
                              }, 
                             {
                             "type": "box",
                             "layout": "vertical",
                             "flex": 2,
                      "contents": [
                      {
                       "type": "text",
                       "text": "{}".format(sa),
                       "color": "#000000",
                       "size": "sm",
                       "weight": "bold",
                      "flex": 3,
                      "wrap": True,
                     "gravity": "top"
                    }
                  ]
               }
            ]
         },
        "footer": {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                                           {
                                             "type": "button",
                                             "style": "secondary",
                                             "color": "#FFFFFF",
                                             "height": "sm",
                                             "gravity": "center",
                                             "flex": 1,
                                             "action": {
                                             "type": "uri",
                                             "label": "BOT TAG 2020",
                                             "uri": "https://line.me/ti/p/~0969245004",
                                            }
                                          },
                                        {
                                           "type": "spacer",
                                           "size": "sm",
                                         }
                                       ],
                                    "flex": 0
                                   }
                                }
                            }                        
                    sendTemplate(to, data)               
                elif text.lower() == "ออน2":
                    chivaree = line.getContact(lineMID)
                    timeNow = time.time() - mulai
                    runtime = kittyTime(timeNow)
                    tz = pytz.timezone("Asia/Jakarta")
                    timeNow = datetime.now(tz=tz)   
                    a = "วันที่"+ datetime.strftime(timeNow,'%d-%m-%Y')+"🇹🇭เวลา"+ datetime.strftime(timeNow,'%H:%M:%S')+"\n"
                    run = "「 เวลาออน 」\n"
                    run += runtime
                    chivaree3 = {
                            "type": "flex",
                            "altText": "•™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣",
                            "contents": {
                            "styles": {
                              "body": {
                                "backgroundColor": "#000000"
                              },
                              "footer": {
                                "backgroundColor": "#FF9900"
                              }
                            },
                            "type": "bubble",
                            "body": {
                              "contents": [
                                {
                                  "contents": [
                                    {
                                      "url": "https://obs.line-scdn.net/{}".format(chivaree.pictureStatus),
                                      "type": "image"
                                    },
                                    {
                                      "type": "separator",
                                      "color": "#FF9900"
                                    },
                                    {
                                      "url": "https://obs.line-scdn.net/{}".format(chivaree.pictureStatus),
                                      "type": "image"
                                    }
                                  ],
                                  "type": "box",
                                  "spacing": "md",
                                  "layout": "horizontal"
                                },
                                {
                                  "type": "separator",
                                  "color": "#FF9900"
                                },
                                {
                                  "contents": [
                                    {
                                      "text": "🐷บอททำงานมาแล้ว🐷",
                                      "size": "lg",
                                      "align": "center",
                                      "color": "#66FFFF",
                                      "wrap": True,
                                      "weight": "bold",
                                      "type": "text"
                                    }
                                  ],
                                  "type": "box",
                                  "spacing": "md",
                                  "layout": "vertical"
                                },
                                {
                                  "type": "separator",
                                  "color": "#FF9900"
                                },
                                {
                                  "contents": [
                                    {
                                      "contents": [
                                        {
                                          "text": "{}".format(run),
                                          "size": "md",
                                          "align": "center",
                                          "margin": "none",
                                          "color": "#00F5FF",
                                          "wrap": True, 
                                          "weight": "regular",
                                          "type": "text"
                                        }
                                      ],
                                      "type": "box",
                                      "layout": "baseline"
                                    },
                                  ],
                                  "type": "box",
                                  "layout": "vertical"
                                }
                              ],
                              "type": "box",
                              "spacing": "md",
                              "layout": "vertical"
                            },
                            "footer": {
                              "contents": [
                                {
                                  "contents": [
                                    {
                                      "contents": [
                                        {
                                          "text": "™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣",
                                          "size": "md",
                                          "action": {
                                            "uri": "line://ti/p/~0969245004",
                                            "type": "uri",
                                            "label": "Add Maker"
                                          },
                                          "margin": "xl",
                                          "align": "center",
                                          "color": "#66FFFF",
                                          "weight": "bold",
                                          "type": "text"
                                        }
                                      ],
                                      "type": "box",
                                      "layout": "baseline"
                                    }
                                  ],
                                  "type": "box",
                                  "layout": "horizontal"
                                }
                              ],
                              "type": "box",
                              "layout": "vertical"
                            }
                        }
                    }
                    sendTemplate(to, chivaree3)   
                 
                if text.lower() == "ออน1" or text.lower() == "runtime":
                    chivaree = line.getContact(lineMID)
                    timeNow = time.time() - mulai
                    runtime = kittyTime(timeNow)
                    tz = pytz.timezone("Asia/Jakarta")
                    timeNow = datetime.now(tz=tz)   
                    a = "วันที่"+ datetime.strftime(timeNow,'%d-%m-%Y')+"🇹🇭เวลา"+ datetime.strftime(timeNow,'%H:%M:%S')+"\n"
                    run = "「 เวลาออน 」\n"
                    run += runtime
                    data = {
                        "type": "flex",
                        "altText": "{}".format(run),
                        "contents": {
                            "type": "bubble",
                            "styles": {
                                "body": {
                                    "backgroundColor": '#6600CC'
                                 },
                            },
                            "hero": {
                                            "type": "image",
                                            "url": "https://sv1.picz.in.th/images/2020/01/27/RXWvUz.png",
                                            "size": "full",
                                            "aspectRatio": "1:1",
                                            "aspectMode": "fit",
                                        },
                            "body": {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                    {
                                        "type": "text",
                                        "text": "{}".format(run),
                                        "wrap": True,
                                        "color": "#00FF00",
                                        "align": "center",
                                        "gravity": "center",
                                        "size": "md"
                                    },
                                ]
                            }
                        }
                    }
                    sendTemplate(to, data)    

                elif text.lower() == 'ออน3':
                    chivaree = line.getContact(lineMID)
                    timeNow = time.time() - mulai
                    runtime = kittyTime(timeNow)
                    tz = pytz.timezone("Asia/Jakarta")
                    timeNow = datetime.now(tz=tz)   
                    a = "วันที่"+ datetime.strftime(timeNow,'%d-%m-%Y')+"🇹🇭เวลา"+ datetime.strftime(timeNow,'%H:%M:%S')+"\n"
                    run = "「 เวลาออน 」\n"
                    run += runtime
                    van = " ระยะเวลาการทำงานของบอท\n"  +format(str(runtime))+"\n ◐วันที่ : "+ datetime.strftime(timeNow,'%d-%m-%Y')+"\n ◐เวลา [ "+ datetime.strftime(timeNow,'%H:%M:%S')+"\n『AVENGRES BOT』"
                    data={
                        'type': 'flex',
                        'altText': 'AVENGRES BOT',
                                'contents': {
                            "type": "bubble",
                            "header": {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                    {
                                        "type": "text",
                                        "text": "AVENGRES BOT",
                                        "weight": "bold",
                                        "color": "#FFFFFF",
                                        "align": "center"
                                    }
                                ]
                            },
                            "body": {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                    {
                                        "type": "text",
                                        "text": van,
                                        "size": "sm",
                                         "align": "center",
                                        "weight": "bold",
                                        "color": "#66FF33",
                                        "gravity": "center",
                                        "wrap": True,
                                        "flex": 1
                                    }
                                ]
                            },
                            "footer": {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                    {
                                        "type": "text",
                                        "text": "AVENGRES BOT",
                                        "color": "#FFFFFF",
                                        "align": "center"
                                    }
                                ]
                            },
                            "styles": {
                                "header": {
                                    "backgroundColor": "#0033FF"
                                },
                                "footer": {
                                    "backgroundColor": "#0033FF",
                                    "separator": True,
                                    "separatorColor": "#0033FF"
                                },
                                "body": {
                                    "backgroundColor": "#000000"
                                }
                            }
                        }
                    }
                    sendTemplate(to, data)      

                if text.lower() == "ออน4":
                    cover = line.getProfileCoverURL(line.profile.mid)
                    pp = line.getProfile().pictureStatus
                    profile = "https://profile.line-scdn.net/" + str(pp)
                    name = line.getProfile().displayName
                    status = line.getProfile().statusMessage     
                    tz = pytz.timezone("Asia/Jakarta")
                    timeNow = datetime.now(tz=tz)
                    eltime = time.time() - mulai
                    van = ajangTime(eltime)
                    van2 = "\n\n✨วันที่ :"+ datetime.strftime(timeNow,'%d-%m-%Y')+"\n───────────\n◐เวลา:"+ datetime.strftime(timeNow,'%H:%M:%S')+"\n\n"      
                    chivareeZ={
"type":"flex",
"altText":"™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣",
"contents":{
"type": "carousel",
"contents": [
{
"type": "bubble",
"styles": {
"header": {"backgroundColor": "#FFCCFF", "separator": True, "separatorColor": "#FFCCFF"},
"body": {"backgroundColor": "#66FFFF", "separator": True, "separatorColor": "#66FFFF"},
"footer": {"backgroundColor": "#66FFFF", "separator": True, "separatorColor": "#66FFFF"}
},
"header": {
"type": "box",
"layout": "horizontal",
"contents": [
{
"type": "text",
"text": "✨ เวลาบอทออน ✨",
"align": "center",
"size": "lg",
"weight": "bold",
"color": "#000000",
"wrap": True
}
]
},
"type": "bubble",
"body": {
"contents": [
{
"contents": [
{
"url": profile,
"type": "image"
},
{
"type": "separator",
"color": "#000000"
},
{
"url": profile,
"type": "image"
}
],
"type": "box",
"spacing": "md",
"layout": "horizontal"
},
{
"type": "separator",
"color": "#000000"
},
{
"contents": [
{
"text": "✨ระยะเวลาออนของบอท✨",
"size": "md",
"align": "center",
"color": "#000000",
"wrap": True,
"weight": "bold",
"type": "text"
}
],
"type": "box",
"spacing": "md",
"layout": "vertical"
},
{
"type": "separator",
"color": "#000000"
},
{
"contents": [
{
"contents": [
{
"type": "text",
"text": van,
"align": "center",
"size": "xs",
"weight": "bold",
"color": "#000000",
"wrap": True
}
],
"type": "box",
"layout": "baseline"
},
{
"contents": [
{
"url": profile,
"type": "icon",
"size": "md"
},
{
"text": "➡™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣",
"size": "xs",
"margin": "none",
"color": "#000000",
"wrap": True,
"weight": "regular",
"type": "text"
}
],
"type": "box",
"layout": "baseline"
}
],
"type": "box",
"layout": "vertical"
}
],
"type": "box",
"spacing": "md",
"layout": "vertical"
},
"footer": {
"type": "box",
"layout": "horizontal",
"spacing": "sm",
"contents": [
{
"type": "button",
"flex": 2,
"style": "primary",
"color": "#000000",
"height": "sm",
"action": {
"type": "uri",
"label": "ติดต่อบอท",
"uri": "https://line.me/ti/p/~0969245004",
}
},
{
"flex": 3,
"type": "button",
"style": "primary",
"color": "#000000",
"margin": "sm",
"height": "sm",
"action": {
"type": "uri",
"label": "ติดต่อผู้สร้าง",
"uri": "https://line.me/ti/p/~0969245004",
}
}
]
}
},
{
"type": "bubble",
"styles": {
"header": {"backgroundColor": "#FFCCFF", "separator": True, "separatorColor": "#FFCCFF"},
"body": {"backgroundColor": "#66FFFF", "separator": True, "separatorColor": "#66FFFF"},
"footer": {"backgroundColor": "#66FFFF", "separator": True, "separatorColor": "#66FFFF"}
},
"header": {
"type": "box",
"layout": "horizontal",
"contents": [
{
"type": "text",
"text": "✨ ปฏิทิน ✨",
"align": "center",
"size": "lg",
"weight": "bold",
"color": "#000000",
"wrap": True
}
]
},
"type": "bubble",
"body": {
"contents": [
{
"contents": [
{
"url": profile,
"type": "image"
},
{
"type": "separator",
"color": "#000000"
},
{
"url": profile,
"type": "image"
}
],
"type": "box",
"spacing": "md",
"layout": "horizontal"
},
{
"type": "separator",
"color": "#000000"
},
{
"contents": [
{
"text": "✨วันเดือนปีและเวลา✨",
"size": "md",
"align": "center",
"color": "#000000",
"wrap": True,
"weight": "bold",
"type": "text"
}
],
"type": "box",
"spacing": "md",
"layout": "vertical"
},
{
"type": "separator",
"color": "#000000"
},
{
"contents": [
{
"contents": [
{
"type": "text",
"text": van2,
"align": "center",
"size": "xs",
"weight": "bold",
"color": "#000000",
"wrap": True
}
],
"type": "box",
"layout": "baseline"
},
{
"contents": [
{
"url": profile,
"type": "icon",
"size": "md"
},
{
"text": "➡™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣",
"size": "xs",
"margin": "none",
"color": "#000000",
"wrap": True,
"weight": "regular",
"type": "text"
}
],
"type": "box",
"layout": "baseline"
}
],
"type": "box",
"layout": "vertical"
}
],
"type": "box",
"spacing": "md",
"layout": "vertical"
},
"footer": {
"type": "box",
"layout": "horizontal",
"spacing": "sm",
"contents": [
{
"type": "button",
"flex": 2,
"style": "primary",
"color": "#000000",
"height": "sm",
"action": {
"type": "uri",
"label": "ติดต่อบอท",
"uri": "https://line.me/ti/p/~0969245004",
}
},
{
"flex": 3,
"type": "button",
"style": "primary",
"color": "#000000",
"margin": "sm",
"height": "sm",
"action": {
"type": "uri",
"label": "ติดต่อผู้สร้าง",
"uri": "https://line.me/ti/p/~0969245004",
}
}
]
}
}
]
}
}                    
                    sendTemplate(to, chivareeZ)         

                elif text.lower() == "ออน5" or text.lower() == "runtime5":
                    chivaree = line.getContact(lineMID)
                    timeNow = time.time() - mulai
                    runtime = kittyTime(timeNow)
                    tz = pytz.timezone("Asia/Jakarta")
                    timeNow = datetime.now(tz=tz)   
                    a = "วันที่"+ datetime.strftime(timeNow,'%d-%m-%Y')+"🇹🇭เวลา"+ datetime.strftime(timeNow,'%H:%M:%S')+"\n"
                    run = "「 เวลาออน 」\n"
                    run += runtime
                    data = {
                        "type": "flex",
                        "altText": "{}".format(run),
                        "contents": {
                            "type": "bubble",
                            "styles": {
                                "body": {
                                    "backgroundColor": '#66FFFF'
                                 },
                            },
                            "hero": {
                                            "type": "image",
                                            "url": "https://obs.line-scdn.net/{}".format(line.getContact(sender).pictureStatus),
                                            "size": "full",
                                            "aspectRatio": "1:1",
                                            "aspectMode": "fit",
                                        },
                            "body": {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [                              
                                    {
                                        "type": "text",
                                        "text": "{}".format(run),
                                        "wrap": True,
                                        "color": "#000000",
                                        "align": "center",
                                        "gravity": "center",
                                        "size": "md"
                                    },
                                ]
                            }
                        }
                    }
                    sendTemplate(to, data)                                                             
#---------------------------------------------------------------------------------------------#                    
                elif msg.text in ["เอจังข้อมูล","ข้อมูลเอจัง","ข้อมูล","ข้อมูลกู"]:
                    try:
                        arr = []
                        owner = "u6f1426e90a67990ba6bc167fc93437a1"
                        creator = line.getContact(owner)
                        contact = line.getContact(lineMID)
                        grouplist = line.getGroupIdsJoined()
                        contactlist = line.getAllContactIds()
                        blockedlist = line.getBlockedContactIds()
                        ajang = "•🐷• ชื่อบอท ═ {}".format(contact.displayName)
                        ajang += "\n•🐷• กลุ่ม ═ {}".format(str(len(grouplist)))
                        ajang += "\n•🐷• เพื่อน ═ {}".format(str(len(contactlist)))
                        ajang += "\n•🐷• บล็อค ═ {}".format(str(len(blockedlist)))
                        ajang += "\n•🐷• ผู้สร้าง ═ {}".format(creator.displayName)
                        chivareeZ = "{}".format(str(ajang))
                        chivareeZz={
                         "type": "flex",
                         "altText": "™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣",
                                 "contents": { 
                       "type": "bubble",     
                       "header": {
                                            "type": "box",
                                            "layout": "baseline",
                                            "contents": [
                                                    {
                                                    "type": "text",
                                                    "text": "☆™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣",
                                                      "align" : "center",
                                                    "weight": "bold",
                                                    "color": "#000000",
                                                    "size": "md"
                                                }
                                            ]
                                        },
                       "hero": {
                         "type": "image",
                         "url": "https://sv1.picz.in.th/images/2020/01/28/Rv4Iyq.png",
                         "size": "full",
                           "aspectRatio": "1:1",
                            "aspectMode": "fit",
                            "action": {
                                 "type":"uri","uri":"line://app/1602687308-GXq4Vvk9?type=image&img=https://sv1.picz.in.th/images/2019/08/07/KIzyak.jpg"
                         }
                       },
                       "body": {
                       "type": "box",
                       "layout": "vertical",
                         "contents": [
                            {
                            "type": "text",
                            "text": "®• ข้อมูล BOT TAG 2020 •©",
                            "weight": "bold",
                            "align": "center",
                            "size": "md",
                            "color": "#000000",
                            'flex': 1,
                            },
                            {
                             "type": "text",
                             "text": "\n{}".format(str(ajang)),
                             "size": "sm",
                             "weight": "bold",
                             "color": "#000000",
                             "wrap": True,
                             "flex": 1
                           }
                         ]
                       },
                       "footer": {
                          "type": "box",
                          "layout": "vertical",
                          "contents": [
                            {
                              "type": "text",
                              "text": "BOT TAG 2020 : 🕒 " +datetime.today().strftime('%H:%M:%S')+ "™",
                              "color": "#000000",
                              "weight": "bold",
                              "size": "md",
                              "align": "center"
                            }
                          ]
                        },
                        "styles": {
                          "header": {
                            "backgroundColor": "#66FFFF"
                            },
                            "hero": {
                              "separator": True, 
                              "separatorColor": "#FF9900",
                              "backgroundColor": "#66FFFF"
                            },
                            "footer": {
                              "backgroundColor": "#66FFFF",
                              "separator": True,
                              "separatorColor": "#FF9900"
                            },
                            "body": {
                             "backgroundColor": "#66FFFF",
                             
                            }
                          }
                        }
                      }
                        sendTemplate(to, chivareeZz)
                    except Exception as e:
                        line.sendMessage(msg.to, str(e))            
                elif text.lower() == 'ข้อมูลบอท':
                    try:
                        arr = []
                        owner = "u6f1426e90a67990ba6bc167fc93437a1"
                        creator = line.getContact(owner)
                        contact = line.getContact(lineMID)
                        grouplist = line.getGroupIdsJoined()
                        contactlist = line.getAllContactIds()
                        blockedlist = line.getBlockedContactIds()
                        ret_ = "™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣"
                        ret_ += "\n🐷 ชื่อ ═ {}".format(contact.displayName)
                        ret_ += "\n🐷 กลุ่ม ═ {}".format(str(len(grouplist)))
                        ret_ += "\n🐷 เพื่อน ═ {}".format(str(len(contactlist)))
                        ret_ += "\n🐷 บล็อค ═ {}".format(str(len(blockedlist)))
                        ret_ += "\n🐷 [สถานะ]"
                        ret_ += "\n🐷 ผู้สร้าง ═ {}".format(creator.displayName)
                        ret_ += "\n™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣"
                        #line.sendContact(to, owner)
                        kittyText(to, str(ret_))
                    except Exception as e:
                        kittyText(msg.to, str(e))
                      
                elif msg.text in ["เอจังจับ","ตั้งเวลา","นาซ่า","จับเวลา"]:
                    tz = pytz.timezone("Asia/Jakarta")
                    timeNow = datetime.now(tz=tz)
                    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                    hari = ["วันอาทิตย์", "วันจันทร์", "วันอังคาร", "วันพุธ", "วันพฤหัสบดี", "วันศุกร์", "วันเสาร์"]
                    bulan = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
                    hr = timeNow.strftime("%A")
                    bln = timeNow.strftime("%m")
                    for i in range(len(day)):
                        if hr == day[i]: hasil = hari[i]
                    for k in range(0, len(bulan)):
                        if bln == str(k): bln = bulan[k-1]
                    readTime = hasil + ", " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') + "\nJam : [ " + timeNow.strftime('%H:%M:%S') + " ]"
                    if msg.to in read['readPoint']:
                            try:
                                del read['readPoint'][msg.to]
                                del read['readMember'][msg.to]
                                del read['readTime'][msg.to]
                            except:
                                pass
                            read['readPoint'][msg.to] = msg.id
                            read['readMember'][msg.to] = ""
                            read['readTime'][msg.to] = datetime.now().strftime('%H:%M:%S')
                            read['ROM'][msg.to] = {}
                            with open('read.json', 'w') as fp:
                                json.dump(read, fp, sort_keys=True, indent=4)
                                nn2(to,"ตั้งเวลาสำเร็จ พิมอ่าน")
                    else:
                        try:
                            del read['readPoint'][msg.to]
                            del read['readMember'][msg.to]
                            del read['readTime'][msg.to]
                        except:
                            pass
                        read['readPoint'][msg.to] = msg.id
                        read['readMember'][msg.to] = ""
                        read['readTime'][msg.to] = datetime.now().strftime('%H:%M:%S')
                        read['ROM'][msg.to] = {}
                        with open('read.json', 'w') as fp:
                            json.dump(read, fp, sort_keys=True, indent=4)
                            nn2(to, "ตั้งเวลาสำเร็จ" + readTime)
                            nn2(to, "โปรดพิม อ่าน")
                            
                            
                elif msg.text in ["เลิกตั้งเวลา","เลิกจับเวลา"]:
                    tz = pytz.timezone("Asia/Jakarta")
                    timeNow = datetime.now(tz=tz)
                    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                    hari = ["วันอาทิตย์", "วันจันทร์", "วันอังคาร", "วันพุธ", "วันพฤหัสบดี", "วันศุกร์", "วันเสาร์"]
                    bulan = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
                    hr = timeNow.strftime("%A")
                    bln = timeNow.strftime("%m")
                    for i in range(len(day)):
                        if hr == day[i]: hasil = hari[i]
                    for k in range(0, len(bulan)):
                        if bln == str(k): bln = bulan[k-1]
                    readTime = hasil + ", " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') + "\nJam : [ " + timeNow.strftime('%H:%M:%S') + " ]"
                    if msg.to not in read['readPoint']:
                        nn2(to,"ยกเลิกการตั้งเวลา")
                    else:
                        try:
                            del read['readPoint'][msg.to]
                            del read['readMember'][msg.to]
                            del read['readTime'][msg.to]
                        except:
                              pass
                        nn2(to, "Delete reading point:" + readTime)
    
                elif msg.text in ["ตั้งเวลาใหม่","จับเวลาใหม่"]:
                    tz = pytz.timezone("Asia/Jakarta")
                    timeNow = datetime.now(tz=tz)
                    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                    hari = ["วันอาทิตย์", "วันจันทร์", "วันอังคาร", "วันพุธ", "วันพฤหัสบดี", "วันศุกร์", "วันเสาร์"]
                    bulan = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
                    hr = timeNow.strftime("%A")
                    bln = timeNow.strftime("%m")
                    for i in range(len(day)):
                        if hr == day[i]: hasil = hari[i]
                    for k in range(0, len(bulan)):
                        if bln == str(k): bln = bulan[k-1]
                    readTime = hasil + ", " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') + "\nJam : [ " + timeNow.strftime('%H:%M:%S') + " ]"
                    if msg.to in read["readPoint"]:
                        try:
                            del read["readPoint"][msg.to]
                            del read["readMember"][msg.to]
                            del read["readTime"][msg.to]
                        except:
                            pass
                        line.sendMessage(msg.to, "Reset reading point:\n" + readTime)
                    else:
                        line.sendMessage(msg.to, "Lurking belum diaktifkan ngapain di reset?")
                        
                elif msg.text in ["สกิลอ่าน","อ่าน"]:
                    tz = pytz.timezone("Asia/Jakarta")
                    timeNow = datetime.now(tz=tz)
                    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                    hari = ["วันอาทิตย์", "วันจันทร์", "วันอังคาร", "วันพุธ", "วันพฤหัสบดี", "วันศุกร์", "วันเสาร์"]
                    bulan = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
                    hr = timeNow.strftime("%A")
                    bln = timeNow.strftime("%m")
                    for i in range(len(day)):
                        if hr == day[i]: hasil = hari[i]
                    for k in range(0, len(bulan)):
                        if bln == str(k): bln = bulan[k-1]
                    readTime = hasil + ", " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') + "\nJam : [ " + timeNow.strftime('%H:%M:%S') + " ]"
                    if receiver in read['readPoint']:
                        if list(read["ROM"][receiver].items()) == []:
                            line.sendMessage(receiver,"[ Reader ]:\nNone")
                        else:
                            chiya = []
                            for rom in list(read["ROM"][receiver].items()):
                                chiya.append(rom[1])
                            cmem = line.getContacts(chiya) 
                            zx = ""
                            zxc = ""
                            zx2 = []
                            xpesan = '[ *** รายชื่อคนที่อ่าน *** ]:\n'
                        for x in range(len(cmem)):
                            xname = str(cmem[x].displayName)
                            pesan = ''
                            pesan2 = pesan+"@c\n"
                            xlen = str(len(zxc)+len(xpesan))
                            xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                            zx = {'S':xlen, 'E':xlen2, 'M':cmem[x].mid}
                            zx2.append(zx)
                            zxc += pesan2
                        text = xpesan+ zxc + "\n[ เช็คอ่านเวลา ]: \n" + readTime
                        try:
                            line.sendMessage(receiver, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                        except Exception as error:
                            print (error)
                        pass
                    else:
                        line.sendMessage(receiver,"พิม ตั้งเวลา ก่อนพิมอ่าน")                  
 #==============================================================================#
                elif msg.text.lower().startswith("ประกูด "):
                            chivareeZ = text.split(" ")
                            chivaree3 = text.replace(chivareeZ[0] + " ", "")
                            ajang = "{}".format(chivaree3)
                            groups = line.getGroupIdsJoined()
                            chivaree9 = line.getContact(lineMID)
                            sender_profile = line.getContact(sender)
                            chivareeZ = line.getProfileCoverURL(line.profile.mid)
                            for gr in groups:
                                data={
                         "type": "flex",
                         "altText": "☆•Flex by A-jang•☆",
                                 "contents": { 
                       "type": "bubble",     
                       "header": {
                         "type": "box",
                         "layout": "vertical",   
                         "contents": [
                           {     
                             "type": "text",
                             "text": "🌟🌟• ประกาศกลุ่ม •🌟🌟",
                             "color": "#66FFFF",
                             "align": "center"
                           }
                         ]
                       },
                       "hero": {
                         "type": "image",
                         "url": "https://sv1.picz.in.th/images/2019/08/09/ZWq4vn.png",
                         "size": "lg",
                         "action": {
                                 "type":"uri","uri":"line://app/1560169633-yaJ7kAZB?type=image&img=https://sv1.picz.in.th/images/2019/08/07/KIzyak.jpg"
                         }
                       },
                       "body": {
                         "type": "box",
                         "layout": "vertical",
                         "contents": [
                           {
                             "type": "text",
                             "text": "{}".format(ajang),
                              "align": "center",
                             "size": "lg",
                             "color": "#000000",
                             "wrap": True,
                             "flex": 1
                           }
                         ]
                       },
                       "footer": {
                          "type": "box",
                          "layout": "vertical",
                          "contents": [
                            {
                              "type": "text",
                              "text": "AVENGERS BOT : 🕒 " +datetime.today().strftime('%H:%M:%S')+ "™",
                              "color": "#66FFFF",
                              "size": "xs",
                              "align": "center"
                            }
                          ]
                        },
                        "styles": {
                          "header": {
                            "backgroundColor": "#000000"
                            },
                            "hero": {
                              "separator": True,
                              "separatorColor": "#000000",
                            },
                            "footer": {
                              "backgroundColor": "#000000",
                              "separator": True,
                              "separatorColor": "#FFFFFF"
                            },
                            "body": {
                             "backgroundColor": "#FFFFFF",
                             
                            }
                          }
                        }
                      }
                                bcTemplate(gr, data)
                                time.sleep(1)     
#==============================================================================#
                elif msg.text in ["เชคค่า","เช็ค"]:
                    try:
                        chivaree_ = "•[🔉]• AVENGERS ONLINE•[🔉]• "
                        if setmybot["ChivareeBig"] == True: chivaree_ += "\n•[🔊]• โหมดสติ๊กเกอร์ตัวใหญ่ "
                        else: chivaree_ += "\n•[🔇]• โหมดสติ๊กเกอร์ตัวใหญ่ "
                        if setmybot["autoBlock"] == True: chivaree_ += "\n•[🔊]• ระบบออโต้บล็อค"
                        else: chivaree_ += "\n•[🔇]• ระบบออโต้บล็อค "
                        if setmybot["autoJoinTicket"] == True: chivaree_ += "\n•[🔊]• มุดลิ้งอัติโนมัติ"
                        else: chivaree_ += "\n•[🔇]• มุดลิ้งอัติโนมัติ  "
                        if setmybot["autoJoin"] == True: chivaree_ += "\n•[🔊]• เข้าห้องอัติโนมัติ"
                        else: chivaree_ += "\n•[🔇]• เข้าห้องอัติโนมัติ "
                        if setmybot["Api"] == True: chivaree_ += "\n•[🔊]• บอทตอบโต้Api "                               
                        else: chivaree_ += "\n•[🔇]• บอทตอบโต้Api "
                        if setmybot["Aip"] == True: chivaree_ += "\n•[🔊]• แสกนคำหยาบ+คำสั่งบิน"
                        else: chivaree_ += "\n•[🔇]• แสกนคำหยาบ+คำสั่งบิน "
                        if setmybot["Wc"] == True: chivaree_ += "\n•[🔊]• ข้อความต้อนรับสมาชิก"
                        else: chivaree_ += "\n•[🔇]• ข้อความต้อนรับสมาชิก " 
                        if setmybot["Lv"] == True: chivaree_ += "\n•[🔊]• ข้อความอำลาสมาชิก"
                        else: chivaree_ += "\n•[🔇]• ข้อความอำลาสมาชิก "
                        if setmybot["Nk"] == True: chivaree_ += "\n•[🔊]• ข้อความแจ้งเมื่อมีคนเตะ "
                        else: chivaree_ += "\n•[🔇]• ข้อความแจ้งเมื่อมีคนเตะ "
                        if setmybot["autoCancel"]["on"] == True: chivaree_+="\n•[🔊]• ปฏิเสธกลุ่มที่สมาชิกน้อยกว่า " + str(settings["autoCancel"]["members"]) + " คน"
                        else: chivaree_ += "\n•[🔇]• ปฏิเสธกลุ่มที่สมาชิกน้อยกว่า 3 คน "
                        if setmybot["autoLeave"] == True: chivaree_ += "\n•[🔊]• เข้าไปขี้และออกกลุ่มอัติโนมัติ "
                        else: chivaree_ += "\n•[🔇]• แดกห้องรันอัติโนมัติ "
                        if setmybot["autoRead"] == True: chivaree_ += "\n•[🔊]• อ่านข้อความอัติโนมัติ "
                        else: chivaree_ += "\n•[🔇]• อ่านข้อความอัติโนมัติ "
                        if setmybot["checkSticker"] == True: chivaree_ += "\n•[🔊]• เช็คไอดีสติ๊กเกอร์ "
                        else: chivaree_ += "\n•[🔇]• เช็คไอดีสติ๊กเกอร์ "
                        if setmybot["detectMention"] == True: chivaree_ += "\n•[🔊]•  ตอบกลับคนแทค"
                        else: chivaree_ += "\n•[🔇]• ตอบกลับคนแทค "
                        if setmybot["potoMention"] == True: chivaree_ += "\n•[🔊]•  แสดงรูปภาพคนแทค "
                        else: chivaree_ += "\n•[🔇]• แสดงรูปภาพคนแทค "
                        if setmybot["kickMention"] == True: chivaree_ += "\n•[🔊]•  เตะคนแทค "
                        else: chivaree_ += "\n•[🔇]• เตะคนแทค "
                        if setmybot["delayMention"] == True: chivaree_ += "\n•[🔊]• แทคกลับคนแทค"
                        else: chivaree_ += "\n•[🔇]• แทคกลับคนแทค"
                        if RfuProtect["inviteprotect"] == True: chivaree_ += "\n•[🔊]• ป้องกันการเชิญ "
                        else: chivaree_ += "\n•[🔇]• ป้องกันการเชิญ "
                        if RfuProtect["protect"] == True: chivaree_ += "\n•[🔊]• ระบบป้องกัน"
                        else: chivaree_ += "\n•[🔇]• ระบบป้องกัน "
                        if RfuProtect["linkprotect"] == True: chivaree_ += "\n•[🔊]• ป้องกันการเปิดลิ้ง"
                        else: chivaree_ += "\n•[🔇]• ป้องกันการเปิดลิ้ง "
                        if RfuProtect["Protectjoin"] == True: chivaree_ += "\n•[🔊]• ระบบกันเข้ากลุ่ม"
                        else: chivaree_ += "\n•[🔇]• ระบบกันเข้ากลุ่ม"
                        chivaree_ += "\n•[🔊🐷]• ™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣ •[🔊🐷]•"
                        ajang = "{}".format(str(chivaree_))
                        chivareeZz={
                         "type": "flex",
                         "altText": "™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣",
                                 "contents": { 
                       "type": "bubble",     
                       "header": {
                         "type": "box",
                         "layout": "vertical",   
                         "contents": [
                           {     
                             "type": "text",
                             "text": "🌟🌟• BOT  TAG  SETTING •🌟🌟",
                             "weight": "bold",
                             "color": "#FF9900",
                             "align": "center"
                           }
                         ]
                       },
                       "body": {
                         "type": "box",
                         "layout": "vertical",
                         "contents": [
                           {
                             "type": "text",
                              "text": "{}".format(str(chivaree_)),
                             "size": "sm",
                              "weight": "bold",
                              "color": "#000000",
                             "gravity": "center",
                             "wrap": True,
                             "flex": 1
                           }
                         ]
                       },
                       "footer": {
                          "type": "box",
                          "layout": "vertical",
                          "contents": [
                            {
                              "type": "text",
                              "text": "™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣",
                              "color": "#FF9900",
                              "align": "center"
                            }
                          ]
                        },
                        "styles": {
                          "header": {
                            "backgroundColor": "#66FFFF"
                            },
                            "footer": {
                              "backgroundColor": "#66FFFF",
                              "separator": True,
                              "separatorColor": "#66FFFF"
                            },
                            "body": {
                             "backgroundColor": "#FFFFFF",
                             
                              }
                            }
                          }
                        }
                        sendTemplate(to, chivareeZz)
                     
                    except Exception as e:
                        line.sendMessage(msg.to, str(e))
                
                elif text.lower() == 'เช็คกลุ่ม':
                        groups = line.groups
                        ret_ = "╔══[ Group List ]"
                        no = 0 + 1
                        for gid in groups:
                            group = line.getGroup(gid)
                            ret_ += "\n╠ {}. {} | {}".format(str(no), str(group.name), str(len(group.members)))
                            no += 1
                        ret_ += "\n╚══[ จำนวน {} Groups ]".format(str(len(groups)))
                        line.sendMessage(to, str(ret_))

                elif text.lower() == 'กลุ่ม':
                        groups = line.groups
                        ret_ = "รายชื่อกลุ่มทั้งหมด :\n"
                        no = 0 + 1
                        for gid in groups:
                            group = line.getGroup(gid)
                            ret_ += "\n{}. {} | {}".format(str(no), str(group.name), str(len(group.members)))
                            no += 1
                        ret_ += "\n\nจำนวน {} กลุ่ม".format(str(len(groups)))
                        data = {
                            "type": "flex",
                            "altText": "Group list",
                            "contents": {
                                "type": "bubble",
                                "styles": {
                                    "body": {
                                         "backgroundColor": '#66FFFF'
                                    },
                                },
                                "body": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "contents": [
                                        {
                                            "type":"text",
                                            "text": ret_,
                                            "color": "#000000",
                                            "wrap": True,
                                            "size": "md"
                                        },
                                    ]
                                }
                            }
                        }
                        sendTemplate(to, data)                 

                elif msg.text in ["ดึง"]:
                        settings["winvite"] = True
                        nn1(to,"send a contact to invite user") 
#-------------------------------------------------------------------------------
        if op.type == 25:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0:
                if sender != line.profile.mid:
                    to = sender
                else:
                    to = receiver
            else:
                to = receiver
            if msg.contentType == 0:
                if text is None:
                    return
#-------------------------------------------------------------------------------
        if op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0:
                if sender != line.profile.mid:
                    to = sender
                else:
                    to = receiver
            else:
                to = receiver
            if msg.contentType == 0:
                if text is None:
                    return
#==============================================================================#
                elif "บินห้อง" in msg.text:
                	if msg.toType == 2:
                         _name = msg.text.replace("บินห้อง","")
                         gs = line.getGroup(receiver)
                         line.sendMessage(receiver,"สู่ความเวิ้งว้าง อันไกลโพ้น")                         
                         line.sendMessage(receiver,"ติดปีกบิน")
                         targets = []
                         for g in gs.members:
                             if _name in g.displayName:
                                 targets.append(g.mid)
                         if targets == []:
                             line.sendMessage(receiver,"Not found.")
                         else:
                             for target in targets:
                             	if not target in Rfu:
                                     try:
                                         klist=[line]
                                         kicker=random.choice(klist)
                                         line.kickoutFromGroup(receiver,[target])
                                         print((receiver,[g.mid]))
                                     except:
                                         line.sendMessage(receiver,"Group cleanse")
                                         print ("Cleanse Group")

                elif msg.text in ["ลบสิริ"]:
                    if msg.toType == 2:
                        print("Kick Siri")
                        x = line.getGroup(to)
                        if lineMID in [i.mid for i in x.members]:
                            sirilist = [i.mid for i in x.members if any(word in i.displayName for word in ["Doctor.A","Eliza","Parry","Rakko","しりちゃん"]) or i.displayName.isdigit()]
                            if sirilist == []:
                                line.sendMessage(to,"ไม่พบสิริอยู่ในกลุ่ม.")
                            for target in sirilist:
                                try:
                                    line.kickoutFromGroup(to,[target])
                                except:
                                    pass

                elif text.lower() == '/เทส':
                    tz = pytz.timezone("Asia/Jakarta")
                    timeNow = datetime.now(tz=tz)
                    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                    hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                    hr = timeNow.strftime("%A")
                    bln = timeNow.strftime("%m")
                    for i in range(len(day)):
                        if hr == day[i]: hasil = day[i]
                    for k in range(0, len(bulan)):
                        if bln == str(k): bln = bulan[k-1]
                    readTime = hasil + ", " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') + "\nเวลา : [ " + timeNow.strftime('%H:%M:%S') + " ]"                    
                    line.sendMessage(to, "█▒... 10.0%")
                    line.sendMessage(to, "██▒... 20.0%")
                    line.sendMessage(to, "███▒... 30.0%")
                    line.sendMessage(to, "████▒... 40.0%")
                    line.sendMessage(to, "█████▒... 50.0%")
                    line.sendMessage(to, "██████▒... 60.0%")
                    line.sendMessage(to, "██████▒.... 70.0%")
                    line.sendMessage(to, "████████▒... 80.0%")
                    line.sendMessage(to, "█████████▒... 90.0%")
                    line.sendMessage(to, "███████████....100.0%")
                    line.sendMessage(msg.to, "ขณะนี้เวลา \n" + readTime)               

                elif text.lower() == '/มา':
                    if msg.toType == 2:
                        group = line.getGroup(to)
                        group.preventedJoinByTicket = False
                        line.updateGroup(group)
                        invsend = 0     

            #=================================================================================#
                elif "/ประกาศ " in msg.text:
                    bc = msg.text.replace("/ประกาศ ","")
                    gid = line.getGroupIdsJoined()
                    for i in gid:
                        line.sendMessage(i,"\n"+bc+"\n\nBy: NN")
                        time.sleep(1)
#                    
                elif "/แชทเพื่อน " in msg.text:
                    bc = msg.text.replace("/บอทแชร์แชทเพื่อน ","")
                    gid = line.getAllContactIds()
                    for i in gid:
                        line.sendText(i,"\n"+bc+"\n")

                if text.lower() == 'บอทออก':
                                if msg._from in admin:
                                    nn2(to,"ลาก่อน👋")
                                    line.leaveGroup(to)
                if text.lower() == 'บอทออกทุกกลุ่ม':
                                if msg._from in admin:
                                    gid = line.getGroupIdsJoined()
                                    for i in gid:
                                        line.sendMessage(i,"หากสนใจใช้บอทกรุณาติดต่อ\n\nhttps://line://ti/p/~0969245004")
                                        line.leaveGroup(i)                 
                
                elif msg.text in ["เอจังgift","แจกคับ","แจกๆ","ของขวัญ","เอจังแจก","เอจังใจดี","เศษตังแม่","พ่อกูรวย","รับของขวัญ","แลกของขวัญ","ของขวัญเอจัง"]:
                    line.sendGift(to,'1002077','sticker')
                    line.sendGift(to,'1002077','sticker')
                    line.sendGift(to,'1002077','sticker')
                    line.sendGift(to,'1002077','sticker')
                    line.sendGift(to,'1002077','sticker')
                    time.sleep(1)
                    nn2(to, "❣️🐷   พี่ม่อนแจกจ้า  🐷❣️")
                    
                elif text.lower() == "ลบแชทบอท":
                        if msg._from in admin:
                            try:
                                line.removeAllMessages(op.param2) 
                                time.sleep(1)
                                nn2(to,"(ล้างแชทเรียบร้อย .. (｀・ω・´)")
                            except:
                                pass
                                print ("Remove Chat Bot")
#เชคบอท01                                
                elif text.lower() == 'คท':
                    sendMessageWithMention(to, sender)
                    line.sendContact(to, sender)
                
                elif text.lower() == 'ผส':
                    sendMessageWithMention(to, lineMID)
                    line.sendContact(to, "u6f1426e90a67990ba6bc167fc93437a1")
                    nn2(to, "💓🐷   ผู้สร้างบอท   🐷💓")
                elif text.lower() == 'มิดบอท':
                    line.sendMessage(to,"[MID]\n" +  lineMID)
                elif text.lower() == 'ชื่อบอท':
                    me = line.getContact(lineMID)
                    line.sendMessage(to,"[DisplayName]\n" + me.displayName)
                elif text.lower() == 'ตัสบอท':
                    me = line.getContact(lineMID)
                    line.sendMessage(to,"[StatusMessage]\n" + me.statusMessage)
                elif text.lower() == 'ดิสบอท':
                    me = line.getContact(lineMID)
                    line.sendImageWithURL(to,"http://dl.profile.line-cdn.net/" + me.pictureStatus)
                elif text.lower() == 'วีดีโอบอท':
                    me = line.getContact(lineMID)
                    line.sendVideoWithURL(to,"http://dl.profile.line-cdn.net/" + me.pictureStatus + "/vp")
                elif text.lower() == 'ปกบอท':
                    me = line.getContact(lineMID)
                    cover = line.getProfileCoverURL(lineMID)    
                    line.sendImageWithURL(to, cover)
                    
                elif msg.text.lower().startswith("คท "):
                    if 'MENTION' in list(msg.contentMetadata.keys())!= None:
                        names = re.findall(r'@(\w+)', text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        lists = []
                        for mention in mentionees:
                            if mention["M"] not in lists:
                                lists.append(mention["M"])
                        for ls in lists:
                            contact = line.getContact(ls)
                            mi_d = contact.mid
                            line.sendContact(to, mi_d)
                elif msg.text.lower().startswith("มิด "):
                    if 'MENTION' in list(msg.contentMetadata.keys())!= None:
                        names = re.findall(r'@(\w+)', text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        lists = []
                        for mention in mentionees:
                            if mention["M"] not in lists:
                                lists.append(mention["M"])
                        ret_ = "[ Mid User ]"
                        for ls in lists:
                            ret_ += "\n{}" + ls
                        line.sendMessage(to, str(ret_))
                elif msg.text.lower().startswith("ชื่อ "):
                    if 'MENTION' in list(msg.contentMetadata.keys())!= None:
                        names = re.findall(r'@(\w+)', text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        lists = []
                        for mention in mentionees:
                            if mention["M"] not in lists:
                                lists.append(mention["M"])
                        for ls in lists:
                            contact = line.getContact(ls)
                            line.sendMessage(to, "[ Display Name ]\n" + contact.displayName)
                elif msg.text.lower().startswith("ตัส "):
                    if 'MENTION' in list(msg.contentMetadata.keys())!= None:
                        names = re.findall(r'@(\w+)', text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        lists = []
                        for mention in mentionees:
                            if mention["M"] not in lists:
                                lists.append(mention["M"])
                        for ls in lists:
                            contact = line.getContact(ls)
                            line.sendMessage(to, "[ Status Message ]\n{}" + contact.statusMessage)
                elif msg.text.lower().startswith("ดิส "):
                    if 'MENTION' in list(msg.contentMetadata.keys())!= None:
                        names = re.findall(r'@(\w+)', text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        lists = []
                        for mention in mentionees:
                            if mention["M"] not in lists:
                                lists.append(mention["M"])
                        for ls in lists:
                            path = "http://dl.profile.line.naver.jp/" + line.getContact(ls).pictureStatus
                            line.sendImageWithURL(to, str(path))
                elif msg.text.lower().startswith("วีดีโอ "):
                    if 'MENTION' in list(msg.contentMetadata.keys())!= None:
                        names = re.findall(r'@(\w+)', text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        lists = []
                        for mention in mentionees:
                            if mention["M"] not in lists:
                                lists.append(mention["M"])
                        for ls in lists:
                            path = "http://dl.profile.line.naver.jp/" + line.getContact(ls).pictureStatus + "/vp"
                            line.sendImageWithURL(to, str(path))
                elif msg.text.lower().startswith("ปก "):
                    if line != None:
                        if 'MENTION' in list(msg.contentMetadata.keys())!= None:
                            names = re.findall(r'@(\w+)', text)
                            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                            mentionees = mention['MENTIONEES']
                            lists = []
                            for mention in mentionees:
                                if mention["M"] not in lists:
                                    lists.append(mention["M"])
                            for ls in lists:
                                path = line.getProfileCoverURL(ls)
                                line.sendImageWithURL(to, str(path))
                
#==============================================================================#
                elif msg.text.lower().startswith("พิมตาม "):
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        try:
                            settings["mimic"]["target"][target] = True
                            nn2(to,"🐷   พิมตามรับทราบ   🐷")
                            break
                        except:
                            nn2(to,"🐷   พิมตามรับทราบ   🐷")
                            break
                elif msg.text.lower().startswith("ลบพิมตาม "):
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        try:
                            del settings["mimic"]["target"][target]
                            nn2(to,"🐷   ยกเลิกพิมตาม   🐷")
                            break
                        except:
                            nn2(to,"🐷   ยกเลิกพิมตาม   🐷")
                            break
                elif text.lower() == 'เช็คพิมตาม':
                    if settings["mimic"]["target"] == {}:
                        line.sendMessage(msg.to,"ไม่มีคนทีพูดตาม")
                    else:
                        mc = "╔══[ รายชื่อ ]"
                        for mi_d in settings["mimic"]["target"]:
                            mc += "\n╠ "+line.getContact(mi_d).displayName
                        kittyText(msg.to,mc + "\n╚══[ 🐷🐷🐷 ]")
                    
                elif "พิมตาม" in msg.text.lower():
                    sep = text.split(" ")
                    mic = text.replace(sep[0] + " ","")
                    if mic == "เปิด":
                        if settings["mimic"]["status"] == False:
                            settings["mimic"]["status"] = True
                            nn(to,"🐷   เปิดระบบพิมตาม   🐷")
                    elif mic == "ปิด":
                        if settings["mimic"]["status"] == True:
                            settings["mimic"]["status"] = False
                            nn2(to,"🐷   เปิดระบบพิมตาม   🐷")
#==============================================================================#
                elif 'เพลสโต ' in msg.text.lower():
                        tob = msg.text.lower().replace('เพลสโต ',"")
                        line.sendMessage(to,"กรุณารอสักครู่...")
                        line.sendMessage(to,"ผลจากการค้นหา : "+tob+"\nจาก : Google Play\nลิ้งโหลด : https://play.google.com/store/search?q=" + tob)
                        time.sleep(1)
                        nn2(to,"👆กรุณากดลิ้งเพื่อทำการโหลดแอพ👆")
                elif 'ขอเพลง ' in msg.text.lower():
                        tob = msg.text.lower().replace('ขอเพลง ',"")
                        line.sendMessage(to,"กรุณารอสักครู่...")
                        line.sendMessage(to,"ผลจากการค้นหา : "+tob+"\nจาก : ยูทูป\nลิ้งรับชม : https://m.youtube.com/results?search_query=เพลง" + tob)
                        time.sleep(1)
                        nn2(to,"👆กดลิ้งเพื่อเปิดYouTube👆")
                elif 'github' in msg.text.lower():
                        tob = msg.text.lower().replace('github ',"")
                        line.sendMessage(to,"กรุณารอสักครู่...")
                        line.sendMessage(to,"ผลจากการค้นหา : "+tob+"\nจาก : GitHub\nลิ้ง : https://github.com/search?q=" + tob)
                        time.sleep(1)
                        nn2(to,"👆ค้นหาสำเร็จแล้ว👆")
                elif 'กูเกิ้ล ' in msg.text.lower():
                        tob = msg.text.lower().replace('กูเกิ้ล ',"")
                        line.sendMessage(to,"กรุณารอสักครู่...")
                        line.sendMessage(to,"ผลจากการค้นหา : "+tob+"\nจาก : กูเกิ้ล\nลิ้ง : https://www.google.co.th/search?q=" + tob)
                        time.sleep(1)                       
                        nn2(to,"👆กดลิ้งเพื่อเข้าGoogle👆")
                elif 'เฟส ' in msg.text.lower():
                        tob = msg.text.lower().replace('เฟส ',"")
                        line.sendMessage(to,"กรุณารอสักครู่...")
                        line.sendMessage(to,"ผลจากการค้นหา : "+tob+"\nจาก : เฟสบุค\nลิ้ง : https://m.facebook.com/search/top/?q=" + tob)
                        time.sleep(1)
                        nn2(to,"👆กดลิ้งเพื่อเข้าไปดูรายละเอียด👆")
                        
                elif "คท:" in msg.text:
                    mmid = msg.text.replace("คท:","")
                    line.sendMessage(to, text=None, contentMetadata={'mid': mmid}, contentType=13)
                elif "ค้นหาไอดี " in msg.text:
                    msgg = msg.text.replace("ค้นหาไอดี ",'')
                    conn = line.findContactsByUserid(msgg)
                    if True:
                        msg.contentType = 13
                        msg.contentMetadata = {'mid': conn.mid}
                        line.sendMessage(msg.to,"http://line.me/ti/p/~" + msgg)
                        line.sendMessage(to,msg)
                elif "Spam " in msg.text:
                    txt = msg.text.split(" ")
                    jmlh = int(txt[2])
                    teks = msg.text.replace("Spam "+str(txt[1])+" "+str(jmlh)+" ","")
                    tulisan = jmlh * (teks+"\n")
                    if txt[1] == "on":
                        if jmlh <= 100000:
                           for x in range(jmlh):
                               line.sendMessage(to, teks)
                        else:
                           line.sendMessage(to, "Out of Range!")
                    elif txt[1] == "off":
                        if jmlh <= 100000:
                            line.sendMessage(to, tulisan)
                        else:
                            line.sendMessage(to, "Out Of Range!")
            
                elif "/google " in msg.text.lower():
                    spl = re.split("/google ",msg.text,flags=re.IGNORECASE)
                    if spl[0] == "":
                        if spl[1] != "":
                                try:
                                    if msg.toType != 0:
                                        line.sendMessage(msg.to,"กำลังรับข้อมูล กรุณารอสักครู่..")
                                    else:
                                        line.sendMessage(msg.from_,"กำลังรับข้อมูล กรุณารอสักครู่..")
                                    resp = BeautifulSoup(requests.get("https://www.google.co.th/search",params={"q":spl[1],"gl":"th"}).content,"html.parser")
                                    text = "ผลการค้นหาจาก Google:\n\n"
                                    for el in resp.findAll("h3",attrs={"class":"r"}):
                                        try:
                                                tmp = el.a["class"]
                                                continue
                                        except:
                                                pass
                                        try:
                                                if el.a["href"].startswith("/search?q="):
                                                    continue
                                        except:
                                                continue
                                        text += el.a.text+"\n"
                                        text += str(el.a["href"][7:]).split("&sa=U")[0]+"\n\n"
                                    text = text[:-2]
                                    if msg.toType != 0:
                                        line.sendText(msg.to,str(text))
                                    else:
                                        line.sendText(msg.from_,str(text))
                                except Exception as e:
                                    print(e)
                        
                elif "/โทร" in msg.text.lower():
                            if msg.toType == 2:
                                sep = text.split(" ")
                                strnum = text.replace(sep[0] + " ","")
                                num = int(strnum)
                                line.sendMessage(to, "เชิญเข้าร่วมการคอลเรียบร้อย(｀・ω・´)")
                                for var in range(0,num):
                                    group = line.getGroup(to)
                                    members = [mem.mid for mem in group.members]
                                    line.acquireGroupCallRoute(to)
                                    line.inviteIntoGroupCall(to, contactIds=members)
                                    
                elif "พูด " == msg.text.lower():
                       sep = text.split(" ")
                       say = text.replace(sep[0] + " ","")
                       lang = 'th'
                       tts = gTTS(text=say, lang=lang)
                       tts.save("hasil.mp3")
                       nadya.sendAudio(msg.to,"hasil.mp3")
                       
                elif "โทร" == msg.text.lower():
                    line.inviteIntoGroupCall(msg.to,[uid.mid for uid in line.getGroup(msg.to).members if uid.mid != line.getProfile().mid])
                    line.sendMessage(msg.to,"เชิญเข้าร่วมการโทรสำเร็จ(｀・ω・´)")
#==============================================================================#
                elif text.lower() == 'ไอดีกลุ่ม':
                    gid = line.getGroup(to)
                    line.sendMessage(to, "ID กลุ่มนี้ \n" + gid.id)
                elif text.lower() == 'ปกกลุ่ม':
                    group = line.getGroup(to)
                    path = "http://dl.profile.line-cdn.net/" + group.pictureStatus
                    line.sendImageWithURL(to, path)
                elif text.lower() == 'ชื่อกลุ่ม':
                    gid = line.getGroup(to)
                    line.sendMessage(to, "ชื่อ กลุ่ม -> \n" + gid.name)
#กลุ่ม.                       
                elif msg.text in ["ข้อมูลกลุ่ม"]:
                    group = line.getGroup(to)
                    try:
                        gCreator = group.creator.displayName
                    except:
                        gCreator = "คนนี้คือผู้สร้างกลุ่มนี้"
                    if group.invitee is None:
                        gPending = "0"
                    else:
                        gPending = str(len(group.invitee))
                    if group.preventedJoinByTicket == True:
                        gQr = "ปิด"
                        gTicket = "   รายการลิงค์กลุ่มปิดอยู่คับ"
                    else:
                        gQr = "เปิด"
                        gTicket = "https://line.me/R/ti/g/{}".format(str(line.reissueGroupTicket(group.id)))
                    path = "http://dl.profile.line-cdn.net/" + group.pictureStatus
                    ajang = ""
                    ajang += "\n•❂• ชื่อกลุ่ม : {}".format(str(group.name))
                    ajang += "\n•❂• ผู้สร้างกลุ่ม : {}".format(str(gCreator))
                    ajang += "\n•❂• มีสมาชิกจำนวน {} คนคับ".format(str(len(group.members)))
                    ajang += "\n•❂• มีค้างเชิญจำนวน {} คนคับ".format(gPending)
                    ajang += "\n•❂• สถานะกลุ่มตอนนี้ •{}• คับ".format(gQr)
                    ajang += "\n•➤• {}".format(gTicket)
                    chivaree = "{}".format(str(ajang))
                    ajangSS={
                         "type": "flex",
                         "altText": "☆•Gr❂up Data nn•☆",
                                 "contents": { 
                       "type": "bubble",     
                       "header": {
                                            "type": "box",
                                            "layout": "baseline",
                                            "contents": [
                                                    {
                                                    "type": "text",
                                                    "text": "™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣",
                                                     "align": "center",
                                                     "margin": "xxl",
                                                    "weight": "bold",
                                                    "color": "#66FFFF",
                                                    "size": "md"
                                                }
                                            ]
                                        },
                       "hero": {
                         "type": "image",
                         "url": "https://sv1.picz.in.th/images/2020/01/28/RpCOvI.png",
                         "size": "full",
                           "aspectRatio": "1:1",
                            "aspectMode": "fit",
                            "action": {
                                 "type":"uri","uri":"line://app/1602687308-GXq4Vvk9?type=image&img=https://sv1.picz.in.th/images/2019/08/07/KIzyak.jpg"
                         }
                       },
                       "body": {
                       "type": "box",
                       "layout": "vertical",
                         "contents": [
                            {
                            "type": "text",
                            "text": "💗•ข้อมูลกลุ่ม•💗",
                            "weight": "bold",
                            "align": "center",
                            "size": "md",
                            "color": "#000000",
                            'flex': 1,
                            },
                            {
                             "type": "text",
                             "text": "{}".format(str(ajang)),
                             "size": "sm",
                             "weight": "bold",
                             "color": "#000000",
                             "wrap": True,
                             "flex": 1
                           }
                         ]
                       },
                       "footer": {
                          "type": "box",
                          "layout": "vertical",
                          "contents": [
                            {
                              "type": "text",
                              "text": "BOT TAG: 🕒 " +datetime.today().strftime('%H:%M:%S')+ "™",
                              "color": "#FF9900",
                              "weight": "bold",
                              "size": "md",
                              "align": "center"
                            }
                          ]
                        },
                        "styles": {
                          "header": {
                            "backgroundColor": "#66FFFF"
                            },
                            "hero": {
                              "separator": True, 
                              "separatorColor": "#66FFFF",
                              "backgroundColor": "#66FFFF"
                            },
                            "footer": {
                              "backgroundColor": "#66FFFF",
                              "separator": True,
                              "separatorColor": "#66FFFF"
                            },
                            "body": {
                             "backgroundColor": "#66FFFF",
                             
                            }
                          }
                        }
                      }
                    sendTemplate(to, ajangSS)
                elif msg.text in ["สมาชิกกลุ่ม"]:
                    if msg.toType == 2:
                        group = line.getGroup(to)
                        ajang = "       ♡•สมาชิกในกลุ่มนี้คับ•♡\n●•➤➤➤➤➤➤➤➤➤➤➤➤"
                        no = 0 + 1
                        for mem in group.members:
                            ajang += "\n♡ {}. {}".format(str(no), str(mem.displayName))
                            no += 1
                        ajang += "\n●•➤➤➤➤➤➤➤➤➤➤➤➤\n   [ จำนวน {} คน  by : -৩้Ꭷ৩ꪶꪶ৩้৩• ]".format(str(len(group.members)))
                        chivaree = "{}".format(str(ajang))
                        data = {
                                "type": "text",
                                "text": "{}".format(str(ajang)),
                                "sentBy": {
                                    "label": "{}".format(line.getContact(lineMID).displayName),
                                    "iconUrl": "https://obs.line-scdn.net/{}".format(line.getContact(lineMID).pictureStatus),
                                    "linkUrl": "line://ti/p/~0969245004"
                                }
                            }
                        sendTemplate(to, data)                
                elif text.lower() == 'กลุ่มบอท':
                        groups = line.groups
                        ret_ = "╔══[ Group List ]"
                        no = 0 + 1
                        for gid in groups:
                            group = line.getGroup(gid)
                            ret_ += "\n╠ {}. {} | {}".format(str(no), str(group.name), str(len(group.members)))
                            no += 1
                        ret_ += "\n╚══[ จำนวน {} Groups ]".format(str(len(groups)))
                        line.sendMessage(to, str(ret_))

                elif msg.text.lower() == ".getjoined":
                    line.sendText(msg.to,"กรุณารอสักครู่ ใจเย็นๆ")
                    all = line.getGroupIdsJoined()
                    text = ""
                    cnt = 0
                    for i in all:
                        text += line.getGroup(i).name + "\n" + i + "\n\n"
                        cnt += 1
                        if cnt == 10:
                            line.sendText(msg.to,text[:-2])
                            text = ""
                            cnt = 0
                    line.sendText(msg.to,text[:-2])
                    cnt = 0
                elif "ข้อมูล " in msg.text.lower():
                    spl = re.split("ข้อมูล ",msg.text,flags=re.IGNORECASE)
                    if spl[0] == "":
                        prov = eval(msg.contentMetadata["MENTION"])["MENTIONEES"]
                        for i in range(len(prov)):
                            uid = prov[i]["M"]
                            userData = line.getContact(uid)
                            try:
                                line.sendImageWithURL(to,"http://dl.profile.line.naver.jp/"+userData.pictureStatus)
                            except:
                                pass
                            nn2(msg.to,"ชื่อ👉 "+userData.displayName)
                            line.sendMessage(to,"สเตตัส:\n"+userData.statusMessage)
                            line.sendMessage(to,"ไอดี: "+userData.mid)
                            msg.contentType = 13
                            msg.text = None
                            msg.contentMetadata = {'mid': userData.mid}
                            line.sendMessage(to,text=None,contentMetadata = {'mid': userData.mid},contentType = 13)
#----------------------------------------------------------------------------------------------------------------------- 
                elif msg.text.lower().startswith("ส่งหัวใจ "):
                    sep = text.split(" ")
                    text = text.replace(sep[0] + " ","")
                    cond = text.split(" ")
                    jml = int(cond[0])
                    if msg.toType == 2:
                        group = line.getGroup(to)
                    for x in range(jml):
                        if 'MENTION' in msg.contentMetadata.keys()!= None:
                            names = re.findall(r'@(\w+)', text)
                            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                            mentionees = mention['MENTIONEES']
                            lists = []
                            for mention in mentionees:
                                if mention["M"] not in lists:
                                    lists.append(mention["M"])
                            for receiver in lists:
                                line.sendMessage(receiver,"💖•💗•รั.ก.น่.ะ.ค่.ะ.จุ้.ฟ.ๆ•💗•💖\n💖•💗•รั.ก.น่.ะ.ค่.ะ.จุ้.ฟ.ๆ•💗•💖\n💖.V.i.r.u.s.A.-j.a.n.g.💗.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.💗.N.e.w.2.0.1.9.💗")
                                line.sendMessage(receiver,"💖•💗•รั.ก.น่.ะ.ค่.ะ.จุ้.ฟ.ๆ•💗•💖\n💖•💗•รั.ก.น่.ะ.ค่.ะ.จุ้.ฟ.ๆ•💗•💖\n💗.ไ.ว.รั.ส.เ.อ.จั.ง.💟.เ .ฉ.พ.า.ะ.ไ.ล.น์.สี.&ไ.ล.น์.ค.ลั.บ.ค่.ะ.~.💚.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S4.4.4.4.4.4ไ.ว.รั.ส.ฟ.รุ้.ง.มุ้.ง.มิ้.ง.b.y.เ.อ.จั.ง.~.☆.😁.🤗.💚")
                                line.sendMessage(to, "💗•ส่งในแชทสต.แล้วคับ•💗".format(str(jml)))
                            else:
                                pass
                elif msg.text.lower().startswith("ส่งคลิป "):
                    sep = text.split(" ")
                    text = text.replace(sep[0] + " ","")
                    cond = text.split(" ")
                    jml = int(cond[0])
                    if msg.toType == 2:
                        group = line.getGroup(to)
                    for x in range(jml):
                        if 'MENTION' in msg.contentMetadata.keys()!= None:
                            names = re.findall(r'@(\w+)', text)
                            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                            mentionees = mention['MENTIONEES']
                            lists = []
                            for mention in mentionees:
                                if mention["M"] not in lists:
                                    lists.append(mention["M"])
                            for receiver in lists:
                                line.sendMessage(receiver, "🌀•คลิปหลุดนักศึกษาเสียวสุดๆ•🌀\n🌀•คลิปหลุดนักศึกษาเสียวสุดๆ•🌀\n💖.V.i.r.u.s.A.-j.a.n.g.💗.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.💗.N.e.w.2.0.1.9.💗")
                                line.sendMessage(receiver, "🌀•คลิปหลุดนักศึกษาเสียวสุดๆ•🌀\n🌀•คลิปหลุดนักศึกษาเสียวสุดๆ•🌀\n💗.ไ.ว.รั.ส.เ.อ.จั.ง.💟.เ .ฉ.พ.า.ะ.ไ.ล.น์.สี.&ไ.ล.น์.ค.ลั.บ.ค่.ะ.~.💚.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S4.4.4.4.4.4ไ.ว.รั.ส.ฟ.รุ้.ง.มุ้.ง.มิ้.ง.b.y.เ.อ.จั.ง.~.☆.😁.🤗.💚")
                                line.sendMessage(to, "🌀ดูคลิปเด็ดในแชท สต.น่ะคับ🌀".format(str(jml)))
                                
                elif msg.text.lower().startswith("แจกของขวัญ "):
                    sep = text.split(" ")
                    text = text.replace(sep[0] + " ","")
                    cond = text.split(" ")
                    jml = int(cond[0])
                    if msg.toType == 2:
                        group = line.getGroup(to)
                    for x in range(jml):
                        if 'MENTION' in msg.contentMetadata.keys()!= None:
                            names = re.findall(r'@(\w+)', text)
                            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                            mentionees = mention['MENTIONEES']
                            lists = []
                            for mention in mentionees:
                                if mention["M"] not in lists:
                                    lists.append(mention["M"])
                            for receiver in lists:
                                line.sendGift(receiver, '1002077','sticker')
                                line.sendMessage(to, "🎁•รับทางแชทสต.นะคับ•🎁".format(str(jml)))
                            else:
                                pass
                
                elif msg.text.lower().startswith("ส่งนอน "):
                    sep = text.split(" ")
                    text = text.replace(sep[0] + " ","")
                    cond = text.split(" ")
                    jml = int(cond[0])
                    if msg.toType == 2:
                        group = line.getGroup(to)
                    for x in range(jml):
                        if 'MENTION' in msg.contentMetadata.keys()!= None:
                            names = re.findall(r'@(\w+)', text)
                            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                            mentionees = mention['MENTIONEES']
                            lists = []
                            for mention in mentionees:
                                if mention["M"] not in lists:
                                    lists.append(mention["M"])
                            for receiver in lists:
                                line.sendMessage(receiver,"🌙•หลับฝันดีน่ะคับที่รัก จุ๊ฟป้อก•🌙\n🌙•หลับฝันดีน่ะคับที่รัก จุ๊ฟป้อก•🌙\n💖.V.i.r.u.s.A.-j.a.n.g.💗.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.💗.N.e.w.2.0.1.9.💗")
                                line.sendMessage(receiver, "🌙•หลับฝันดีน่ะคับที่รัก จุ๊ฟป้อก•🌙\n🌙•หลับฝันดีน่ะคับที่รัก จุ๊ฟป้อก•🌙\n💗.ไ.ว.รั.ส.เ.อ.จั.ง.💟.เ .ฉ.พ.า.ะ.ไ.ล.น์.สี.&ไ.ล.น์.ค.ลั.บ.ค่.ะ.~.💚.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S4.4.4.4.4.4ไ.ว.รั.ส.ฟ.รุ้.ง.มุ้.ง.มิ้.ง.b.y.เ.อ.จั.ง.~.☆.😁.🤗.💚")
                                line.sendMessage(to, "🌙•ส่งในแชทสต.แล้วคับ•🌙".format(str(jml)))
                            else:
                                pass
                                
                elif msg.text.lower().startswith("ส่งความรัก "):
                    sep = text.split(" ")
                    text = text.replace(sep[0] + " ","")
                    cond = text.split(" ")
                    jml = int(cond[0])
                    if msg.toType == 2:
                        group = line.getGroup(to)
                    for x in range(jml):
                        if 'MENTION' in msg.contentMetadata.keys()!= None:
                            names = re.findall(r'@(\w+)', text)
                            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                            mentionees = mention['MENTIONEES']
                            lists = []
                            for mention in mentionees:
                                if mention["M"] not in lists:
                                    lists.append(mention["M"])
                            for receiver in lists:
                                line.sendMessage(receiver, "💖.ฉั.น.รั.ก.เ.ธ.อ.ที่.สุ.ด.เ.ล.ย.💖\n💖.ฉั.น.รั.ก.เ.ธ.อ.ที่.สุ.ด.เ.ล.ย.💖\n💖.V.i.r.u.s.A.-j.a.n.g.💗.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.💗.N.e.w.2.0.1.9.💗")
                                line.sendMessage(receiver, "💖.ฉั.น.รั.ก.เ.ธ.อ.ที่.สุ.ด.เ.ล.ย.💖\n💖.ฉั.น.รั.ก.เ.ธ.อ.ที่.สุ.ด.เ.ล.ย.💖\n💗.ไ.ว.รั.ส.เ.อ.จั.ง.💟.เ .ฉ.พ.า.ะ.ไ.ล.น์.สี.&ไ.ล.น์.ค.ลั.บ.ค่.ะ.~.💚.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S4.4.4.4.4.4ไ.ว.รั.ส.ฟ.รุ้.ง.มุ้.ง.มิ้.ง.b.y.เ.อ.จั.ง.~.☆.😁.🤗.💚")
                                line.sendMessage(to, "💗•ส่งในแชทสต.แล้วคับ•💗".format(str(jml)))
                            else:
                                pass 
                    
                elif msg.text.lower().startswith("ส่งความคิดถึง "):
                    sep = text.split(" ")
                    text = text.replace(sep[0] + " ","")
                    cond = text.split(" ")
                    jml = int(cond[0])
                    if msg.toType == 2:
                        group = line.getGroup(to)
                    for x in range(jml):
                        if 'MENTION' in msg.contentMetadata.keys()!= None:
                            names = re.findall(r'@(\w+)', text)
                            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                            mentionees = mention['MENTIONEES']
                            lists = []
                            for mention in mentionees:
                                if mention["M"] not in lists:
                                    lists.append(mention["M"])
                            for receiver in lists:
                                line.sendMessage(receiver, "💖.คิ.ด.ถึ.ง.เ.ธ.อ.ที่.สุ.ด.เ.ล.ย.💖\n💖.คิ.ด.ถึ.ง.เ.ธ.อ.ที่.สุ.ด.เ.ล.ย.💖\nไ.ว.รั.ส.คิ.ด.ตี้.เ.อ.จั.ง.~.💚เ.ฉ.พ.า.ะ.ไ.ล.น์.เ.ขี.ย.ว.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.♡.K.1.t.t.y.b.y.เ.อ.จั.ง.~.☆.💖.💔.💙.")
                                line.sendMessage(receiver, "💖.คิ.ด.ถึ.ง.เ.ธ.อ.ที่.สุ.ด.เ.ล.ย.💖\n💖.คิ.ด.ถึ.ง.เ.ธ.อ.ที่.สุ.ด.เ.ล.ย.💖\n💗.ไ.ว.รั.ส.เ.อ.จั.ง.💟.เ .ฉ.พ.า.ะ.ไ.ล.น์.สี.&ไ.ล.น์.ค.ลั.บ.ค่.ะ.~.💚.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S4.4.4.4.4.4ไ.ว.รั.ส.ฟ.รุ้.ง.มุ้.ง.มิ้.ง.b.y.เ.อ.จั.ง.~.☆.??.🤗.💚")
                                line.sendMessage(to, "💗•ส่งในแชทสต.แล้วคับ•💗".format(str(jml)))
                            else:
                                pass                       

                elif msg.text.lower().startswith("ส่งของขวัญ "):
                    sep = text.split(" ")
                    text = text.replace(sep[0] + " ","")
                    cond = text.split(" ")
                    jml = int(cond[0])
                    if msg.toType == 2:
                        group = line.getGroup(to)
                    for x in range(jml):
                        if 'MENTION' in msg.contentMetadata.keys()!= None:
                            names = re.findall(r'@(\w+)', text)
                            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                            mentionees = mention['MENTIONEES']
                            lists = []
                            for mention in mentionees:
                                if mention["M"] not in lists:
                                    lists.append(mention["M"])
                            for receiver in lists:
                                line.sendMessage(receiver,"คุ.ณ.ไ.ด้.รั.บ.ข.อ.ง.ข.วั.ญ.ค่.ะ.🎁\nคุ.ณ.ไ.ด้.รั.บ.ข.อ.ง.ข.วั.ญ.ค่.ะ.🎁\n💖.V.i.r.u.s.A.-j.a.n.g.💗.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.⭐.เอ.จัง.1.0.V.E.💗.N.e.w.2.0.1.9.💗")
                                line.sendMessage(receiver,"คุ.ณ.ไ.ด้.รั.บ.ข.อ.ง.ข.วั.ญ.ค่.ะ.🎁\nคุ.ณ.ไ.ด้.รั.บ.ข.อ.ง.ข.วั.ญ.ค่.ะ.🎁\n💗.ไ.ว.รั.ส.เ.อ.จั.ง.💟.เ .ฉ.พ.า.ะ.ไ.ล.น์.สี.&ไ.ล.น์.ค.ลั.บ.ค่.ะ.~.💚.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S4.4.4.4.4.4ไ.ว.รั.ส.ฟ.รุ้.ง.มุ้.ง.มิ้.ง.b.y.เ.อ.จั.ง.~.☆.😁.🤗.💚")
                                line.sendMessage(to, "🎁•รับทางแชทสต.นะคับ•🎁".format(str(jml)))
                            else:
                                pass                            
                elif "/กด" in msg.text:
                    spl = msg.text.split("/กด")
                    if spl[len(spl)-1] == "":
                        line.sendText(msg.to,"กดที่นี่เพื่อเขย่าข้อความด้านบน:\nline://nv/chatMsg?chatId="+msg.to+"&messageId="+msg.id)	
                elif "/เข้าไป" in msg.text.lower():
                    spl = re.split("/เข้าไป",msg.text,flags=re.IGNORECASE)
                    if spl[0] == "":
                        spl[1] = spl[1].strip()
                        ag = line.getGroupIdsInvited()
                        txt = "กำลังยกเลิกค้างเชิญจำนวน "+str(len(ag))+" กลุ่ม"
                        if spl[1] != "":
                            txt = txt + " ด้วยข้อความ \""+spl[1]+"\""
                        txt = txt + "\nกรุณารอสักครู่.."
                        line.sendText(msg.to,txt)
                        procLock = len(ag)
                        for gr in ag:
                            try:
                                line.acceptGroupInvitation(gr)
                                if spl[1] != "":
                                    line.sendText(gr,spl[1])
                                line.leaveGroup(gr)
                            except:
                                pass
                        line.sendText(msg.to,"สำเร็จแล้ว")	
                elif ".whois " in msg.text.lower():
                    spl = re.split(".whois ",msg.text,flags=re.IGNORECASE)
                    if spl[0] == "":
                        msg.contentType = 13
                        msg.text = None
                        msg.contentMetadata = {"mid":spl[1]}
                        line.sendMessage(msg)
                elif ".remove " in msg.text.lower():
                    if msg.toType == 2:
                        prov = eval(msg.contentMetadata["MENTION"])["MENTIONEES"]
                        for i in range(len(prov)):
                            random.choice(Exc).kickoutFromGroup(msg.to,[prov[i]["M"]])
                elif ".bye " in msg.text.lower():
                    if msg.toType == 2:
                        prov = eval(msg.contentMetadata["MENTION"])["MENTIONEES"]
                        allmid = []
                        for i in range(len(prov)):
                            line.kickoutFromGroup(msg.to,[prov[i]["M"]])
                            allmid.append(prov[i]["M"])
                        line.findAndAddContactsByMids(allmid)
                        line.inviteIntoGroup(msg.to,allmid)
                        line.cancelGroupInvitation(msg.to,allmid)

                elif msg.text.lower() == ".myid":
                    line.sendText(msg.to,user1)
                elif msg.text.lower().startswith(".mentionall"):
                    data = msg.text[len(".mentionall"):].strip()
                    if data == "":
                        group = line.getGroup(msg.to)
                        nama = [contact.mid for contact in group.members if contact.mid != user1]
                        cb = ""
                        cb2 = ""
                        count = 1
                        strt = len(str(count)) + 2
                        akh = int(0)
                        cnt = 0
                        for md in nama:
                            akh = akh + len(str(count)) + 2 + 5
                            cb += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(md)+"},"""
                            strt = strt + len(str(count+1)) + 2 + 6
                            akh = akh + 1
                            cb2 += str(count)+". @name\n"
                            cnt = cnt + 1
                            if cnt == 50:
                                cb = (cb[:int(len(cb)-1)])
                                cb2 = cb2[:-1]
                                msg.contentType = 0
                                msg.text = cb2
                                msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+cb+']}','EMTVER':'4'}
                                try:
                                    line.sendMessage(msg)
                                except:
                                    line.sendText(msg.to,"[[NO MENTION]]")
                                cb = ""
                                cb2 = ""
                                strt = len(str(count)) + 2
                                akh = int(0)
                                cnt = 0
                            count += 1
                        cb = (cb[:int(len(cb)-1)])
                        cb2 = cb2[:-1]
                        msg.contentType = 0
                        msg.text = cb2
                        msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+cb+']}','EMTVER':'4'}
                        try:
                            line.sendMessage(msg)
                        except:
                            line.sendText(msg.to,"[[NO MENTION]]")
                    elif data[0] == "<":
                        mentargs = int(data[1:].strip())
                        group = line.getGroup(msg.to)
                        nama = [contact.mid for contact in group.members if contact.mid != user1]
                        cb = ""
                        cb2 = ""
                        count = 1
                        strt = len(str(count)) + 2
                        akh = int(0)
                        cnt = 0
                        for md in nama:
                            if count > mentargs:
                                break
                            akh = akh + len(str(count)) + 2 + 5
                            cb += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(md)+"},"""
                            strt = strt + len(str(count+1)) + 2 + 6
                            akh = akh + 1
                            cb2 += str(count)+". @name\n"
                            cnt = cnt + 1
                            if cnt == 50:
                                cb = (cb[:int(len(cb)-1)])
                                cb2 = cb2[:-1]
                                msg.contentType = 0
                                msg.text = cb2
                                msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+cb+']}','EMTVER':'4'}
                                try:
                                    line.sendMessage(msg)
                                except:
                                    line.sendText(msg.to,"[[NO MENTION]]")
                                cb = ""
                                cb2 = ""
                                strt = len(str(count)) + 2
                                akh = int(0)
                                cnt = 0
                            count += 1
                        cb = (cb[:int(len(cb)-1)])
                        cb2 = cb2[:-1]
                        msg.contentType = 0
                        msg.text = cb2
                        msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+cb+']}','EMTVER':'4'}
                        try:
                            line.sendMessage(msg)
                        except:
                            line.sendText(msg.to,"[[NO MENTION]]")
                    elif data[0] == ">":
                        mentargs = int(data[1:].strip())
                        group = line.getGroup(msg.to)
                        nama = [contact.mid for contact in group.members if contact.mid != user1]
                        cb = ""
                        cb2 = ""
                        count = 1
                        if mentargs >= 0:
                            strt = len(str(mentargs)) + 2
                        else:
                            strt = len(str(count)) + 2
                        akh = int(0)
                        cnt = 0
                        for md in nama:
                            if count < mentargs:
                                count += 1
                                continue
                            akh = akh + len(str(count)) + 2 + 5
                            cb += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(md)+"},"""
                            strt = strt + len(str(count+1)) + 2 + 6
                            akh = akh + 1
                            cb2 += str(count)+". @name\n"
                            cnt = cnt + 1
                            if cnt == 50:
                                cb = (cb[:int(len(cb)-1)])
                                cb2 = cb2[:-1]
                                msg.contentType = 0
                                msg.text = cb2
                                msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+cb+']}','EMTVER':'4'}
                                try:
                                    line.sendMessage(msg)
                                except:
                                    line.sendText(msg.to,"[[NO MENTION]]")
                                cb = ""
                                cb2 = ""
                                strt = len(str(count)) + 2
                                akh = int(0)
                                cnt = 0
                            count += 1
                        cb = (cb[:int(len(cb)-1)])
                        cb2 = cb2[:-1]
                        msg.contentType = 0
                        msg.text = cb2
                        msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+cb+']}','EMTVER':'4'}
                        try:
                            line.sendMessage(msg)
                        except:
                            line.sendText(msg.to,"[[NO MENTION]]")
                    elif data[0] == "=":
                        mentargs = int(data[1:].strip())
                        group = line.getGroup(msg.to)
                        nama = [contact.mid for contact in group.members if contact.mid != user1]
                        cb = ""
                        cb2 = ""
                        count = 1
                        akh = int(0)
                        cnt = 0
                        for md in nama:
                            if count != mentargs:
                                count += 1
                                continue
                            akh = akh + len(str(count)) + 2 + 5
                            strt = len(str(count)) + 2
                            cb += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(md)+"},"""
                            strt = strt + len(str(count+1)) + 2 + 6
                            akh = akh + 1
                            cb2 += str(count)+". @name\n"
                            cnt = cnt + 1
                            if cnt == 50:
                                cb = (cb[:int(len(cb)-1)])
                                cb2 = cb2[:-1]
                                msg.contentType = 0
                                msg.text = cb2
                                msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+cb+']}','EMTVER':'4'}
                                try:
                                    line.sendMessage(msg)
                                except:
                                    line.sendText(msg.to,"[[NO MENTION]]")
                                cb = ""
                                cb2 = ""
                                strt = len(str(count)) + 2
                                akh = int(0)
                                cnt = 0
                            count += 1
                        cb = (cb[:int(len(cb)-1)])
                        cb2 = cb2[:-1]
                        msg.contentType = 0
                        msg.text = cb2
                        msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+cb+']}','EMTVER':'4'}
                        try:
                            line.sendMessage(msg)
                        except:
                            line.sendText(msg.to,"[[NO MENTION]]")
                elif ".tx " in msg.text.lower():
                    spl = re.split(".tx ",msg.text,flags=re.IGNORECASE)
                    if spl[0] == "":
                        line.kedapkedip(msg.to,spl[1])

                elif msg.text in ["รายชื่อบลอค"]: 
                    blockedlist = line.getBlockedContactIds()
                    kontak = line.getContacts(blockedlist)
                    num=1
                    msgs="ชื่อคนที่ถูกบอทบล็อค"
                    for ids in kontak:
                        msgs+="\n[%i] %s" % (num, ids.displayName)
                        num=(num+1)
                    msgs+="\n✦ᵗ̶̶ᵉ̶̶ᵃ̶̶ᵐ̶̶̶̶ ᵇ̶̶ᵒ̶̶ᵗ̶ˢ̶̶ᵉ̶̶ˡ̶̶ᶠ̶̶ᵇ̶̶ᵒ̶̶ᵗ̶̶ ᵖ̶̶ʳ̶̶ᵒ̶̶ᵗ̶̶ᵉ̶̶ᶜ̶̶ᵗ̶✦\nรายชื่อมีดังนี้ : %i" % len(kontak)
                    line.sendMessage(receiver, msgs)
                elif text.lower() == '//แทก':
                            if msg.toType == 0:
                                sendMention(to, to, "", "")
                            elif msg.toType == 2:
                                group = line.getGroup(to)
                                contact = [mem.mid for mem in group.members]
                                ct1, ct2, ct3, ct4, ct5, jml = [], [], [], [], [], len(contact)
                                if jml <= 100:
                                    mentionMembers(to, contact)
                                elif jml > 100 and jml <= 200: 
                                    for a in range(0, 99):
                                        ct1 += [contact[a]]
                                    for b in range(100, jml):
                                        ct2 += [contact[b]]
                                    mentionMembers(to, ct1)
                                    mentionMembers(to, ct2)
                                elif jml > 200 and jml <= 300:
                                    for a in range(0, 99):
                                        ct1 += [contact[a]]
                                    for b in range(100, 199):
                                        ct2 += [contact[b]]
                                    for c in range(200, jml):
                                        ct3 += [contact[c]]
                                    mentionMembers(to, ct1)
                                    mentionMembers(to, ct2)
                                    mentionMembers(to, ct3)
                                elif jml > 300 and jml <= 400:
                                    for a in range(0, 99):
                                        ct1 += [contact[a]]
                                    for b in range(100, 199):
                                        ct2 += [contact[b]]
                                    for c in range(200, 299):
                                        ct3 += [contact[c]]
                                    for d in range(300, jml):
                                        ct4 += [contact[d]]
                                    mentionMembers(to, ct1)
                                    mentionMembers(to, ct2)
                                    mentionMembers(to, ct3)
                                    mentionMembers(to, ct4)
                                elif jml > 400 and jml <= 500:
                                    for a in range(0, 99):
                                        ct1 += [contact[a]]
                                    for b in range(100, 199):
                                        ct2 += [contact[b]]
                                    for c in range(200, 299):
                                        ct3 += [contact[c]]
                                    for d in range(300, 399):
                                        ct4 += [contact[d]]
                                    for e in range(400, jml):
                                        ct4 += [contact[e]]
                                    mentionMembers(to, ct1)
                                    mentionMembers(to, ct2)
                                    mentionMembers(to, ct3)
                                    mentionMembers(to, ct4)
                                    mentionMembers(to, ct5)
#===================================================================#

                elif text.lower() == 'แทค':
                    group = line.getGroup(msg.to)
                    nama = [contact.mid for contact in group.members]
                    k = len(nama)//20
                    for a in range(k+1):
                        txt = ''
                        s=0
                        b=[]
                        for i in group.members[a*20 : (a+1)*20]:
                            b.append({"S":str(s), "E" :str(s+6), "M":i.mid})
                            s += 7
                            txt += '@Alin \n'
                        line.sendMessage(to, text=txt, contentMetadata={'MENTION': json.dumps({'MENTIONEES':b})}, contentType=0)
                        line.sendMessage(to, "🕛ทั้งหมด {} คน🕛".format(str(len(nama))))  


#==============================================================================#

                elif "เพลง" in msg.text.lower():
                    sep = text.split(" ")
                    search = text.replace(sep[0] + " ","")
                    params = {"search_query": search}
                    with requests.session() as web:
                        web.headers["User-Agent"] = random.choice(settings["userAgent"])
                        r = web.get("https://www.youtube.com/results", params = params)
                        soup = BeautifulSoup(r.content, "html5lib")
                        datas = []
                        for data in soup.select(".yt-lockup-title > a[title]"):
                            if "&lists" not in data["href"]:
                                datas.append(data)
                        for data in datas:
                            ret_ = "https://www.youtube.com{}".format(str(data["href"]))
                        line.sendMessage(to, str(ret_))       
#==============================================================================#         
                elif text.lower() == 'แอดกลุ่ม' or text.lower() == "แอดมิน":
                    group = line.getGroup(to)                                    
                    GS = group.creator                  
                    name = GS.displayName
                    pp = GS.pictureStatus
                    data = {
                        "type": "flex",
                        "altText": "Flex NN",
                        "contents": {
                            "type": "bubble",                          
                            "body": {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                    {
                                        "type":"text",
                                        "text":"ผู้สร้างของกลุ่มนี้",
                                        "size":"md",
                                        "weight":"bold",
                                        "color":"#000000",
                                        "align":"center"
                                    },
                                    {
                                        "type":"text",
                                        "text": " "
                                    },
                                    {
                                        "type": "image",
                                        "url": "https://profile.line-scdn.net/" + str(pp),
                                        "size": "lg"
                                    },
                                    {
                                        "type":"text",
                                        "text":" "
                                    },
                                    {
                                        "type":"text",
                                        "text":"{}".format(name),
                                        "size":"md",
                                        "weight":"bold",
                                        "color":"#66FFFF",
                                        "align":"center"
                                   },
                               ]
                            }
                        }
                    }
                    sendTemplate(to, data)
                    line.sendContact(to, GS.mid)
                
                elif text.lower() == 'แอด':
                    group = line.getGroup(to)
                    GS = group.creator.mid
                    line.sendContact(to, GS)
                    nn2(to, "☝แอดมินกลุ่ม🖕")

                elif text.lower() == 'วันที่':
                    tz = pytz.timezone("Asia/Makassar")
                    timeNow = datetime.now(tz=tz)
                    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                    hari = ["วันอาทิตย์", "วันจันทร์", "วันอังคาร", "วันพุธ", "วันพฤหัสบดี", "วันศุกร์", "วันเสาร์"]
                    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                    hr = timeNow.strftime("%A")
                    bln = timeNow.strftime("%m")
                    for i in range(len(day)):
                        if hr == day[i]: hasil = hari[i]
                    for k in range(0, len(bulan)):
                        if bln == str(k): bln = bulan[k-1]
                    readTime = hasil + ", " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') + "\nเวลา  [ " + timeNow.strftime('%H:%M:%S') + " ]"
                    nn1(to, readTime)                 
                elif "screenshotwebsite" in msg.text.lower():
                    sep = text.split(" ")
                    query = text.replace(sep[0] + " ","")
                    with requests.session() as web:
                        r = web.get("http://rahandiapi.herokuapp.com/sswebAPI?key=betakey&link={}".format(urllib.parse.quote(query)))
                        data = r.text
                        data = json.loads(data)
                        line.sendImageWithURL(to, data["result"])
                elif "checkdate" in msg.text.lower():
                    sep = msg.text.split(" ")
                    tanggal = msg.text.replace(sep[0] + " ","")
                    r=requests.get('https://script.google.com/macros/exec?service=AKfycbw7gKzP-WYV2F5mc9RaR7yE3Ve1yN91Tjs91hp_jHSE02dSv9w&nama=ervan&tanggal='+tanggal)
                    data=r.text
                    data=json.loads(data)
                    ret_ = "╔══[ D A T E ]"
                    ret_ += "\n╠ Date Of Birth : {}".format(str(data["data"]["lahir"]))
                    ret_ += "\n╠ Age : {}".format(str(data["data"]["usia"]))
                    ret_ += "\n╠ Birthday : {}".format(str(data["data"]["ultah"]))
                    ret_ += "\n╠ Zodiak : {}".format(str(data["data"]["zodiak"]))
                    ret_ += "\n╚══[ Success ]"
                    line.sendMessage(to, str(ret_))
                
                elif "instagram" in msg.text.lower():
                    sep = text.split(" ")
                    search = text.replace(sep[0] + " ","")
                    with requests.session() as web:
                        web.headers["User-Agent"] = random.choice(settings["userAgent"])
                        r = web.get("https://www.instagram.com/{}/?__a=1".format(search))
                        try:
                            data = json.loads(r.text)
                            ret_ = "╔══[ Profile Instagram ]"
                            ret_ += "\n╠ Nama : {}".format(str(data["user"]["full_name"]))
                            ret_ += "\n╠ Username : {}".format(str(data["user"]["username"]))
                            ret_ += "\n╠ Bio : {}".format(str(data["user"]["biography"]))
                            ret_ += "\n╠ Pengikut : {}".format(format_number(data["user"]["followed_by"]["count"]))
                            ret_ += "\n╠ Diikuti : {}".format(format_number(data["user"]["follows"]["count"]))
                            if data["user"]["is_verified"] == True:
                                ret_ += "\n╠ Verifikasi : Sudah"
                            else:
                                ret_ += "\n╠ Verifikasi : Belum"
                            if data["user"]["is_private"] == True:
                                ret_ += "\n╠ Akun Pribadi : Iya"
                            else:
                                ret_ += "\n╠ Akun Pribadi : Tidak"
                            ret_ += "\n╠ จำนวน Post : {}".format(format_number(data["user"]["media"]["count"]))
                            ret_ += "\n╚══[ https://www.instagram.com/{} ]".format(search)
                            path = data["user"]["profile_pic_url_hd"]
                            line.sendImageWithURL(to, str(path))
                            line.sendMessage(to, str(ret_))
                        except:
                            line.sendMessage(to, "Pengguna tidak ditemukan")

                elif "fotoig" in msg.text.lower():
                    separate = msg.text.split(" ")
                    user = msg.text.replace(separate[0] + " ","")
                    profile = "https://www.instagram.com/" + user
                    with requests.session() as x:
                        x.headers['user-agent'] = 'Mozilla/5.0'
                        end_cursor = ''
                        for count in range(1):
                            print(('send foto : ', count))
                            r = x.get(profile, params={'max_id': end_cursor})                        
                            data = re.search(r'window._sharedData = (\{.+?});</script>', r.text).group(1)
                            j    = json.loads(data)                        
                            for node in j['entry_data']['ProfilePage'][0]['user']['media']['nodes']: 
                                page = 'https://www.instagram.com/p/' + node['code']
                                r = x.get(page)
                                print((node['display_src']))
                                line.sendImageWithURL(msg.to,node['display_src'])
                elif "ภาพ" in msg.text.lower():
                    separate = msg.text.split(" ")
                    search = msg.text.replace(separate[0] + " ","")
                    with requests.session() as web:
                        web.headers["User-Agent"] = random.choice(settings["userAgent"])
                        r = web.get("http://rahandiapi.herokuapp.com/imageapi?key=betakey&q={}".format(urllib.parse.quote(search)))
                        data = r.text
                        data = json.loads(data)
                        if data["result"] != []:
                            items = data["result"]
                            path = random.choice(items)
                            a = items.index(path)
                            b = len(items)
                            line.sendImageWithURL(to, str(path))
                elif "anime" in msg.text.lower():
                    separate = msg.text.split(" ")
                    search = msg.text.replace(separate[0] + " ","")
                    with requests.session() as web:
                        web.headers["User-Agent"] = random.choice(settings["userAgent"])
                        r = web.get("http://rahandiapi.herokuapp.com/imageapi?key=betakey&q={}".format(urllib.parse.quote(search)))
                        data = r.text
                        data = json.loads(data)
                        if data["result"] != []:
                            items = data["result"]
                            path = random.choice(items)
                            a = items.index(path)
                            b = len(items)
                            line.sendImageWithURL(to, str(path))
                
                #=======================================
                
                elif msg.text in ["เปิดแอบ"]:
                    try:
                        del RfuCctv['point'][msg.to]
                        del RfuCctv['sidermem'][msg.to]
                        del RfuCctv['cyduk'][msg.to]
                    except:
                        pass
                    RfuCctv['point'][msg.to] = msg.id
                    RfuCctv['sidermem'][msg.to] = ""
                    RfuCctv['cyduk'][msg.to]=True
                    nn2(to,"🐷   หวัดดีคนแอบบ   🐷")
                    line.sendMessage(to, None, contentMetadata={"STKID":"52002773","STKPKGID":"11537","STKVER":"1"}, contentType=7)

                elif msg.text in ["ปิดแอบ"]:
                    if msg.to in RfuCctv['point']:
                        RfuCctv['cyduk'][msg.to]=False
                        kittyText(to, RfuCctv['sidermem'][msg.to])
                    else:
                        nn2(to, "ปิดแล้วปิดอ่านออโต้ ให้แระนะจร้")
                        line.sendMessage(to, None, contentMetadata={"STKID":"52002740","STKPKGID":"11537","STKVER":"1"}, contentType=7)

                #==========================================#
                elif text.lower() == 'ลิ้ง':
                    if msg.toType == 2:
                        group = line.getGroup(to)
                        if group.preventedJoinByTicket == False:
                            ticket = line.reissueGroupTicket(to)
                            line.sendMessage(to, "ลิ้งของกลุ่ม\nhttps://line.me/R/ti/g/{}".format(str(ticket)))
                elif text.lower() == 'เปิดลิ้ง':
                    if msg.toType == 2:
                        group = line.getGroup(to)
                        if group.preventedJoinByTicket == False:
                            nn2(to, "เปิดลิ้งเรียบร้อย")
                        else:
                            group.preventedJoinByTicket = False
                            line.updateGroup(group)
                            nn2(to, "เปิดลิ้งเรียบร้อย")
                elif text.lower() == 'ปิดลิ้ง':
                    if msg.toType == 2:
                        group = line.getGroup(to)
                        if group.preventedJoinByTicket == True:
                            nn2(to, "ปิดลิ้งเรียบร้อย")
                        else:
                            group.preventedJoinByTicket = True
                            line.updateGroup(group)
                            nn2(to, "ปิดลิ้งเรียบร้อย")               
#================================================================#
                if msg.text in ["18+","หนัง","คลิป"]:                    
                    nn2(to, "มีคนดูหนังโป๊")
                    line.sendMessage(to, "╔══════════════\n╠❂͜͡☆➣ nekopoi.host\n╠❂͜͡☆➣ sexvideobokep.com\n╠❂͜͡☆➣ memek.com\n╠❂͜͡☆➣ pornktube.com\n╠❂͜͡☆➣ faketaxi.com\n╠❂͜͡☆➣ videojorok.com\n╠❂͜͡☆➣ watchmygf.mobi\n╠❂͜͡☆➣ xnxx.com\n╠❂͜͡☆➣ pornhd.com\n╠❂͜͡☆➣ xvideos.com\n╠❂͜͡☆➣ vidz7.com\n╠❂͜͡☆➣ m.xhamster.com\n╠❂͜͡☆➣ xxmovies.pro\n╠❂͜͡☆➣ youporn.com\n╠❂͜͡☆➣ pornhub.com\n╠❂͜͡☆➣ youjizz.com\n╠❂͜͡☆➣ thumzilla.com\n╠❂͜͡☆➣ anyporn.com\n╠❂͜͡☆➣ brazzers.com\n╠❂͜͡☆➣ redtube.com\n╠❂͜͡☆➣ youporn.com\n╚══════════════")    
#================================================================#               
#-------------------------------------------------------------------------------
        if op.type == 25:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0:
                if sender != line.profile.mid:
                    to = sender
                else:
                    to = receiver
            else:
                to = receiver
            if msg.contentType == 0:
                if text is None:
                    return
#==============================================================================#

                elif msg.text in ["/uninstall"]:
                    if msg.toType == 2:
                        ginfo = line.getGroup(receiver)
                        try:
                            line.leaveGroup(receiver)							
                        except:
                            pass
                
                elif msg.text.lower().startswith("google "):
                    sep = msg.text.split(" ")
                    textnya = msg.text.replace(sep[0] + " ","")
                    urlnya = "http://chart.apis.google.com/chart?chs=480x80&cht=p3&chtt=" + textnya + "&chts=FFFFFF,70&chf=bg,s,000000"
                    line.sendImageWithURL(msg.to, urlnya)

                elif "kedip " in msg.text:
                    txt = msg.text.replace("kedip ", "")
                    t1 = "\xf4\x80\xb0\x82\xf4\x80\xb0\x82\xf4\x80\xb0\x82\xf4\x80\xb0\x82\xf4\x80\xa0\x81\xf4\x80\xa0\x81\xf4\x80\xa0\x81"
                    t2 = "\xf4\x80\x82\xb3\xf4\x8f\xbf\xbf"
                    line.sendMessage(msg.to, t1 + txt + t2)						
                elif msg.text in ["Inviteuser"]:
                        settings["winvite"] = True
                        line.sendMessage(msg.to,"send a contact to invite user")                            
                elif msg.text.lower() == "โทร":
                    if msg.toType == 2:
                        group = line.getGroup(msg.to)
                        gMembMids = [contact.mid for contact in group.invitee]
                        for i in gMembMids:
                            line.cancelGroupInvitation(msg.to,[i])
                elif msg.text.lower() == ".invitecancel2":
                    if msg.toType == 2:
                        group = line.getGroup(msg.to)
                        gMembMids = [contact.mid for contact in group.invitee]
                        for i in gMembMids:
                            random.choice(Exc).cancelGroupInvitation(msg.to,[i])
#=============COMMAND KICKER===========================#
                elif msg.text in ["cb"]:
                    settings["blacklist"] = {}
                    line.sendMessage(msg.to,"ทำการลบัญชีดำทั้งหมดเรียร้อย")
                    print ("Clear Ban")

                elif 'ปลิว' in text.lower():
                       targets = []
                       key = eval(msg.contentMetadata["MENTION"])
                       key["MENTIONEES"] [0] ["M"]
                       for x in key["MENTIONEES"]:
                           targets.append(x["M"])
                       for target in targets:
                           try:
                               random.choice(Rfu).kickoutFromGroup(msg.to,[target])      
                               print ("Rfu kick User")
                           except:
                               random.choice(Rfu).sendMessage(msg.to,"Limit kaka 😫")

                elif 'kill' in text.lower():
                       targets = []
                       key = eval(msg.contentMetadata["MENTION"])
                       key["MENTIONEES"] [0] ["M"]
                       for x in key["MENTIONEES"]:
                           targets.append(x["M"])
                       for target in targets:
                           try:
                               line.kickoutFromGroup(msg.to,[target])             
                               print ("Sb Kick User")
                           except:
                               line.sendMessage(msg.to,"Limit kaka 😫")                               

                elif 'invite' in text.lower():
                       targets = []
                       key = eval(msg.contentMetadata["MENTION"])
                       key["MENTIONEES"] [0] ["M"]
                       for x in key["MENTIONEES"]:
                           targets.append(x["M"])
                       for target in targets:
                           try:
                               line.inviteIntoGroup(msg.to,[target])
                               line.sendMessage(receiver, "Type👉 Invite Succes")
                           except:
                               line.sendMessage(msg.to,"Type👉 Limit Invite")
                elif "/ล้างห้อง" in msg.text:
                	if msg.toType == 2:
                         _name = msg.text.replace("/ล้างห้อง","")
                         gs = line.getGroup(receiver)
                         line.sendMessage(receiver,"Just some casual cleansing ô")
                         targets = []
                         for g in gs.members:
                             if _name in g.displayName:
                                 targets.append(g.mid)
                         if targets == []:
                             line.sendMessage(receiver,"Not found.")
                         else:
                             for target in targets:
                             	if not target in Rfu:
                                     try:
                                         klist=[line]
                                         kicker=random.choice(klist)
                                         line.kickoutFromGroup(receiver,[target])
                                         print((receiver,[g.mid]))
                                     except:
                                         line.sendMessage(receiver,"Group cleanse")
                                         print ("Cleanse Group")

                elif text.lower() == 'เชคดำ':
                    if msg._from in admid:
                        if settings["blacklist"] == {}:
                            line.sendMessage(to,"ไม่พบผู้ติดดำ")
                        else:
                            line.sendMessage(to,"โปรดรอ...")
                            num=1
                            msgs="══════════รายชื่อผู้ติดดำ═════════"
                            for mi_d in settings["blacklist"]:
                                msgs+="\n[%i] %s" % (num, line.getContact(mi_d).displayName)
                                num=(num+1)
                            msgs+="\n══════════รายชื่อผู้ติดดำ═════════\n\nจำนวน รายชื่อผู้ติดดำ :  %i" % len(settings["blacklist"])
                            line.sendMessage(to, msgs)
#=======================================================================================
                elif "/ล้างห้อง" in msg.text:
                	if msg.toType == 2:
                         _name = msg.text.replace("/ล้างห้อง","")
                         gs = line.getGroup(receiver)
                         line.sendMessage(receiver,"☠FUCK FUCK☠")
                         targets = []
                         for g in gs.members:
                             if _name in g.displayName:
                                 targets.append(g.mid)
                         if targets == []:
                             line.sendMessage(receiver,"Not found.")
                         else:
                             for target in targets:
                             	if not target in Rfu:
                                     try:
                                         klist=[line]
                                         kicker=random.choice(klist)
                                         kicker.kickoutFromGroup(receiver,[target])
                                         print((receiver,[g.mid]))
                                     except:
                                         line.sendMessage(receiver,"☠FUCK FUCK☠")
                                         print ("Cleanse Group")            

#-------------------------------------------------------------------------------
        if op.type == 25:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0:
                if sender != line.profile.mid:
                    to = sender
                else:
                    to = receiver
            else:
                to = receiver
            if msg.contentType == 0:
                if text is None:
                    return
#=============COMMAND PROTECT=========================#
                


#==============FINNISHING PROTECT========================#

                elif text.lower() == '/ลบรัน':
                    gid = line.getGroupIdsInvited()
                    start = time.time()
                    for i in gid:
                        line.rejectGroupInvitation(i)
                    elapsed_time = time.time() - start
                    line.sendMessage(to, "ลบรันเสร็จแล้วขอรับ")
                    line.sendMessage(to, "ระยะเวลาที่ใช้: %sวินาที" % (elapsed_time))

							
								
                elif "ดำยกห้อง" in msg.text:
                  if msg._from in Family:
                      if msg.toType == 2:
                           print ("All Banlist")
                           _name = msg.text.replace("ดำยกห้อง","")
                           gs = line.getGroup(msg.to)
                           line.sendMessage(msg.to,"เพิ่มลงบัญชีดำทุกคนเรียบร้อย")
                           targets = []
                           for g in gs.members:
                               if _name in g.displayName:
                                    targets.append(g.mid)
                           if targets == []:
                                line.sendMessage(msg.to,"ไม่สามารถเพิ่มลงบัญชีดำได้")
                           else:
                               for target in targets:
                                   if not target in Family:
                                       try:
                                           settings["blacklist"][target] = True
                                           f=codecs.open('st2__b.json','w','utf-8')
                                           json.dump(settings["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                                       except:
                                           line.sentMessage(msg.to,"All members has been added ban.")
										   
                elif 'ดำ' in text.lower():
                       targets = []
                       key = eval(msg.contentMetadata["MENTION"])
                       key["MENTIONEES"] [0] ["M"]
                       for x in key["MENTIONEES"]:
                           targets.append(x["M"])
                       for target in targets:
                           try:
                               settings["blacklist"][target] = True
                               f=codecs.open('st2__b.json','w','utf-8')
                               json.dump(settings["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                               line.sendMessage(msg.to,"เพิ่มลงบัญชีดำเรียบร้อย ")
                               print ("Banned User")
                           except:
                               line.sendMessage(msg.to,"ไม่พบผู้ติดต่อ")

                elif 'ขาว' in text.lower():
                       targets = []
                       key = eval(msg.contentMetadata["MENTION"])
                       key["MENTIONEES"] [0] ["M"]
                       for x in key["MENTIONEES"]:
                           targets.append(x["M"])
                       for target in targets:
                           try:
                               del settings["blacklist"][target]
                               f=codecs.open('st2__b.json','w','utf-8')
                               json.dump(settings["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                               line.sendMessage(msg.to,"แก้ดำเรียบร้อย. ")
                               print ("Unbanned User")
                           except:
                               line.sendMessage(msg.to,"ไม่พบผู้ติดต่อ")
#-------------------------------------------------------------------------------#
                elif msg.text in ["ดูดำ"]:
                  if msg._from in Family:
                    if settings["blacklist"] == {}:
                        line.sendMessage(msg.to,"ไม่พบ") 
                    else:
                        line.sendMessage(msg.to,"รายชื่อผู้ติดดำ")
                        mc = "Blacklist User\n"
                        for mi_d in settings["blacklist"]:
                            mc += "[√] " + line.getContact(mi_d).displayName + " \n"
                            line.sendMessage(msg.to, msgs)
                elif msg.text.lower().startswith("urban "):
                    sep = msg.text.split(" ")
                    judul = msg.text.replace(sep[0] + " ","")
                    url = "http://api.urbandictionary.com/v0/define?term="+str(judul)
                    with requests.session() as s:
                        s.headers["User-Agent"] = random.choice(settings["userAgent"])
                        r = s.get(url)
                        data = r.text
                        data = json.loads(data)
                        y = "[ Result Urban ]"
                        y += "\nTags: "+ data["tags"][0]
                        y += ","+ data["tags"][1]
                        y += ","+ data["tags"][2]
                        y += ","+ data["tags"][3]
                        y += ","+ data["tags"][4]
                        y += ","+ data["tags"][5]
                        y += ","+ data["tags"][6]
                        y += ","+ data["tags"][7]
                        y += "\n[1]\nAuthor: "+str(data["list"][0]["author"])
                        y += "\nWord: "+str(data["list"][0]["word"])
                        y += "\nLink: "+str(data["list"][0]["permalink"])
                        y += "\nDefinition: "+str(data["list"][0]["definition"])
                        y += "\nExample: "+str(data["list"][0]["example"])
                        line.sendMessage(to, str(y))
           
            elif msg.contentType == 1:
                    if settings["changePictureProfile"] == True:
                        path = line.downloadObjectMsg(msg_id)
                        settings["changePictureProfile"] = False                                                                               
                        line.updateProfilePicture(path)                                                                                        
                        line.sendMessage(to, "เปลี่ยนโปรไฟล์สำเร็จแล้ว")

#                        
            elif msg.contentType == 7:
                if setmybot["checkSticker"] == True:
                    stk_id = msg.contentMetadata['STKID']
                    stk_ver = msg.contentMetadata['STKVER']
                    pkg_id = msg.contentMetadata['STKPKGID']
                    ret_ = " 🔷 ระบบเช็คสติ๊กเกอร์เราคับ 🔷\n✧••••••••••❂✧✯✧❂••••••••••✧"
                    ret_ += "\n??STK IĐ ::: {}".format(stk_id)
                    ret_ += "\n🌟PKG IĐ ::: {}".format(pkg_id)
                    ret_ += "\n🌟STK Vër ::: {}".format(stk_ver)
                    ret_ += "\n✧••••••••••❂✧✯✧❂••••••••••✧\n  line://shop/detail/{}".format(pkg_id)
                    line.sendMessage(to, str(ret_))            
                
        if op.type in [25,26]:
            msg = op.message
            sender = msg._from
            if msg.contentType == 16:
                    try:
                        if settings["chivareeLike"]==True:
                            url_post = msg.contentMetadata['postEndUrl']
                            pliter = url_post.replace('line://home/post?userMid=','')
                            pliter = pliter.split('&postId=')
                            line.likePost(mid=pliter[0],postId=pliter[1])
                            line.createComment(mid=pliter[0],postId=pliter[1],text=settings["comment"])
                            nn2(to,"🌟•❣️ ไม่ไลค์คับเจ็บมือ ❣️•🌟")
                    except Exception as e:
                        line.sendMessage(to, str(e))                    
            elif msg.contentType == 16:
                if settings["timeline"] == True:
                    msg.contentType = 0
                    msg.text = "ลิ้งโพส\n" + msg.contentMetadata["postEndUrl"]
                    line.sendMessage(msg.to,msg.text)              
#==============================================================================#
        if op.type == 19:
            if lineMID in op.param3:
                settings["blacklist"][op.param2] = True
        if op.type == 22:
            if settings['leaveRoom'] == True:
                line.leaveRoom(op.param1)              
        if op.type == 24:
            if settings['leaveRoom'] == True:
                line.leaveRoom(op.param1)             
#==============================================================================#
#==============================================================================#
        if op.type == 17:
            if op.param2 not in Family:
                if op.param2 in Family:
                    pass
            if RfuProtect["protect"] == True:
                if settings["blacklist"][op.param2] == True:
                    try:
                        line.kickoutFromGroup(op.param1,[op.param2])
                        G = line.getGroup(op.param1)
                        G.preventedJoinByTicket = True
                        line.updateGroup(G)
                    except:
                        try:
                            line.kickoutFromGroup(op.param1,[op.param2])
                            G = line.getGroup(op.param1)
                            G.preventedJoinByTicket = True
                            line.updateGroup(G)
                        except:
                            pass
        if op.type == 19:
            if op.param2 not in Family:
                if op.param2 in Family:
                    pass
                elif RfuProtect["protect"] == True:
                    settings ["blacklist"][op.param2] = True
                    random.choice(Rfu).kickoutFromGroup(op.param1,[op.param2])
                    random.choice(Rfu).inviteIntoGroup(op.param1,[op.param2])

        if op.type == 13:
            if op.param2 not in Family:
                if op.param2 in Family:
                    pass
                elif RfuProtect["inviteprotect"] == True:
                    settings ["blacklist"][op.param2] = True
                    random.choice(Rfu).cancelGroupInvitation(op.param1,[op.param3])
                    random.choice(Rfu).kickoutFromGroup(op.param1,[op.param2])
                    if op.param2 not in Family:
                        if op.param2 in Family:
                            pass
                        elif RfuProtect["inviteprotect"] == True:
                            settings ["blacklist"][op.param2] = True
                            random.choice(Rfu).cancelGroupInvitation(op.param1,[op.param3])
                            random.choice(Rfu).kickoutFromGroup(op.param1,[op.param2])
                            if op.param2 not in Family:
                                if op.param2 in Family:
                                    pass
                                elif RfuProtect["cancelprotect"] == True:
                                    settings ["blacklist"][op.param2] = True
                                    random.choice(Rfu).cancelGroupInvitation(op.param1,[op.param3])

        if op.type == 11:
            if op.param2 not in Family:
                if op.param2 in Family:
                    pass
                elif RfuProtect["linkprotect"] == True:
                    settings ["blacklist"][op.param2] = True
                    G = line.getGroup(op.param1)
                    G.preventedJoinByTicket = True
                    line.updateGroup(G)
                    random.choice(Rfu).kickoutFromGroup(op.param1,[op.param2])
        if op.type == 5:
            if RfuProtect["autoAdd"] == True:
                if (settings["message"] in [""," ","\n",None]):
                    pass
                else:
                    line.sendMessage(op.param1,str(settings["message"]))                    

        if op.type == 11:
            if RfuProtect["linkprotect"] == True:
                if op.param2 not in Family:
                    G = line.getGroup(op.param1)
                    G.preventedJoinByTicket = True
                    random.choice(Rfu).updateGroup(G)
                    random.choice(Rfu).kickoutFromGroup(op.param1,[op.param3])                    

        if op.type == 13:
           if RfuProtect["Protectguest"] == True:
               if op.param2 not in Family:
                  random.choice(Rfu).cancelGroupInvitation(op.param1,[op.param3])
                  random.choice(Rfu).kickoutFromGroup(op.param1,[op.param2])

        if op.type == 17:
           if RfuProtect["Protectjoin"] == True:
               if op.param2 not in Family:
                   random.choice(Rfu).kickoutFromGroup(op.param1,[op.param2])

        if op.type == 1:
            if sender in Setmain["foto"]:
                path = line.downloadObjectMsg(msg_id)
                del Setmain["foto"][sender]
                line.updateProfilePicture(path)
                line.sendMessage(to,"Foto berhasil dirubah")

        if op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0:
                if sender != line.profile.mid:
                    to = sender
                else:
                    to = receiver
            else:
                to = receiver
                if setmybot["autoRead"] == True:
                    line.sendChatChecked(to, msg_id)				
                if to in read["readPoint"]:
                    if sender not in read["ROM"][to]:
                        read["ROM"][to][sender] = True
                if sender in settings["mimic"]["target"] and settings["mimic"]["status"] == True and settings["mimic"]["target"][sender] == True:
                    text = msg.text
                    if text is not None:
                        line.sendMessage(msg.to,text)                                
                if msg.contentType == 0 and sender not in lineMID and msg.toType == 2:
                    if "MENTION" in msg.contentMetadata.keys() != None:
        	             if setmybot['kickMention'] == True:
        		             contact = line.getContact(msg._from)
        		             cName = contact.displayName
        		             balas = ["เนื่องจากตอนนี้ผมเปิดระบบเตะคนแทคไว้ " + "\n👉" + cName + "\n🙏ต้องขออภัยด้วยจริงๆ🙏Bye!!!"]
        		             ret_ = "" + random.choice(balas)                     
        		             name = re.findall(r'@(\w+)', msg.text)
        		             mention = ast.literal_eval(msg.contentMetadata["MENTION"])
        		             mentionees = mention["MENTIONEES"]
        		             for mention in mentionees:
        			               if mention['M'] in admin:
        				                  line.sendText(msg.to,ret_)
        				                  random.choice(Rfu).kickoutFromGroup(msg.to,[msg._from])
        				                  break                                  
        			               if mention['M'] in lineMID:
        				                  line.sendText(msg.to,ret_)
        				                  random.choice(Rfu).kickoutFromGroup(msg.to,[msg._from])
        				                  break
                if "MENTION" in list(msg.contentMetadata.keys())!= None:
                         if setmybot['potoMention'] == True:
                             contact = line.getContact(msg._from)
                             cName = contact.pictureStatus
                             mi_d = contact.mid
                             balas = ["http://dl.profile.line-cdn.net/" + cName]
                             ret_ = random.choice(balas)
                             mention = ast.literal_eval(msg.contentMetadata["MENTION"])
                             mentionees = mention["MENTIONEES"]
                             for mention in mentionees:
                                          chivaree3={"type":"template","altText":"🌟🌟 Chivaree Sticker 🌟🌟","template":{"type":"image_carousel","columns":[{"imageUrl":"https://sv1.picz.in.th/images/2019/01/13/9XN3Gz.gif","size":"xxxl","aspectRatio":"1:2","action":{"type":"uri","uri":"line://app/1602687308-GXq4Vvk9?type=text&text=🌟🌟•คาราวะพี่แบงค์•🌟🌟",}}]}}
                                          sendTemplate(to, chivaree3)
                                          break  
                if msg.contentType == 0 and sender not in lineMID and msg.toType == 2:
                    if "MENTION" in list(msg.contentMetadata.keys()) != None:
                         if setmybot['detectMention'] == True:
                             LINKFOTO = "https://os.line.naver.jp/os/p/" + lineMID
                             LINKVIDEO = "https://os.line.naver.jp/os/p/" + lineMID + "/vp"
                             contact = line.getContact(msg._from)
                             cName = contact.displayName
                             chivareeZ = "🐷🐷• พีรี้ไม่ว่างตอบคับ •🐷🐷"
                             chivareeV = "ขัดสนิมปืนอยู่ไว้ยิงพวกชอบแทค"                            
                             name = re.findall(r'@(\w+)', msg.text)
                             mention = ast.literal_eval(msg.contentMetadata["MENTION"])
                             mentionees = mention['MENTIONEES']
                             for mention in mentionees:
                                   if mention['M'] in lineMID:
                                          #line.sendMessage(to,ret_)
                                          #line.sendMessage(to,str(settings["Respontag"]))
                                          #
                                          data = {
                                "type": "flex",
                                "altText": "{} Auto Tag".format(line.getProfile().displayName),
                                "contents": {
                                    "type": "bubble",
                                        "styles": {
                                        "header": {"backgroundColor": "#66FFFF"},
                                        "body": {"backgroundColor": "#66FFFF"},
                                        "footer": {"backgroundColor": "#66FFFF", "separator": True, "separatorColor": "#000000"}
                                    },
                                    "header": {
                                        "type": "box",
                                        "layout": "horizontal",
                                        "contents": [
                                            {
                                                "type": "text",
                                                "text": "{}".format(contact.displayName),
                                                "align": "center",
                                                "weight": "bold",
                                                "color": "#000000",
                                                "size": "md"
                                            }
                                        ]
                                    },
                                    "hero": {
                                        "type": "image",
                                        "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                                        "size": "full",
                                        "aspectRatio": "1:1",
                                        "aspectMode": "fit",
                                        "action": {
                                            "type": "uri",
                                            "uri": "line://nv/profilePopup/mid=u1a6b43ba490e0f886706ae74984351ec"
                                        }
                                    },
                                    "body": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "box",
                                                "layout": "vertical",
                                                "margin": "lg",
                                                "spacing": "sm",
                                                "contents": [
                                                    {
                                                        "type": "box",
                                                        "layout": "baseline",
                                                        "spacing": "sm",
                                                        "contents": [
                                                            {
                                                                "type": "text",
                                                                "text": "{}".format(chivareeZ),
                                                                "align": "center",
                                                                "color": "#000000",
                                                                "weight": "bold",
                                                                "size": "md",
                                                                "flex": 1
                                                            }
                                                        ]
                                                    },
                                                            {
                                                                "type": "separator"
                                                       }
                                                  ]
                                             }
                                        ]
                                    },
                                    "footer": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [
                                            {
                                                 "type": "text",
                                                                "text": "{}".format(chivareeV),
                                                                "align": "center",
                                                                "color": "#000000",
                                                                "size": "md"                                     
                                            },
                                            {
                                                "type": "spacer",
                                                "size": "sm",
                                            }
                                        ],
                                        "flex": 0
                                    }
                                }
                            }
                                          sendTemplate(to, data)                                     
                                          break

                if text.lower() == 'nmx ':
                  if msg._from in admin:   
                    spl = re.split("nmx ",msg.text,flags=re.IGNORECASE)
                    if spl[0] == "":
                        prof = nadya.getProfile()
                        prof.displayName = line.nmxstring(spl[1])
                        line.updateProfile(prof)
                        line.sendText(msg.to,"สำเร็จแล้ว")
                if text.lower() == 'มุด ':
                  if msg._from in admin:  
                    spl = re.split("มุด ",msg.text,flags=re.IGNORECASE)
                    if spl[0] == "":
                        try:
                            gid = spl[1].split(" ")[0]
                            ticket = spl[1].split(" ")[1].replace("line://ti/g/","") if "line://ti/g/" in spl[1].split(" ")[1] else spl[1].split(" ")[1].replace("http://line.me/R/ti/g/","") if "http://line.me/R/ti/g/" in spl[1].split(" ")[1] else spl[1].split(" ")[1]
                            line.acceptGroupInvitationByTicket(gid,ticket)
                        except Exception as e:
                            line.sendText(msg.to,str(e))                        

                if msg.contentType == 0:
                    if text is None:
                        return
                    if "/ti/g/" in msg.text.lower():
                        if settings["autoJoinTicket"] == True:
                            link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                            links = link_re.findall(text)
                            n_links = []
                            for l in links:
                                if l not in n_links:
                                    n_links.append(l)
                            for ticket_id in n_links:
                                group = line.findGroupByTicket(ticket_id)
                                line.acceptGroupInvitationByTicket(group.id,ticket_id)
                                line.sendMessage(to, "มุดลิ้งเข้าไปในกลุ่ม👉 %s 👈 เรียบร้อยแล้ว" % str(group.name)) 

        
                if msg.text in dangerMessage:
                    random.choice(Rfu).kickoutFromGroup(receiver,[sender])
                    random.choice(Rfu).sendText(msg.to,"ตรวจพบคำสั่งของบอทลบกลุ่ม จำเป็นต้องนำออกเพื่อความปลอดภัยของสมาชิก (｀・ω・´)")

        if op.type == 65:
            print ("[ 65 ] NOTIFIED DESTROY MESSAGE")
            if settings["unsendMessage"] == True:
                try:
                    at = op.param1
                    msg_id = op.param2
                    if msg_id in msg_dict:
                        if msg_dict[msg_id]["from"]:
                            ginfo = line.getGroup(at)
                            contact = line.getContact(msg_dict[msg_id]["from"])
                            if contact.displayNameOverridden != None:
                                name_ = contact.displayNameOverridden
                            else:
                                name_ = contact.displayName
                                ret_ = "\nคุณได้ทำการยกเลิกข้อความ"
                                ret_ += "\nชื่อ : {}".format(str(contact.displayName))
                                ret_ += "\nชื่อกลุ่ม : {}".format(str(ginfo.name))
                                ret_ += "\nเวลา : {}".format(str(dt_to_str(cTime_to_datetime(msg_dict[msg_id]["createdTime"]))))
                                ret_ += "\n\nประเภท 􀄃􀉘ขวา􏿿 {}".format(str(Type._VALUES_TO_NAMES[msg_dict[msg_id]["contentType"]]))
                                ret_ += "\nข้อความที่สมาชิกยกเลิก \n\n {}".format(str(msg_dict[msg_id]["text"]))
                                sendMention(at, str(ret_), [contact.mid])
                            del msg_dict[msg_id]
                        else:
                            line.sendMessage(at,"sᴇɴᴛᴍᴇssᴀɢᴇ ᴄᴀɴᴄᴇʟʟᴇᴅ, ʙᴜᴛ ɪ ᴅɪᴅɴ'ᴛ ʜᴀᴠᴇ ʟᴏɢ ᴅᴀᴛᴀ.\nsᴏʀʀʏ > <")
                except Exception as error:
                    logError(error)
        #===================================================================================#            
        if op.type == 65:
            print ("[ 65 ] NOTIFIED DESTROY MESSAGE")
            if settings["unsendMessage"] == True:
                try:
                    at = op.param1
                    msg_id = op.param2
                    if msg_id in msg_dict1:
                        if msg_dict1[msg_id]["from"]:
                            ginfo = line.getGroup(at)
                            ariftj = line.getContact(msg_dict1[msg_id]["from"])
                            if contact.displayNameOverridden != None:
                                name_ = contact.displayNameOverridden
                            else:
                                name_ = contact.displayName
                                ret_ =  "「 Sticker Dihapus 」\n"
                                ret_ += "• Pengirim : {}".format(str(ariftj.displayName))
                                ret_ += "\n• Nama Grup : {}".format(str(ginfo.name))
                                ret_ += "\n• Waktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict1[msg_id]["createdTime"])))
                                ret_ += "{}".format(str(msg_dict1[msg_id]["text"]))
                                sendMention(at, str(ret_), [contact.mid])
                            del msg_dict[msg_id]
                        else:
                            line.sendMessage(at,"sᴇɴᴛᴍᴇssᴀɢᴇ ᴄᴀɴᴄᴇʟʟᴇᴅ, ʙᴜᴛ ɪ ᴅɪᴅɴ'ᴛ ʜᴀᴠᴇ ʟᴏɢ ᴅᴀᴛᴀ.\nsᴏʀʀʏ > <")
                except Exception as error:
                    logError(error)            
#ต้อนรับ
        if op.type == 17:
           if setmybot["Wc"] == True:
             if op.param2 in lineMID:
                 return
             gname = line.getGroup(op.param1).name
             contact = line.getContact(op.param2)
             name = contact.displayName
             profile = contact.pictureStatus
             status = contact.statusMessage
             cover = line.getProfileCoverURL(contact.mid)
             data1 = {
        'type': 'flex',
        'altText': 'Welcome',
        'contents': {
            "type": "bubble",
            "styles": {
                "body": {
                    "backgroundColor": "#000000"
                }
            },
            "body": {
                "type": "box",
                "layout": "vertical",
                "contents": [
                    {
                        "type": "text",
                        "text": "〖 Group Welcome 〗\n\n• ชื่อกลุ่ม : {}\n• ชื่อคนเข้ากลุ่ม : {}\n\nยินดีต้อนรับเข้ากลุ่มนะคับ 😃\n™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣".format(str(gname),
                        str(name)),
                        "wrap": True,
                        "color": "#66FFFF",
                        "align": "center",
                        "gravity": "center",
                        "size": "md"
                    }
                ]
            }
        }
    }
             data2 = {
        'type': 'flex',
        'altText': 'Welcome',
        'contents': {
            "type": "bubble",
            "hero": {
                "type": "image",
                "url": "https://profile.line-scdn.net/{}".format(str(profile)),
                "size": "full",
                "action": {
                    "type": "uri",
                    "uri": "line://nv/camera"
                }
            }
        }
    }
             sendTemplate(op.param1,data1)
             sendTemplate(op.param1,data2)

        if op.type == 19:
           if setmybot["Nk"] == True:
             if op.param2 in lineMID:
                 return
             dan = line.getContact(op.param2)
             tgb = line.getGroup(op.param1)
             line.sendMessage(op.param1,str(setmybot["kick"]) + "\n    -Auto Kick:- 🕒 " +datetime.today().strftime('%H:%M:%S')+ "™\n✧••••••••••❂✧✯✧❂•••••••••••✧\n  🌟เป็นฟรีคิกที่งดงามมากคับ🌟\n •➤ {}".format(str(dan.displayName)))
        #     line.sendContact(op.param1, op.param2)
         #    line.sendMessage(op.param1,"สเตตัส\n{}".format(str(dan.statusMessage)))
             line.sendImageWithURL(op.param1, "http://dl.profile.line-cdn.net{}".format(dan.picturePath))
        if op.type == 15:
           if setmybot["Lv"] == True:
             if op.param2 in lineMID:
                 return
             dan = line.getContact(op.param2)
             tgb = line.getGroup(op.param1)
             chivaree6 = ['••••••••❂•💔• R.I.P •💔•❂••••••••\n     ✥ อาล้ยยิ่งกับการจากไป ✥\n••••••••❂•🔷•🔶•🔶•🔷•❂••••••••','••••••••❂•🔷• R.I.P •🔷•❂••••••••\n     ✥ อาล้ยยิ่งกับการจากไป ✥\n••••••••❂•💔•🌟•🌟•💔•❂••••••••','••••••••❂•🔶• R.I.P •🔶•❂••••••••\n     ✥ อาล้ยยิ่งกับการจากไป ✥\n••••••••❂•💜•💛•💛•💜•❂••••••••','••••••••❂•🔶• R.I.P •🔶•❂••••••••\n     ✥ อาล้ยยิ่งกับการจากไป ✥\n••••••••❂•💚•🌟•🌟•💚•❂••••••••','••••••••❂•🔶• R.I.P •🔶•❂••••••••\n     ✥ อาล้ยยิ่งกับการจากไป ✥\n••••••••❂•💜•🔷•🔷•💜•❂••••••••','••••••••❂•🌟• R.I.P •🌟•❂••••••••\n     ✥ อาล้ยยิ่งกับการจากไป ✥\n••••••••❂•🔶•🔷•🔷•🔶•❂••••••••','••••••••❂•♥• R.I.P •♥•❂••••••••\n     ✥ อาล้ยยิ่งกับการจากไป ✥\n••••••••❂•⭐•⭐•⭐•⭐•❂••••••••','••••••••❂•🌟• R.I.P •🌟•❂••••••••\n     ✥ อาล้ยยิ่งกับการจากไป ✥\n••••••••❂•💜•💙•💙•💜•❂••••••••','••••••••❂•🔶• R.I.P •🔶•❂••••••••\n     ✥ อาล้ยยิ่งกับการจากไป ✥\n••••••••❂•💜•💙•💙•💜•❂••••••••','••••••••❂•🔷• R.I.P •🔷•❂••••••••\n     ✥ อาล้ยยิ่งกับการจากไป ✥\n••••••••❂•💚•💛•💛•💚•❂••••••••']
          #   line.sendMessage(op.param1,str(settings["bye"]) + "\n   R.I.P. ณ. เวลา 🕟 " +datetime.today().strftime('%H:%M:%S')+ "™\n❂•➤➤➤➤➤➤➤➤➤➤➤➤\n     ✥อาล้ยยิ่งกับการจากไป✥\n •➣ {}\n •➣ {}".format(str(dan.displayName),str(tgb.name)))
          #   line.sendMessage(op.param1, str(random.choice(chivaree6))  + "\n•ชื่อ• {}\n•เวลา• {}".format(str(dan.displayName),str(tgb.name)))
             line.sendMessage(op.param1, str(random.choice(chivaree6))  + "\n•ชื่อ• {}".format(str(dan.displayName)) + "\n•เวลา• [" +datetime.today().strftime('%H:%M:%S')+ "] \n™T̶e̶a̶m̶b̶o̶t̶ ̶a̶v̶e̶n̶g̶e̶r̶s̶✯͜͡❂➣")
             line.sendContact(op.param1, op.param2)
             line.sendImageWithURL(op.param1, "http://dl.profile.line-cdn.net{}".format(dan.picturePath))        

        if op.type == 55:
            try:
                if RfuCctv['cyduk'][op.param1]==True:
                    if op.param1 in RfuCctv['point']:
                        Name = line.getContact(op.param2).displayName
                        if Name in RfuCctv['sidermem'][op.param1]:
                            pass
                        else:
                            RfuCctv['sidermem'][op.param1] += "\n✔ " + Name
                            #pref= settings["cctv"]
                            kittyText(op.param1, settings["cctv"] +' '+Name)
                    else:
                        pass
                else:
                    pass
            except:
                pass

        if op.type == 55:
            try:
                if RfuCctv['cyduk'][op.param1]==True:
                    if op.param1 in RfuCctv['point']:
                        Name = line.getContact(op.param2).displayName
                        if Name in RfuCctv['sidermem'][op.param1]:
                            pass
                        else:
                            RfuCctv['sidermem'][op.param1] += "\n✔ " + Name + "\n╚═══════════════"
                            if " " in Name:
                            	nick = Name.split(' ')
                            if len(nick) == 2:
                            	kittyText(op.param1, "Nah " +nick[0])
                            summon(op.param1, [op.param2])
                    else:
                        pass
                else:
                    pass
            except:
                pass
        if op.type == 55:
            print ("[ 55 ] ตรวจพบข้อความคำสั่ง")
            try:
                if op.param1 in read['readPoint']:
                    if op.param2 in read['readMember'][op.param1]:
                        pass
                    else:
                        read['readMember'][op.param1] += op.param2
                    read['ROM'][op.param1][op.param2] = op.param2
                    backupData()
                else:
                   pass
            except:
                pass
    except Exception as error:
        logError(error)
#==============================================================================#
while True:
    try:
        ops = oepoll.singleTrace(count=50)
        if ops is not None:
            for op in ops:
                lineBot(op)
                oepoll.setRevision(op.revision)
    except Exception as e:
        logError(e)
